"""EvoCRM v2 top-level model.

Flow:
  (tabular)    ──► CustomerTower      ┐
  (seq)        ──► ProductInteraction ┼──► concat tokens ──► Perceiver IO hub
  (cat_ids)    ──► ProductCatalog     ┘                      (N_latent, d_latent)
                                                                  │
                                           ┌──────────────────────┼──────────────────────┐
                                           ▼                      ▼                      ▼
                                    OutputQueryHead        OutputQueryHead        OutputQueryHead
                                      (churn, binary)      (category, K-way)        (CLV, reg)
"""
from __future__ import annotations
import torch
import torch.nn as nn
from typing import Dict, List, Optional
from .config import EvoCRMConfig, TaskHeadConfig
from .towers import CustomerTower, ProductInteractionTower, ProductCatalogTower
from .perceiver import PerceiverIOHub, OutputQueryHead


class EvoCRM(nn.Module):
    def __init__(
        self,
        config: EvoCRMConfig,
        n_tabular_features: int,
        product_vocab_size: int,
        n_categories: int,
    ):
        super().__init__()
        self.config = config
        self.n_tabular_features = n_tabular_features

        input_dim = config.perceiver.input_dim

        self.customer_tower = CustomerTower(
            n_tabular_features=n_tabular_features,
            d_token=config.ft_transformer.d_token,
            n_blocks=config.ft_transformer.n_blocks,
            n_heads=config.ft_transformer.n_heads,
            output_dim=input_dim,
            dropout=config.ft_transformer.attention_dropout,
        )
        self.interaction_tower = ProductInteractionTower(
            product_vocab_size=product_vocab_size,
            output_dim=input_dim,
            dropout=config.perceiver.dropout,
        )
        self.catalog_tower = ProductCatalogTower(
            n_categories=n_categories,
            output_dim=input_dim,
        )

        self.hub = PerceiverIOHub(
            num_latents=config.perceiver.num_latents,
            latent_dim=config.perceiver.latent_dim,
            input_dim=input_dim,
            n_cross_attention_heads=config.perceiver.n_cross_attention_heads,
            n_self_attention_heads=config.perceiver.n_self_attention_heads,
            n_self_attention_blocks_per_layer=(
                config.perceiver.n_self_attention_blocks_per_layer
            ),
            n_layers=config.perceiver.n_layers,
            dropout=config.perceiver.dropout,
        )

        # Task heads — one output query per task
        self.task_heads = nn.ModuleDict()
        self.task_configs: Dict[str, TaskHeadConfig] = {}
        for task in config.task_heads:
            self.task_heads[task.name] = OutputQueryHead(
                latent_dim=config.perceiver.latent_dim,
                query_dim=config.perceiver.latent_dim,
                output_dim=task.num_classes,
                n_heads=config.perceiver.n_cross_attention_heads,
                hidden_dim=task.hidden_dim,
                dropout=config.perceiver.dropout,
            )
            self.task_configs[task.name] = task

        # Uncertainty weighting: log-variance per task (Kendall 2018)
        if config.training.use_uncertainty_weighting:
            self.log_vars = nn.ParameterDict({
                t.name: nn.Parameter(torch.zeros(1))
                for t in config.task_heads
            })
        else:
            self.log_vars = None

    def forward(
        self,
        tabular: torch.Tensor,              # (B, F)
        seq_pids: torch.Tensor,             # (B, L)
        seq_dt: torch.Tensor,               # (B, L)
        seq_mask: torch.Tensor,             # (B, L) bool
        cat_ids: torch.Tensor,              # (B, K)
    ) -> Dict[str, torch.Tensor]:
        # Towers
        cust_tok = self.customer_tower(tabular)             # (B, F+1, d)
        seq_tok = self.interaction_tower(seq_pids, seq_dt, seq_mask)  # (B, L, d)
        cat_tok = self.catalog_tower(cat_ids)               # (B, 1, d)

        # Build fused token sequence + mask
        B = cust_tok.size(0)
        cust_mask = torch.ones(
            B, cust_tok.size(1), dtype=torch.bool, device=tabular.device,
        )
        cat_mask = torch.ones(
            B, cat_tok.size(1), dtype=torch.bool, device=tabular.device,
        )
        fused = torch.cat([cust_tok, seq_tok, cat_tok], dim=1)
        fused_mask = torch.cat([cust_mask, seq_mask, cat_mask], dim=1)

        latents = self.hub(fused, input_mask=fused_mask)   # (B, N_lat, d_lat)

        outputs = {}
        for name, head in self.task_heads.items():
            outputs[name] = head(latents)
        return outputs

    def compute_loss(
        self,
        outputs: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
        valid_masks: Dict[str, torch.Tensor],
    ) -> Dict[str, torch.Tensor]:
        """Multi-task loss with per-sample validity masking.

        targets[name]: (B,) for binary/regression, (B,) long for multiclass
        valid_masks[name]: (B,) bool — only include these rows in task's loss
        """
        losses = {}
        total = 0.0
        for name, cfg in self.task_configs.items():
            pred = outputs[name]
            tgt = targets[name]
            vm = valid_masks[name]
            if vm.sum() == 0:
                losses[name] = torch.tensor(0.0, device=pred.device)
                continue

            pred_v = pred[vm]
            tgt_v = tgt[vm]

            if cfg.task_type == "binary":
                bce = nn.functional.binary_cross_entropy_with_logits(
                    pred_v.squeeze(-1), tgt_v.float(), reduction="mean",
                )
                l = bce
            elif cfg.task_type == "multiclass":
                l = nn.functional.cross_entropy(pred_v, tgt_v.long())
            elif cfg.task_type == "regression":
                # Huber on log1p(target) — CLV is heavy-tailed
                pred_s = pred_v.squeeze(-1)
                tgt_s = torch.log1p(tgt_v.clamp(min=0.0).float())
                l = nn.functional.huber_loss(pred_s, tgt_s, delta=1.0)
            else:
                raise ValueError(f"Unknown task_type: {cfg.task_type}")

            losses[name] = l

            if self.log_vars is not None:
                log_var = self.log_vars[name]
                # Kendall weighting: L/(2σ²) + log σ
                weighted = 0.5 * torch.exp(-log_var) * l + 0.5 * log_var
                total = total + weighted.squeeze()
            else:
                total = total + cfg.loss_weight * l

        losses["total"] = total
        return losses
