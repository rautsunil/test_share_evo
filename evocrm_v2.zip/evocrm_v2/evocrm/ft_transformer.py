"""FT-Transformer implementation for tabular inputs.

Based on Gorishniy et al. 2021, "Revisiting Deep Learning Models for
Tabular Data" (NeurIPS). Simplified for EvoCRM v2: numerical-only features
since our tabular feature set is RFM-style.
"""
from __future__ import annotations
import math
import torch
import torch.nn as nn
from typing import Optional


class NumericalFeatureTokenizer(nn.Module):
    """One learnable (weight, bias) per feature → (B, F, d_token)."""
    def __init__(self, n_features: int, d_token: int):
        super().__init__()
        self.weight = nn.Parameter(torch.empty(n_features, d_token))
        self.bias = nn.Parameter(torch.empty(n_features, d_token))
        nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))
        nn.init.zeros_(self.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, F) → (B, F, d)
        return x.unsqueeze(-1) * self.weight + self.bias


class CLSToken(nn.Module):
    def __init__(self, d_token: int):
        super().__init__()
        self.cls = nn.Parameter(torch.empty(1, 1, d_token))
        nn.init.trunc_normal_(self.cls, std=0.02)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, F, d) → (B, F+1, d) with CLS prepended
        B = x.size(0)
        return torch.cat([self.cls.expand(B, -1, -1), x], dim=1)


class FTTransformerBlock(nn.Module):
    def __init__(
        self, d_token: int, n_heads: int,
        attention_dropout: float, ffn_dropout: float,
        ffn_hidden_mult: float, residual_dropout: float,
    ):
        super().__init__()
        self.norm1 = nn.LayerNorm(d_token)
        self.attn = nn.MultiheadAttention(
            embed_dim=d_token, num_heads=n_heads,
            dropout=attention_dropout, batch_first=True,
        )
        self.drop1 = nn.Dropout(residual_dropout)

        self.norm2 = nn.LayerNorm(d_token)
        d_hidden = int(d_token * ffn_hidden_mult)
        self.ffn = nn.Sequential(
            nn.Linear(d_token, d_hidden),
            nn.GELU(),
            nn.Dropout(ffn_dropout),
            nn.Linear(d_hidden, d_token),
        )
        self.drop2 = nn.Dropout(residual_dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.norm1(x)
        a, _ = self.attn(h, h, h, need_weights=False)
        x = x + self.drop1(a)
        h = self.norm2(x)
        x = x + self.drop2(self.ffn(h))
        return x


class FTTransformer(nn.Module):
    """Full FT-Transformer encoder. Returns (B, F+1, d_token).

    Downstream modules can pick CLS (index 0) or use the full sequence.
    """
    def __init__(
        self,
        n_features: int,
        d_token: int = 64,
        n_blocks: int = 3,
        n_heads: int = 8,
        attention_dropout: float = 0.1,
        ffn_dropout: float = 0.1,
        ffn_d_hidden_multiplier: float = 4 / 3,
        residual_dropout: float = 0.0,
    ):
        super().__init__()
        self.tokenizer = NumericalFeatureTokenizer(n_features, d_token)
        self.cls = CLSToken(d_token)
        self.blocks = nn.ModuleList([
            FTTransformerBlock(
                d_token=d_token, n_heads=n_heads,
                attention_dropout=attention_dropout,
                ffn_dropout=ffn_dropout,
                ffn_hidden_mult=ffn_d_hidden_multiplier,
                residual_dropout=residual_dropout,
            )
            for _ in range(n_blocks)
        ])
        self.norm = nn.LayerNorm(d_token)
        self.d_token = d_token

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, F) numerical features
        h = self.tokenizer(x)              # (B, F, d)
        h = self.cls(h)                    # (B, F+1, d)
        for blk in self.blocks:
            h = blk(h)
        h = self.norm(h)
        return h                           # (B, F+1, d)
