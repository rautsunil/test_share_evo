"""Input towers for EvoCRM v2.

Each tower produces tokens in the shared input_dim space so the Perceiver
hub can cross-attend across them uniformly.

Towers:
  - CustomerTower: FT-Transformer over tabular RFM features.
  - ProductInteractionTower: sequence of product embeddings + time deltas.
  - (Optional) TextTower: for when real text embeddings are available.
"""
from __future__ import annotations
import torch
import torch.nn as nn
from typing import Optional
from .ft_transformer import FTTransformer


class CustomerTower(nn.Module):
    def __init__(
        self,
        n_tabular_features: int,
        d_token: int = 64,
        n_blocks: int = 3,
        n_heads: int = 8,
        output_dim: int = 128,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.ft = FTTransformer(
            n_features=n_tabular_features,
            d_token=d_token,
            n_blocks=n_blocks,
            n_heads=n_heads,
            attention_dropout=dropout,
            ffn_dropout=dropout,
        )
        self.proj = nn.Linear(d_token, output_dim)

    def forward(self, tabular: torch.Tensor) -> torch.Tensor:
        # tabular: (B, F)
        h = self.ft(tabular)         # (B, F+1, d_token)
        return self.proj(h)          # (B, F+1, output_dim)


class ProductInteractionTower(nn.Module):
    """Product-id + time-delta encoder.

    Each interaction becomes a token:  emb(product_id) + time_feat(delta).
    """
    def __init__(
        self,
        product_vocab_size: int,
        output_dim: int = 128,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.product_emb = nn.Embedding(
            product_vocab_size, output_dim, padding_idx=0,
        )
        # Time features: log(delta+1), delta/30, delta/365
        self.time_mlp = nn.Sequential(
            nn.Linear(3, output_dim),
            nn.GELU(),
            nn.Linear(output_dim, output_dim),
        )
        self.norm = nn.LayerNorm(output_dim)
        self.dropout = nn.Dropout(dropout)
        self.output_dim = output_dim

    def forward(
        self,
        product_ids: torch.Tensor,      # (B, L) long
        time_deltas: torch.Tensor,      # (B, L) float, days from cutoff
        mask: torch.Tensor,             # (B, L) bool — True = valid
    ) -> torch.Tensor:
        p_emb = self.product_emb(product_ids)      # (B, L, d)

        td = time_deltas.clamp(min=0.0).unsqueeze(-1)
        time_feats = torch.cat([
            torch.log1p(td),
            td / 30.0,
            td / 365.0,
        ], dim=-1)
        t_emb = self.time_mlp(time_feats)           # (B, L, d)

        h = self.norm(p_emb + t_emb)
        h = self.dropout(h)
        # Zero out padding positions so cross-attention masking downstream
        # has consistent semantics even if we forget to pass the mask
        h = h * mask.unsqueeze(-1).float()
        return h


class ProductCatalogTower(nn.Module):
    """Static product-catalog token per customer: aggregated category embedding.

    In production you'd swap this for Sentence-BERT over descriptions;
    here we use category indices as a stand-in.
    """
    def __init__(
        self,
        n_categories: int,
        output_dim: int = 128,
    ):
        super().__init__()
        self.cat_emb = nn.Embedding(
            n_categories + 1, output_dim, padding_idx=0,
        )
        self.norm = nn.LayerNorm(output_dim)

    def forward(self, cat_ids: torch.Tensor) -> torch.Tensor:
        # cat_ids: (B, K) — top-K category indices per customer
        h = self.cat_emb(cat_ids).mean(dim=1, keepdim=True)  # (B, 1, d)
        return self.norm(h)
