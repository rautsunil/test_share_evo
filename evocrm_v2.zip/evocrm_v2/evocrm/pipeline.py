"""End-to-end pipeline for EvoCRM v2.

Given the four canonical tables, build features and labels, assemble
a train/val split (customer-level, temporal), train, and evaluate.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from typing import Dict, Tuple, Optional
from dataclasses import dataclass

from .config import EvoCRMConfig
from .labels import LabelingConfig, build_all_labels, suggest_cutoff
from .features import (
    build_customer_features, build_interaction_sequences,
    assemble_feature_matrix,
)
from .dataset import EvoCRMDataset
from .model import EvoCRM
from .train import train_model
from .evaluate import evaluate


@dataclass
class PipelineArtifacts:
    model: EvoCRM
    train_dataset: EvoCRMDataset
    val_dataset: EvoCRMDataset
    train_metrics: Dict
    val_metrics: Dict
    history: Dict
    feature_names: list
    product_vocab_size: int
    n_categories: int


def run_pipeline(
    tables: Dict[str, pd.DataFrame],
    config: EvoCRMConfig,
    cutoff_date: Optional[pd.Timestamp] = None,
    val_fraction: float = 0.2,
    verbose: bool = True,
) -> PipelineArtifacts:
    """Run the full pipeline end-to-end.

    tables must contain the 4 canonical EvoCRM tables (see data.EVOCRM_SCHEMA).
    """
    orders = tables["orders"]
    order_items = tables["order_items"]
    products = tables["products"]
    customers = tables["customers"]

    # --- 1. Temporal cutoff
    if cutoff_date is None:
        cutoff_date = suggest_cutoff(
            orders,
            observation_days=config.data.observation_window_days,
        )
    if verbose:
        print(f"[pipeline] cutoff_date = {cutoff_date}")

    # --- 2. Labels (post-cutoff only)
    lbl_cfg = LabelingConfig(
        cutoff_date=cutoff_date,
        observation_window_days=config.data.observation_window_days,
        min_feature_window_days=config.data.min_feature_window_days,
    )
    labels_df = build_all_labels(
        orders, order_items, products, customers, lbl_cfg,
    )
    if verbose:
        print(f"[pipeline] labels: n={len(labels_df)} | "
              f"churn_rate={labels_df['churn'].mean():.3f}")

    # --- 3. Features (pre-cutoff only)
    cust_feats = build_customer_features(
        orders, order_items, customers, cutoff_date,
    )
    seq_data = build_interaction_sequences(
        orders, order_items, customers, cutoff_date,
        max_length=config.data.max_sequence_length,
    )

    # Only use customers who have both labels AND features
    common_ids = labels_df["customer_unique_id"].values
    common_ids = [c for c in common_ids if c in cust_feats.index]
    labels_df = labels_df.set_index("customer_unique_id").loc[common_ids].reset_index()

    feat_matrix = assemble_feature_matrix(
        cust_feats, seq_data, common_ids,
    )

    # Category ids per customer: take their most-common category in feature window
    # (simple default; could be swapped for Sentence-BERT embeddings)
    cat_ids = _build_customer_category_ids(
        orders, order_items, products, customers,
        cutoff_date, common_ids, top_k=3,
    )
    n_categories = int(cat_ids.max()) + 1 if cat_ids.size > 0 else 1

    # --- 4. Train/val split (customer-level, random within already-temporally-split data)
    rng = np.random.default_rng(config.training.seed)
    idx = np.arange(len(common_ids))
    rng.shuffle(idx)
    n_val = int(len(idx) * val_fraction)
    val_idx = idx[:n_val]
    trn_idx = idx[n_val:]

    def build_ds(rows):
        return EvoCRMDataset(
            tabular=feat_matrix["tabular"][rows],
            seq_pids=feat_matrix["seq_pids"][rows],
            seq_dt=feat_matrix["seq_dt"][rows],
            seq_mask=feat_matrix["seq_mask"][rows],
            cat_ids=cat_ids[rows],
            labels={
                "churn": labels_df["churn"].values[rows],
                "category": np.where(
                    labels_df["category"].values[rows] >= 0,
                    labels_df["category"].values[rows], 0,
                ),
                "clv": labels_df["clv"].values[rows].astype(np.float32),
            },
            valid_masks={
                "churn": labels_df["churn_valid"].values[rows],
                "category": labels_df["category_valid"].values[rows],
                "clv": labels_df["clv_valid"].values[rows],
            },
        )

    train_ds = build_ds(trn_idx)
    val_ds = build_ds(val_idx)

    # --- 5. Adjust config for observed category count
    # (reserves a slot for the "other" bucket if needed)
    for t in config.task_heads:
        if t.name == "category":
            max_cat_label = int(labels_df["category"].clip(lower=0).max()) + 1
            t.num_classes = max(t.num_classes, max_cat_label)

    # --- 6. Model
    n_tabular_features = feat_matrix["tabular"].shape[1]
    model = EvoCRM(
        config=config,
        n_tabular_features=n_tabular_features,
        product_vocab_size=seq_data.product_id_vocab_size,
        n_categories=n_categories,
    )

    if verbose:
        n_params = sum(p.numel() for p in model.parameters())
        print(f"[pipeline] model params: {n_params:,}")

    # --- 7. Train
    history = train_model(model, train_ds, val_ds, config, verbose=verbose)

    # --- 8. Evaluate
    train_metrics = evaluate(model, train_ds, device=config.training.device)
    val_metrics = evaluate(model, val_ds, device=config.training.device)

    if verbose:
        print("[pipeline] TRAIN metrics:")
        for k, v in train_metrics.items():
            print(f"   {k}: {v}")
        print("[pipeline] VAL metrics:")
        for k, v in val_metrics.items():
            print(f"   {k}: {v}")

    return PipelineArtifacts(
        model=model,
        train_dataset=train_ds,
        val_dataset=val_ds,
        train_metrics=train_metrics,
        val_metrics=val_metrics,
        history=history,
        feature_names=feat_matrix["tabular_feature_names"],
        product_vocab_size=seq_data.product_id_vocab_size,
        n_categories=n_categories,
    )


def _build_customer_category_ids(
    orders, order_items, products, customers,
    cutoff_date, customer_ids, top_k=3,
):
    """For each customer, return their top-K most frequent category ids
    in the feature window. Reserves id 0 for padding/unknown.
    """
    cutoff = pd.Timestamp(cutoff_date)
    o = orders.merge(
        customers[["customer_id", "customer_unique_id"]],
        on="customer_id", how="inner",
    )
    o["order_purchase_timestamp"] = pd.to_datetime(o["order_purchase_timestamp"])
    o = o[o["order_purchase_timestamp"] <= cutoff]
    o = o[~o["order_status"].isin(["canceled", "unavailable"])]

    merged = o.merge(order_items, on="order_id").merge(
        products[["product_id", "product_category_name"]], on="product_id",
    )
    # Build category vocab
    cats = sorted(merged["product_category_name"].dropna().unique())
    cat_to_idx = {c: i + 1 for i, c in enumerate(cats)}

    out = np.zeros((len(customer_ids), top_k), dtype=np.int64)
    id_to_row = {c: i for i, c in enumerate(customer_ids)}

    for cuid, grp in merged.groupby("customer_unique_id", sort=False):
        if cuid not in id_to_row:
            continue
        counts = grp["product_category_name"].value_counts().head(top_k)
        row = id_to_row[cuid]
        for i, cat in enumerate(counts.index):
            out[row, i] = cat_to_idx.get(cat, 0)
    return out
