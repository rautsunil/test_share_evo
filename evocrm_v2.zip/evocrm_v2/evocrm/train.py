"""Training loop for EvoCRM v2."""
from __future__ import annotations
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR
from typing import Dict, List, Optional, Tuple
from .config import EvoCRMConfig
from .model import EvoCRM
from .dataset import EvoCRMDataset


def _pick_device(requested: str) -> torch.device:
    if requested == "cuda" and torch.cuda.is_available():
        return torch.device("cuda")
    return torch.device("cpu")


def train_model(
    model: EvoCRM,
    train_dataset: EvoCRMDataset,
    val_dataset: Optional[EvoCRMDataset],
    config: EvoCRMConfig,
    verbose: bool = True,
) -> Dict[str, List[float]]:
    device = _pick_device(config.training.device)
    model.to(device)

    train_loader = DataLoader(
        train_dataset, batch_size=config.training.batch_size,
        shuffle=True, drop_last=False,
    )
    val_loader = (
        DataLoader(val_dataset, batch_size=config.training.batch_size)
        if val_dataset is not None else None
    )

    optimizer = AdamW(
        model.parameters(),
        lr=config.training.learning_rate,
        weight_decay=config.training.weight_decay,
    )
    total_steps = max(1, len(train_loader) * config.training.num_epochs)
    scheduler = CosineAnnealingLR(optimizer, T_max=total_steps)

    history = {"train_total": [], "val_total": []}
    best_val = float("inf")
    patience_ctr = 0

    for epoch in range(config.training.num_epochs):
        model.train()
        train_sum, train_n = 0.0, 0
        for batch in train_loader:
            batch_dev = {
                k: v.to(device) for k, v in batch.items()
            }
            outputs = model(
                tabular=batch_dev["tabular"],
                seq_pids=batch_dev["seq_pids"],
                seq_dt=batch_dev["seq_dt"],
                seq_mask=batch_dev["seq_mask"],
                cat_ids=batch_dev["cat_ids"],
            )
            targets = {
                name: batch_dev[f"label_{name}"]
                for name in model.task_configs.keys()
            }
            valid_masks = {
                name: batch_dev[f"valid_{name}"]
                for name in model.task_configs.keys()
            }
            losses = model.compute_loss(outputs, targets, valid_masks)
            loss = losses["total"]

            optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(
                model.parameters(), config.training.gradient_clip,
            )
            optimizer.step()
            scheduler.step()

            train_sum += float(loss.item()) * batch_dev["tabular"].size(0)
            train_n += batch_dev["tabular"].size(0)

        train_avg = train_sum / max(train_n, 1)
        history["train_total"].append(train_avg)

        # Validation
        val_avg = float("nan")
        if val_loader is not None:
            val_avg = _eval_total_loss(model, val_loader, device)
            history["val_total"].append(val_avg)

            if val_avg < best_val - 1e-4:
                best_val = val_avg
                patience_ctr = 0
            else:
                patience_ctr += 1

        if verbose:
            print(f"epoch {epoch+1:3d} | train={train_avg:.4f}"
                  + (f" | val={val_avg:.4f}" if val_loader else ""))

        if patience_ctr >= config.training.patience:
            if verbose:
                print(f"early stop at epoch {epoch+1}")
            break

    return history


def _eval_total_loss(model: EvoCRM, loader: DataLoader, device) -> float:
    model.eval()
    total, n = 0.0, 0
    with torch.no_grad():
        for batch in loader:
            batch_dev = {k: v.to(device) for k, v in batch.items()}
            outputs = model(
                tabular=batch_dev["tabular"],
                seq_pids=batch_dev["seq_pids"],
                seq_dt=batch_dev["seq_dt"],
                seq_mask=batch_dev["seq_mask"],
                cat_ids=batch_dev["cat_ids"],
            )
            targets = {
                name: batch_dev[f"label_{name}"]
                for name in model.task_configs.keys()
            }
            valid_masks = {
                name: batch_dev[f"valid_{name}"]
                for name in model.task_configs.keys()
            }
            losses = model.compute_loss(outputs, targets, valid_masks)
            total += float(losses["total"].item()) * batch_dev["tabular"].size(0)
            n += batch_dev["tabular"].size(0)
    return total / max(n, 1)
