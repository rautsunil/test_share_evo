"""Configuration objects for EvoCRM v2.

All hyperparameters flow through these dataclasses. No magic numbers in modules.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class DataConfig:
    # Temporal leak-prevention
    observation_window_days: int = 90
    min_feature_window_days: int = 30

    # Sequence handling
    max_sequence_length: int = 50        # max interactions per customer
    min_sequence_length: int = 1

    # Categorical handling
    max_categories_per_feature: int = 1000
    unknown_category_token: int = 0      # reserved id for <UNK>
    padding_category_token: int = 0

    # Text
    text_embedding_dim: int = 384        # paraphrase-multilingual-MiniLM-L12-v2 output
    max_text_length: int = 64


@dataclass
class FTTransformerConfig:
    """Feature Tokenizer Transformer for the Customer Tower."""
    d_token: int = 64
    n_blocks: int = 3
    n_heads: int = 8
    attention_dropout: float = 0.1
    ffn_dropout: float = 0.1
    ffn_d_hidden_multiplier: float = 4/3  # standard FT-T default
    residual_dropout: float = 0.0


@dataclass
class PerceiverConfig:
    """Perceiver IO hub configuration."""
    num_latents: int = 64
    latent_dim: int = 128
    input_dim: int = 128                 # all towers project to this
    n_cross_attention_heads: int = 4
    n_self_attention_heads: int = 8
    n_self_attention_blocks_per_layer: int = 2
    n_layers: int = 4
    dropout: float = 0.1


@dataclass
class TaskHeadConfig:
    name: str
    task_type: str                       # "binary", "multiclass", "regression"
    num_classes: int = 1                 # 1 for binary/regression, K for multiclass
    loss_weight: float = 1.0
    hidden_dim: int = 128


@dataclass
class LoRAConfig:
    enabled: bool = True
    rank: int = 8
    alpha: int = 16
    dropout: float = 0.05
    target_modules: List[str] = field(
        default_factory=lambda: ["q_proj", "v_proj"]
    )


@dataclass
class TrainingConfig:
    batch_size: int = 128
    num_epochs: int = 20
    learning_rate: float = 1e-4
    weight_decay: float = 1e-5
    warmup_steps: int = 200
    gradient_clip: float = 1.0
    device: str = "cuda"                 # falls back to cpu automatically
    seed: int = 42

    # Multi-task loss: uncertainty weighting (Kendall et al. 2018)
    use_uncertainty_weighting: bool = True

    # Early stopping
    patience: int = 5


@dataclass
class EvoCRMConfig:
    data: DataConfig = field(default_factory=DataConfig)
    ft_transformer: FTTransformerConfig = field(default_factory=FTTransformerConfig)
    perceiver: PerceiverConfig = field(default_factory=PerceiverConfig)
    lora: LoRAConfig = field(default_factory=LoRAConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)
    task_heads: List[TaskHeadConfig] = field(
        default_factory=lambda: [
            TaskHeadConfig(name="churn", task_type="binary", num_classes=1),
            TaskHeadConfig(name="category", task_type="multiclass", num_classes=10),
            TaskHeadConfig(name="clv", task_type="regression", num_classes=1),
        ]
    )
