"""Feature engineering for EvoCRM v2.

CRITICAL: every function here takes `cutoff_date` and filters source data
to `timestamp <= cutoff` BEFORE any aggregation. This is the feature-side
leak prevention. Combined with labels.py (which only uses post-cutoff data),
the train/test pipeline is temporally clean.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple
from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Customer-level tabular features (RFM + derived)
# ---------------------------------------------------------------------------
def build_customer_features(
    orders: pd.DataFrame,
    order_items: pd.DataFrame,
    customers: pd.DataFrame,
    cutoff_date: pd.Timestamp,
) -> pd.DataFrame:
    """Tabular features per customer_unique_id, strictly <= cutoff."""
    cutoff = pd.Timestamp(cutoff_date)

    # Resolve unique ids
    orders = orders.merge(
        customers[["customer_id", "customer_unique_id"]],
        on="customer_id", how="inner", validate="many_to_one",
    )
    orders["order_purchase_timestamp"] = pd.to_datetime(
        orders["order_purchase_timestamp"]
    )
    # CUTOFF GUARD — every downstream aggregation derives from this
    orders = orders[orders["order_purchase_timestamp"] <= cutoff].copy()
    orders = orders[~orders["order_status"].isin(["canceled", "unavailable"])]

    if len(orders) == 0:
        return pd.DataFrame(columns=[
            "customer_unique_id", "recency_days", "frequency",
            "monetary", "avg_order_value", "tenure_days", "n_items",
        ]).set_index("customer_unique_id")

    items = orders.merge(order_items, on="order_id", how="inner")
    items["line_total"] = items["price"] + items["freight_value"]

    order_totals = items.groupby(
        ["customer_unique_id", "order_id"]
    )["line_total"].sum().reset_index()

    agg_orders = orders.groupby("customer_unique_id").agg(
        last_order=("order_purchase_timestamp", "max"),
        first_order=("order_purchase_timestamp", "min"),
        frequency=("order_id", "nunique"),
    )
    agg_money = order_totals.groupby("customer_unique_id").agg(
        monetary=("line_total", "sum"),
        avg_order_value=("line_total", "mean"),
    )
    agg_items = items.groupby("customer_unique_id").agg(
        n_items=("product_id", "count"),
    )

    feats = agg_orders.join(agg_money).join(agg_items)
    feats["recency_days"] = (cutoff - feats["last_order"]).dt.days
    feats["tenure_days"] = (cutoff - feats["first_order"]).dt.days
    feats = feats.drop(columns=["last_order", "first_order"])

    # Reorder + fillna
    feats = feats[[
        "recency_days", "frequency", "monetary",
        "avg_order_value", "tenure_days", "n_items",
    ]].fillna(0)
    return feats


# ---------------------------------------------------------------------------
# Interaction sequences (variable-length per customer)
# ---------------------------------------------------------------------------
@dataclass
class SequenceData:
    """Per-customer interaction sequence, padded/truncated."""
    customer_ids: np.ndarray              # (N,)
    product_ids: np.ndarray               # (N, L) int
    timestamps_delta: np.ndarray          # (N, L) float, days from cutoff
    mask: np.ndarray                      # (N, L) bool, True = real token
    product_id_vocab_size: int


def build_interaction_sequences(
    orders: pd.DataFrame,
    order_items: pd.DataFrame,
    customers: pd.DataFrame,
    cutoff_date: pd.Timestamp,
    max_length: int = 50,
) -> SequenceData:
    """Sorted most-recent-last interaction sequences, capped at max_length."""
    cutoff = pd.Timestamp(cutoff_date)

    orders = orders.merge(
        customers[["customer_id", "customer_unique_id"]],
        on="customer_id", how="inner", validate="many_to_one",
    )
    orders["order_purchase_timestamp"] = pd.to_datetime(
        orders["order_purchase_timestamp"]
    )
    orders = orders[orders["order_purchase_timestamp"] <= cutoff].copy()
    orders = orders[~orders["order_status"].isin(["canceled", "unavailable"])]

    items = orders.merge(order_items, on="order_id", how="inner")
    items = items.sort_values(["customer_unique_id", "order_purchase_timestamp"])

    # Build product vocab (reserve 0 for padding)
    unique_products = items["product_id"].unique()
    pid_to_idx = {p: i + 1 for i, p in enumerate(unique_products)}
    vocab_size = len(pid_to_idx) + 1   # +1 for pad

    # Per-customer sequences
    cust_ids = []
    pid_matrix = []
    dt_matrix = []
    mask_matrix = []

    for cuid, grp in items.groupby("customer_unique_id", sort=False):
        pids = grp["product_id"].map(pid_to_idx).to_numpy()
        ts = grp["order_purchase_timestamp"].to_numpy()
        # seconds -> days (pandas 3.x dropped "timedelta64[D]" casting)
        deltas_sec = (cutoff - pd.to_datetime(ts)).total_seconds().to_numpy()
        deltas = (deltas_sec / 86400.0).astype(float)

        # Truncate to most recent max_length
        if len(pids) > max_length:
            pids = pids[-max_length:]
            deltas = deltas[-max_length:]

        L = len(pids)
        pad_len = max_length - L
        pids_padded = np.concatenate([pids, np.zeros(pad_len, dtype=np.int64)])
        deltas_padded = np.concatenate([deltas, np.zeros(pad_len, dtype=np.float32)])
        mask_padded = np.concatenate([
            np.ones(L, dtype=bool), np.zeros(pad_len, dtype=bool),
        ])

        cust_ids.append(cuid)
        pid_matrix.append(pids_padded)
        dt_matrix.append(deltas_padded)
        mask_matrix.append(mask_padded)

    if not cust_ids:
        return SequenceData(
            customer_ids=np.array([]),
            product_ids=np.zeros((0, max_length), dtype=np.int64),
            timestamps_delta=np.zeros((0, max_length), dtype=np.float32),
            mask=np.zeros((0, max_length), dtype=bool),
            product_id_vocab_size=vocab_size,
        )

    return SequenceData(
        customer_ids=np.array(cust_ids),
        product_ids=np.stack(pid_matrix).astype(np.int64),
        timestamps_delta=np.stack(dt_matrix).astype(np.float32),
        mask=np.stack(mask_matrix),
        product_id_vocab_size=vocab_size,
    )


# ---------------------------------------------------------------------------
# Product text features (category → embedding proxy)
# ---------------------------------------------------------------------------
def build_product_category_embeddings(
    products: pd.DataFrame,
    embedding_dim: int = 64,
    seed: int = 42,
) -> Tuple[pd.DataFrame, Dict[str, int]]:
    """Category embedding lookup. In production, use multilingual Sentence-BERT;
    here we use a deterministic random embedding to keep the pipeline runnable
    offline. Interface is identical.
    """
    rng = np.random.default_rng(seed)
    cats = sorted(products["product_category_name"].dropna().unique())
    cat_to_idx = {c: i + 1 for i, c in enumerate(cats)}   # reserve 0 for unknown

    emb_matrix = rng.standard_normal(
        (len(cats) + 1, embedding_dim)
    ).astype(np.float32) * 0.1

    products = products.copy()
    products["category_idx"] = products["product_category_name"].map(
        cat_to_idx
    ).fillna(0).astype(int)

    return products, cat_to_idx, emb_matrix


# ---------------------------------------------------------------------------
# Assembly: all features keyed by customer_unique_id
# ---------------------------------------------------------------------------
def assemble_feature_matrix(
    customer_features: pd.DataFrame,
    sequences: SequenceData,
    customer_ids_order: List[str],
) -> Dict[str, np.ndarray]:
    """Align all feature sources to a common customer_id ordering."""
    cust_df = customer_features.reindex(customer_ids_order).fillna(0)

    # Build seq alignment map
    seq_map = {c: i for i, c in enumerate(sequences.customer_ids)}
    empty_seq = np.zeros(sequences.product_ids.shape[1], dtype=np.int64)
    empty_dt = np.zeros(sequences.timestamps_delta.shape[1], dtype=np.float32)
    empty_mask = np.zeros(sequences.mask.shape[1], dtype=bool)

    seq_pids, seq_dt, seq_masks = [], [], []
    for cuid in customer_ids_order:
        idx = seq_map.get(cuid)
        if idx is None:
            seq_pids.append(empty_seq)
            seq_dt.append(empty_dt)
            seq_masks.append(empty_mask)
        else:
            seq_pids.append(sequences.product_ids[idx])
            seq_dt.append(sequences.timestamps_delta[idx])
            seq_masks.append(sequences.mask[idx])

    return {
        "tabular": cust_df.to_numpy(dtype=np.float32),
        "tabular_feature_names": list(cust_df.columns),
        "seq_pids": np.stack(seq_pids) if seq_pids else np.zeros((0, 0), dtype=np.int64),
        "seq_dt": np.stack(seq_dt) if seq_dt else np.zeros((0, 0), dtype=np.float32),
        "seq_mask": np.stack(seq_masks) if seq_masks else np.zeros((0, 0), dtype=bool),
    }
