"""EvoCRM v2: Foundation model for CRM prediction via Perceiver IO hub."""
__version__ = "2.0.0"
