"""Specialist baselines for EvoCRM v2.

Each task gets a dedicated classical model trained on the tabular
feature matrix only (no sequence/catalog modalities). This is the
apples-to-apples "specialist" comparison for the hub-and-spoke claim.
"""
from __future__ import annotations
import numpy as np
from typing import Dict, List
from sklearn.ensemble import (
    GradientBoostingClassifier, GradientBoostingRegressor,
    RandomForestClassifier, RandomForestRegressor,
)
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    roc_auc_score, f1_score, accuracy_score,
    mean_squared_error, mean_absolute_error,
)


def train_baselines(
    X_train: np.ndarray,
    X_val: np.ndarray,
    labels_train: Dict[str, np.ndarray],
    labels_val: Dict[str, np.ndarray],
    valid_train: Dict[str, np.ndarray],
    valid_val: Dict[str, np.ndarray],
    task_types: Dict[str, str],        # name -> "binary"/"multiclass"/"regression"
    seed: int = 42,
) -> Dict[str, Dict[str, Dict[str, float]]]:
    """Train per-task specialist baselines and return metrics.

    Returns structure: {task_name: {model_name: {metric: value}}}
    """
    results: Dict[str, Dict[str, Dict[str, float]]] = {}

    for task, ttype in task_types.items():
        vm_tr = valid_train[task].astype(bool)
        vm_va = valid_val[task].astype(bool)

        y_tr = labels_train[task][vm_tr]
        y_va = labels_val[task][vm_va]
        X_tr = X_train[vm_tr]
        X_va = X_val[vm_va]

        if len(y_tr) < 20 or len(y_va) < 5:
            results[task] = {"error": "insufficient data"}
            continue

        task_results = {}

        if ttype == "binary":
            for name, clf in [
                ("gbm", GradientBoostingClassifier(random_state=seed, n_estimators=100)),
                ("rf", RandomForestClassifier(random_state=seed, n_estimators=200)),
                ("logreg", LogisticRegression(max_iter=500, random_state=seed)),
            ]:
                try:
                    clf.fit(X_tr, y_tr)
                    proba = clf.predict_proba(X_va)[:, 1]
                    pred = (proba > 0.5).astype(int)
                    task_results[name] = {
                        "auc": float(roc_auc_score(y_va, proba))
                              if len(np.unique(y_va)) > 1 else float("nan"),
                        "f1": float(f1_score(y_va, pred, zero_division=0)),
                        "accuracy": float(accuracy_score(y_va, pred)),
                    }
                except Exception as e:
                    task_results[name] = {"error": str(e)}

        elif ttype == "multiclass":
            for name, clf in [
                ("gbm", GradientBoostingClassifier(random_state=seed, n_estimators=100)),
                ("rf", RandomForestClassifier(random_state=seed, n_estimators=200)),
                ("logreg", LogisticRegression(max_iter=500, random_state=seed, multi_class="auto")),
            ]:
                try:
                    clf.fit(X_tr, y_tr)
                    pred = clf.predict(X_va)
                    task_results[name] = {
                        "accuracy": float(accuracy_score(y_va, pred)),
                        "f1_macro": float(f1_score(y_va, pred, average="macro", zero_division=0)),
                        "f1_weighted": float(f1_score(y_va, pred, average="weighted", zero_division=0)),
                    }
                except Exception as e:
                    task_results[name] = {"error": str(e)}

        elif ttype == "regression":
            y_tr_log = np.log1p(np.clip(y_tr, a_min=0, a_max=None))
            for name, reg in [
                ("gbm", GradientBoostingRegressor(random_state=seed, n_estimators=100)),
                ("rf", RandomForestRegressor(random_state=seed, n_estimators=200)),
            ]:
                try:
                    reg.fit(X_tr, y_tr_log)
                    pred_log = reg.predict(X_va)
                    pred = np.expm1(pred_log).clip(min=0)
                    task_results[name] = {
                        "rmse": float(np.sqrt(mean_squared_error(y_va, pred))),
                        "mae": float(mean_absolute_error(y_va, pred)),
                    }
                except Exception as e:
                    task_results[name] = {"error": str(e)}

        results[task] = task_results

    return results


def baselines_from_pipeline(artifacts, labels_df) -> Dict:
    """Convenience: pull the train/val tabular matrices out of pipeline
    artifacts and run baselines.
    """
    train_ds = artifacts.train_dataset
    val_ds = artifacts.val_dataset

    X_tr = train_ds.tabular
    X_va = val_ds.tabular

    labels_train = train_ds.labels
    labels_val = val_ds.labels
    valid_train = train_ds.valid_masks
    valid_val = val_ds.valid_masks

    task_types = {t.name: t.task_type for t in artifacts.model.config.task_heads}

    return train_baselines(
        X_tr, X_va, labels_train, labels_val,
        valid_train, valid_val, task_types,
    )
