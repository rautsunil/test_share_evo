"""Data module.

Two entry points:
  1. generate_synthetic_olist(...) — produces Olist-shaped tables for
     end-to-end testing without downloads.
  2. load_olist(root_dir) / load_retailrocket(root_dir) — adapters for
     real datasets when you point at them.

All outputs conform to the schema expected by labels.py and features.py.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Dict
from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Schema: the 4 canonical tables EvoCRM consumes
# ---------------------------------------------------------------------------
EVOCRM_SCHEMA = {
    "orders": [
        "order_id", "customer_id", "order_purchase_timestamp", "order_status",
    ],
    "order_items": [
        "order_id", "product_id", "price", "freight_value",
    ],
    "products": [
        "product_id", "product_category_name",
    ],
    "customers": [
        "customer_id", "customer_unique_id",
    ],
}


def generate_synthetic_olist(
    n_customers: int = 2000,
    n_products: int = 200,
    n_categories: int = 12,
    start_date: str = "2022-01-01",
    end_date: str = "2023-12-31",
    seed: int = 42,
) -> Dict[str, pd.DataFrame]:
    """Generate Olist-shaped synthetic data.

    Key realism: purchase timing is driven by a per-customer Poisson rate,
    so churn is a genuine signal (low-rate customers skip the observation
    window), NOT a deterministic function of any feature. This means a
    correctly-built pipeline should get AUC in the 0.7–0.85 range, and
    AUC > 0.95 indicates a leak.
    """
    rng = np.random.default_rng(seed)
    start = pd.Timestamp(start_date)
    end = pd.Timestamp(end_date)
    total_days = (end - start).days

    # Customers: latent purchase rate drives behavior
    customer_unique_ids = [f"cust_{i:06d}" for i in range(n_customers)]
    # Heavy-tailed rates — some customers buy often, most rarely
    rates = rng.lognormal(mean=-3.5, sigma=1.2, size=n_customers)  # orders/day
    rates = np.clip(rates, 1e-4, 0.5)

    # Products with categories
    cat_names = [f"cat_{i:02d}" for i in range(n_categories)]
    product_ids = [f"prod_{i:05d}" for i in range(n_products)]
    product_cats = rng.choice(cat_names, size=n_products)
    product_prices = rng.lognormal(mean=3.5, sigma=0.7, size=n_products)

    products_df = pd.DataFrame({
        "product_id": product_ids,
        "product_category_name": product_cats,
    })

    # Generate orders per customer via Poisson process
    orders_rows = []
    items_rows = []
    customers_rows = []
    order_counter = 0

    for cust_idx, (cuid, rate) in enumerate(zip(customer_unique_ids, rates)):
        expected = rate * total_days
        n_orders = rng.poisson(expected)
        n_orders = max(n_orders, 0)

        if n_orders == 0:
            # Still register the customer (with a placeholder customer_id)
            customers_rows.append({
                "customer_id": f"cid_{cust_idx:06d}_0",
                "customer_unique_id": cuid,
            })
            continue

        # Uniform order timestamps across the window
        timestamps = sorted([
            start + pd.Timedelta(days=float(rng.uniform(0, total_days)))
            for _ in range(n_orders)
        ])

        for k, ts in enumerate(timestamps):
            cid = f"cid_{cust_idx:06d}_{k}"
            oid = f"ord_{order_counter:08d}"
            order_counter += 1

            customers_rows.append({
                "customer_id": cid, "customer_unique_id": cuid,
            })
            status = rng.choice(
                ["delivered", "shipped", "canceled"],
                p=[0.92, 0.05, 0.03],
            )
            orders_rows.append({
                "order_id": oid,
                "customer_id": cid,
                "order_purchase_timestamp": ts,
                "order_status": status,
            })

            # 1–4 items per order
            n_items = rng.integers(1, 5)
            for _ in range(n_items):
                p_idx = rng.integers(0, n_products)
                items_rows.append({
                    "order_id": oid,
                    "product_id": product_ids[p_idx],
                    "price": float(product_prices[p_idx]),
                    "freight_value": float(rng.uniform(5, 25)),
                })

    return {
        "orders": pd.DataFrame(orders_rows),
        "order_items": pd.DataFrame(items_rows),
        "products": products_df,
        "customers": pd.DataFrame(customers_rows).drop_duplicates("customer_id"),
    }


def load_olist(root: str) -> Dict[str, pd.DataFrame]:
    """Load real Olist CSVs from a directory.

    Expects the standard Kaggle filenames:
      olist_orders_dataset.csv
      olist_order_items_dataset.csv
      olist_products_dataset.csv
      olist_customers_dataset.csv
    """
    root = Path(root)
    files = {
        "orders": "olist_orders_dataset.csv",
        "order_items": "olist_order_items_dataset.csv",
        "products": "olist_products_dataset.csv",
        "customers": "olist_customers_dataset.csv",
    }
    tables = {}
    for key, fname in files.items():
        p = root / fname
        if not p.exists():
            raise FileNotFoundError(f"Missing {p}")
        tables[key] = pd.read_csv(p)
    return tables


def load_retailrocket(root: str) -> Dict[str, pd.DataFrame]:
    """Adapter for RetailRocket → EvoCRM schema (for transfer evaluation).

    RetailRocket has events.csv (visitorid, itemid, event, timestamp) and
    item_properties*.csv. We synthesize a minimal EvoCRM schema from it.
    """
    root = Path(root)
    events = pd.read_csv(root / "events.csv")
    # Keep only transactions as "orders"
    tx = events[events["event"] == "transaction"].copy()
    tx["order_purchase_timestamp"] = pd.to_datetime(tx["timestamp"], unit="ms")
    tx["order_id"] = "rr_ord_" + tx.index.astype(str)
    tx["customer_id"] = "rr_cid_" + tx["visitorid"].astype(str)
    tx["order_status"] = "delivered"

    orders = tx[[
        "order_id", "customer_id", "order_purchase_timestamp", "order_status",
    ]]
    customers = pd.DataFrame({
        "customer_id": tx["customer_id"].unique(),
        "customer_unique_id": tx["customer_id"].unique(),
    })
    order_items = pd.DataFrame({
        "order_id": tx["order_id"],
        "product_id": "rr_prod_" + tx["itemid"].astype(str),
        "price": 1.0,    # not available in RR
        "freight_value": 0.0,
    })
    products = pd.DataFrame({
        "product_id": order_items["product_id"].unique(),
        "product_category_name": "unknown",
    })
    return {
        "orders": orders,
        "order_items": order_items,
        "products": products,
        "customers": customers,
    }
