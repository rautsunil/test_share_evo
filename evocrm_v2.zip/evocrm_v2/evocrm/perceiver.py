"""Perceiver IO hub for EvoCRM v2.

Architecture:
  - Small learned latent array (N_latent, d_latent).
  - Cross-attention: latents attend to concatenated input streams.
  - Stacked self-attention blocks on the latents.
  - Output queries (one per task) cross-attend to latents → task features.

This implements hub-and-spoke AT THE ARCHITECTURAL LEVEL:
  hub   = latent array + self-attention stack
  spokes= output queries (one per task head)
"""
from __future__ import annotations
import torch
import torch.nn as nn
from typing import Dict, List, Optional


class CrossAttention(nn.Module):
    def __init__(
        self, q_dim: int, kv_dim: int, n_heads: int, dropout: float = 0.0,
    ):
        super().__init__()
        self.q_norm = nn.LayerNorm(q_dim)
        self.kv_norm = nn.LayerNorm(kv_dim)
        # Project KV into Q space so one MHA handles it
        self.kv_proj = nn.Linear(kv_dim, q_dim)
        self.attn = nn.MultiheadAttention(
            embed_dim=q_dim, num_heads=n_heads,
            dropout=dropout, batch_first=True,
        )
        self.ffn = nn.Sequential(
            nn.Linear(q_dim, q_dim * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(q_dim * 2, q_dim),
        )
        self.out_norm = nn.LayerNorm(q_dim)

    def forward(
        self, q: torch.Tensor, kv: torch.Tensor,
        key_padding_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        q_n = self.q_norm(q)
        kv_n = self.kv_proj(self.kv_norm(kv))
        a, _ = self.attn(q_n, kv_n, kv_n,
                         key_padding_mask=key_padding_mask,
                         need_weights=False)
        q = q + a
        q = q + self.ffn(self.out_norm(q))
        return q


class SelfAttentionBlock(nn.Module):
    def __init__(self, d: int, n_heads: int, dropout: float = 0.0):
        super().__init__()
        self.norm1 = nn.LayerNorm(d)
        self.attn = nn.MultiheadAttention(
            embed_dim=d, num_heads=n_heads,
            dropout=dropout, batch_first=True,
        )
        self.norm2 = nn.LayerNorm(d)
        self.ffn = nn.Sequential(
            nn.Linear(d, d * 4), nn.GELU(),
            nn.Dropout(dropout), nn.Linear(d * 4, d),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.norm1(x)
        a, _ = self.attn(h, h, h, need_weights=False)
        x = x + a
        x = x + self.ffn(self.norm2(x))
        return x


class PerceiverIOHub(nn.Module):
    def __init__(
        self,
        num_latents: int = 64,
        latent_dim: int = 128,
        input_dim: int = 128,
        n_cross_attention_heads: int = 4,
        n_self_attention_heads: int = 8,
        n_self_attention_blocks_per_layer: int = 2,
        n_layers: int = 4,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.latents = nn.Parameter(torch.empty(num_latents, latent_dim))
        nn.init.trunc_normal_(self.latents, std=0.02)

        # Alternating cross-attention + self-attention stack
        self.cross_attns = nn.ModuleList([
            CrossAttention(
                q_dim=latent_dim, kv_dim=input_dim,
                n_heads=n_cross_attention_heads, dropout=dropout,
            )
            for _ in range(n_layers)
        ])
        self.self_attn_stacks = nn.ModuleList([
            nn.ModuleList([
                SelfAttentionBlock(
                    d=latent_dim, n_heads=n_self_attention_heads,
                    dropout=dropout,
                )
                for _ in range(n_self_attention_blocks_per_layer)
            ])
            for _ in range(n_layers)
        ])

        self.latent_dim = latent_dim
        self.input_dim = input_dim

    def forward(
        self,
        inputs: torch.Tensor,
        input_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """inputs: (B, N, input_dim) — fused/concatenated from all towers.
           input_mask: (B, N) bool; True = real token, False = padding.
        Returns: (B, num_latents, latent_dim)
        """
        B = inputs.size(0)
        latents = self.latents.unsqueeze(0).expand(B, -1, -1)

        # key_padding_mask in PyTorch MHA: True = IGNORE. Invert.
        kp_mask = None
        if input_mask is not None:
            kp_mask = ~input_mask

        for cross, sa_stack in zip(self.cross_attns, self.self_attn_stacks):
            latents = cross(latents, inputs, key_padding_mask=kp_mask)
            for sa in sa_stack:
                latents = sa(latents)
        return latents


class OutputQueryHead(nn.Module):
    """One output query per task. Cross-attends to latents and projects to
    task-specific output dim. This IS the 'spoke' in hub-and-spoke.
    """
    def __init__(
        self,
        latent_dim: int,
        query_dim: int,
        output_dim: int,
        n_heads: int = 4,
        hidden_dim: int = 128,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.query = nn.Parameter(torch.empty(1, 1, query_dim))
        nn.init.trunc_normal_(self.query, std=0.02)

        self.cross = CrossAttention(
            q_dim=query_dim, kv_dim=latent_dim,
            n_heads=n_heads, dropout=dropout,
        )
        self.mlp = nn.Sequential(
            nn.LayerNorm(query_dim),
            nn.Linear(query_dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, output_dim),
        )

    def forward(self, latents: torch.Tensor) -> torch.Tensor:
        # latents: (B, N_latent, d_latent)
        B = latents.size(0)
        q = self.query.expand(B, -1, -1)    # (B, 1, query_dim)
        h = self.cross(q, latents)           # (B, 1, query_dim)
        return self.mlp(h.squeeze(1))        # (B, output_dim)
