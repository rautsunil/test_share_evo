"""Label construction for EvoCRM v2.

All three tasks (churn, category, CLV) use strict temporal discipline:
  - Features come from data at or before cutoff_date.
  - Labels come from data strictly after cutoff_date.
  - No feature sees any post-cutoff event.

This module handles LABELS ONLY. Feature-side leak prevention lives in
the data adapters.
"""
from __future__ import annotations
import pandas as pd
import numpy as np
from dataclasses import dataclass
from typing import Tuple


@dataclass
class LabelingConfig:
    cutoff_date: pd.Timestamp
    observation_window_days: int = 90
    min_feature_window_days: int = 30


def build_all_labels(
    orders: pd.DataFrame,
    order_items: pd.DataFrame,
    products: pd.DataFrame,
    customers: pd.DataFrame,
    config: LabelingConfig,
) -> pd.DataFrame:
    """Build labels for churn, category, and CLV.

    Required columns:
        orders: order_id, customer_id, order_purchase_timestamp, order_status
        order_items: order_id, product_id, price, freight_value
        products: product_id, product_category_name
        customers: customer_id, customer_unique_id

    Returns:
        DataFrame indexed by customer_unique_id with:
            churn           ∈ {0, 1}
            category        ∈ {0, ..., K-1}  (next category after cutoff)
            clv             float            (observation-window revenue)
            churn_valid     bool             (eligible for churn label)
            category_valid  bool             (eligible for category label)
            clv_valid       bool             (eligible for clv label)
    """
    _validate_columns(orders, order_items, products, customers)

    cutoff = pd.Timestamp(config.cutoff_date)
    obs_end = cutoff + pd.Timedelta(days=config.observation_window_days)

    # Resolve customer_unique_id (Olist quirk: customer_id changes per order)
    orders = orders.merge(
        customers[["customer_id", "customer_unique_id"]],
        on="customer_id",
        how="inner",
        validate="many_to_one",
    )
    orders["order_purchase_timestamp"] = pd.to_datetime(
        orders["order_purchase_timestamp"]
    )

    # Drop non-realized orders
    orders = orders[~orders["order_status"].isin(["canceled", "unavailable"])].copy()

    # Validate observation window fits inside data
    dataset_max = orders["order_purchase_timestamp"].max()
    if obs_end > dataset_max:
        raise ValueError(
            f"Observation window ends at {obs_end.date()} but dataset "
            f"ends at {dataset_max.date()}. Move cutoff earlier."
        )

    in_feature = orders["order_purchase_timestamp"] <= cutoff
    in_observation = (
        (orders["order_purchase_timestamp"] > cutoff)
        & (orders["order_purchase_timestamp"] <= obs_end)
    )

    feat_orders = orders.loc[in_feature].copy()
    obs_orders = orders.loc[in_observation].copy()

    # --- Eligibility: customer must have ≥1 order in feature window and
    #     enough runway to be observable
    feat_agg = feat_orders.groupby("customer_unique_id").agg(
        feature_orders=("order_id", "nunique"),
        first_feat_order=("order_purchase_timestamp", "min"),
    )
    min_window = pd.Timedelta(days=config.min_feature_window_days)
    eligible_mask = (
        (feat_agg["feature_orders"] >= 1)
        & ((cutoff - feat_agg["first_feat_order"]) >= min_window)
    )
    eligible = feat_agg.loc[eligible_mask].index

    # --- Churn label
    obs_order_counts = obs_orders.groupby("customer_unique_id")["order_id"].nunique()
    obs_order_counts = obs_order_counts.reindex(eligible, fill_value=0)
    churn = (obs_order_counts == 0).astype(int)

    # --- CLV label (revenue in observation window)
    obs_items = obs_orders.merge(order_items, on="order_id", how="inner")
    obs_items["line_total"] = obs_items["price"] + obs_items["freight_value"]
    obs_revenue = obs_items.groupby("customer_unique_id")["line_total"].sum()
    clv = obs_revenue.reindex(eligible, fill_value=0.0)

    # --- Category label (category of FIRST post-cutoff order, top-K only)
    category = _build_category_labels(
        obs_orders, order_items, products, eligible
    )

    # --- Assemble
    labels = pd.DataFrame(
        {
            "churn": churn.values,
            "category": category.values,
            "clv": clv.values,
        },
        index=eligible,
    )
    labels["churn_valid"] = True
    labels["category_valid"] = category.values >= 0   # -1 means no next order
    labels["clv_valid"] = True
    # Category label only meaningful for non-churners
    labels.loc[labels["churn"] == 1, "category_valid"] = False

    labels.index.name = "customer_unique_id"
    return labels.reset_index()


def _build_category_labels(
    obs_orders: pd.DataFrame,
    order_items: pd.DataFrame,
    products: pd.DataFrame,
    eligible: pd.Index,
    top_k: int = 10,
) -> pd.Series:
    """Category of the first product in the first post-cutoff order."""
    if len(obs_orders) == 0:
        return pd.Series(-1, index=eligible, dtype=int)

    # Earliest post-cutoff order per customer
    first_obs = (
        obs_orders.sort_values("order_purchase_timestamp")
        .groupby("customer_unique_id")
        .first()
        .reset_index()
    )
    # Get product categories for that order
    first_items = first_obs.merge(
        order_items[["order_id", "product_id"]], on="order_id", how="left"
    )
    first_items = first_items.merge(
        products[["product_id", "product_category_name"]],
        on="product_id",
        how="left",
    )
    # First product per customer (order items aren't ordered; take first row)
    first_per_cust = first_items.groupby("customer_unique_id").first()

    # Map to top-K categories; others → bucket K-1 ("other")
    vc = first_per_cust["product_category_name"].value_counts()
    top_cats = vc.head(top_k - 1).index.tolist()
    cat_map = {c: i for i, c in enumerate(top_cats)}

    def map_cat(c):
        if pd.isna(c):
            return -1   # no label available
        return cat_map.get(c, top_k - 1)  # "other" bucket

    cats = first_per_cust["product_category_name"].apply(map_cat)
    # Customers with no observation order → -1 (invalid)
    return cats.reindex(eligible, fill_value=-1).astype(int)


def suggest_cutoff(
    orders: pd.DataFrame, observation_days: int = 90
) -> pd.Timestamp:
    ts = pd.to_datetime(orders["order_purchase_timestamp"])
    return ts.max().normalize() - pd.Timedelta(days=observation_days)


def _validate_columns(orders, order_items, products, customers):
    req = {
        "orders": {"order_id", "customer_id", "order_purchase_timestamp", "order_status"},
        "order_items": {"order_id", "product_id", "price", "freight_value"},
        "products": {"product_id", "product_category_name"},
        "customers": {"customer_id", "customer_unique_id"},
    }
    for name, df in [
        ("orders", orders),
        ("order_items", order_items),
        ("products", products),
        ("customers", customers),
    ]:
        missing = req[name] - set(df.columns)
        if missing:
            raise ValueError(f"{name} missing columns: {missing}")
