"""PyTorch Dataset for EvoCRM v2."""
from __future__ import annotations
import numpy as np
import torch
from torch.utils.data import Dataset
from typing import Dict, List


class EvoCRMDataset(Dataset):
    def __init__(
        self,
        tabular: np.ndarray,                # (N, F) float
        seq_pids: np.ndarray,               # (N, L) long
        seq_dt: np.ndarray,                 # (N, L) float
        seq_mask: np.ndarray,               # (N, L) bool
        cat_ids: np.ndarray,                # (N, K) long
        labels: Dict[str, np.ndarray],      # name → (N,)
        valid_masks: Dict[str, np.ndarray], # name → (N,) bool
    ):
        self.tabular = tabular.astype(np.float32)
        self.seq_pids = seq_pids.astype(np.int64)
        self.seq_dt = seq_dt.astype(np.float32)
        self.seq_mask = seq_mask.astype(bool)
        self.cat_ids = cat_ids.astype(np.int64)
        self.labels = {k: v for k, v in labels.items()}
        self.valid_masks = {k: v.astype(bool) for k, v in valid_masks.items()}
        self._n = len(tabular)

    def __len__(self):
        return self._n

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        item = {
            "tabular": torch.from_numpy(self.tabular[idx]),
            "seq_pids": torch.from_numpy(self.seq_pids[idx]),
            "seq_dt": torch.from_numpy(self.seq_dt[idx]),
            "seq_mask": torch.from_numpy(self.seq_mask[idx]),
            "cat_ids": torch.from_numpy(self.cat_ids[idx]),
        }
        for name, arr in self.labels.items():
            item[f"label_{name}"] = torch.tensor(arr[idx])
        for name, m in self.valid_masks.items():
            item[f"valid_{name}"] = torch.tensor(m[idx])
        return item
