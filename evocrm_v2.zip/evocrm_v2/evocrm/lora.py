"""LoRA adapters for EvoCRM v2.

Implements low-rank adaptation (Hu et al. 2021) for parameter-efficient
fine-tuning. Used for the "self-evolving" mechanism: after pretraining,
the base model is frozen and only small LoRA matrices are updated on
new data (e.g., overnight on fresh outcome signals).

Core idea:
    W_effective = W + (B @ A) * (alpha / rank)
    where W is frozen, A ∈ R^(rank × in), B ∈ R^(out × rank) are trainable.
"""
from __future__ import annotations
import math
import torch
import torch.nn as nn
from typing import List, Optional


class LoRALinear(nn.Module):
    """Wraps a frozen nn.Linear with a trainable low-rank residual."""
    def __init__(
        self,
        base_linear: nn.Linear,
        rank: int = 8,
        alpha: int = 16,
        dropout: float = 0.0,
    ):
        super().__init__()
        self.base = base_linear
        # Freeze base
        for p in self.base.parameters():
            p.requires_grad = False

        in_f = base_linear.in_features
        out_f = base_linear.out_features
        self.lora_A = nn.Parameter(torch.empty(rank, in_f))
        self.lora_B = nn.Parameter(torch.zeros(out_f, rank))
        nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
        # B initialized to zero → identity at init

        self.scale = alpha / rank
        self.drop = nn.Dropout(dropout) if dropout > 0 else nn.Identity()
        self.rank = rank
        self.alpha = alpha

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        base_out = self.base(x)
        lora_out = self.drop(x) @ self.lora_A.T @ self.lora_B.T
        return base_out + lora_out * self.scale


def inject_lora(
    model: nn.Module,
    target_module_names: List[str],
    rank: int = 8,
    alpha: int = 16,
    dropout: float = 0.05,
) -> int:
    """Replace matching nn.Linear modules with LoRALinear wrappers.

    Matches by suffix: any Linear whose attribute path ends with one of
    the target names is wrapped. Returns count of wrapped modules.
    """
    wrapped = 0
    for parent_name, parent in _iter_modules_with_names(model):
        for attr_name, child in list(parent.named_children()):
            if not isinstance(child, nn.Linear):
                continue
            if not any(attr_name.endswith(t) for t in target_module_names):
                continue
            wrapped_mod = LoRALinear(
                child, rank=rank, alpha=alpha, dropout=dropout,
            )
            setattr(parent, attr_name, wrapped_mod)
            wrapped += 1
    return wrapped


def inject_lora_into_attention(
    model: nn.Module,
    rank: int = 8,
    alpha: int = 16,
    dropout: float = 0.05,
) -> int:
    """Convenience: wrap attention projection layers.

    PyTorch's nn.MultiheadAttention uses internal Linear for in_proj/out_proj.
    We wrap out_proj (safest, doesn't break fused QKV) and any standalone
    Linear named q_proj/k_proj/v_proj if present.
    """
    wrapped = 0
    for parent_name, parent in _iter_modules_with_names(model):
        for attr_name, child in list(parent.named_children()):
            if isinstance(child, nn.MultiheadAttention):
                # Wrap the out_proj only (in_proj is a fused parameter)
                if hasattr(child, "out_proj") and isinstance(child.out_proj, nn.Linear):
                    child.out_proj = LoRALinear(
                        child.out_proj, rank=rank, alpha=alpha, dropout=dropout,
                    )
                    wrapped += 1
            elif isinstance(child, nn.Linear) and attr_name in (
                "q_proj", "k_proj", "v_proj", "kv_proj",
            ):
                setattr(
                    parent, attr_name,
                    LoRALinear(child, rank=rank, alpha=alpha, dropout=dropout),
                )
                wrapped += 1
    return wrapped


def freeze_non_lora(model: nn.Module) -> int:
    """Freeze every parameter that isn't part of a LoRA adapter.

    Returns number of trainable parameters remaining.
    """
    for p in model.parameters():
        p.requires_grad = False
    n_trainable = 0
    for m in model.modules():
        if isinstance(m, LoRALinear):
            m.lora_A.requires_grad = True
            m.lora_B.requires_grad = True
            n_trainable += m.lora_A.numel() + m.lora_B.numel()
    return n_trainable


def count_parameters(model: nn.Module) -> dict:
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return {
        "total": total,
        "trainable": trainable,
        "frozen": total - trainable,
        "trainable_pct": 100.0 * trainable / max(total, 1),
    }


def _iter_modules_with_names(model: nn.Module):
    # named_modules() already includes the root (with name "")
    for name, mod in model.named_modules():
        yield name, mod
