"""Evaluation metrics for EvoCRM v2."""
from __future__ import annotations
import numpy as np
import torch
from torch.utils.data import DataLoader
from typing import Dict, List
from sklearn.metrics import (
    roc_auc_score, f1_score, accuracy_score,
    mean_squared_error, mean_absolute_error,
)
from .model import EvoCRM
from .dataset import EvoCRMDataset


def evaluate(
    model: EvoCRM,
    dataset: EvoCRMDataset,
    batch_size: int = 256,
    device: str = "cuda",
) -> Dict[str, Dict[str, float]]:
    """Compute per-task metrics. Only evaluates on valid rows per task."""
    dev = torch.device(device) if (device == "cpu" or torch.cuda.is_available()) else torch.device("cpu")
    model.to(dev).eval()
    loader = DataLoader(dataset, batch_size=batch_size)

    task_preds: Dict[str, List[np.ndarray]] = {n: [] for n in model.task_configs}
    task_targets: Dict[str, List[np.ndarray]] = {n: [] for n in model.task_configs}
    task_valid: Dict[str, List[np.ndarray]] = {n: [] for n in model.task_configs}

    with torch.no_grad():
        for batch in loader:
            batch_dev = {k: v.to(dev) for k, v in batch.items()}
            outputs = model(
                tabular=batch_dev["tabular"],
                seq_pids=batch_dev["seq_pids"],
                seq_dt=batch_dev["seq_dt"],
                seq_mask=batch_dev["seq_mask"],
                cat_ids=batch_dev["cat_ids"],
            )
            for name in model.task_configs:
                task_preds[name].append(outputs[name].cpu().numpy())
                task_targets[name].append(
                    batch_dev[f"label_{name}"].cpu().numpy()
                )
                task_valid[name].append(
                    batch_dev[f"valid_{name}"].cpu().numpy()
                )

    results = {}
    for name, cfg in model.task_configs.items():
        preds = np.concatenate(task_preds[name])
        targets = np.concatenate(task_targets[name])
        valid = np.concatenate(task_valid[name]).astype(bool)

        if valid.sum() == 0:
            results[name] = {"n_valid": 0}
            continue

        preds_v = preds[valid]
        targets_v = targets[valid]

        if cfg.task_type == "binary":
            logits = preds_v.squeeze(-1)
            probs = 1.0 / (1.0 + np.exp(-logits))
            pred_cls = (probs > 0.5).astype(int)
            try:
                auc = roc_auc_score(targets_v, probs)
            except ValueError:
                auc = float("nan")
            results[name] = {
                "n_valid": int(valid.sum()),
                "auc": float(auc),
                "f1": float(f1_score(targets_v, pred_cls, zero_division=0)),
                "accuracy": float(accuracy_score(targets_v, pred_cls)),
                "pos_rate": float(targets_v.mean()),
            }
        elif cfg.task_type == "multiclass":
            pred_cls = preds_v.argmax(axis=-1)
            results[name] = {
                "n_valid": int(valid.sum()),
                "accuracy": float(accuracy_score(targets_v, pred_cls)),
                "f1_macro": float(f1_score(
                    targets_v, pred_cls, average="macro", zero_division=0,
                )),
                "f1_weighted": float(f1_score(
                    targets_v, pred_cls, average="weighted", zero_division=0,
                )),
            }
        elif cfg.task_type == "regression":
            # Model predicts log1p(CLV); invert for evaluation
            pred_s = preds_v.squeeze(-1)
            pred_clv = np.expm1(pred_s).clip(min=0)
            rmse = float(np.sqrt(mean_squared_error(targets_v, pred_clv)))
            mae = float(mean_absolute_error(targets_v, pred_clv))
            results[name] = {
                "n_valid": int(valid.sum()),
                "rmse": rmse,
                "mae": mae,
                "target_mean": float(targets_v.mean()),
            }
        else:
            results[name] = {"error": f"unknown type {cfg.task_type}"}

    return results
