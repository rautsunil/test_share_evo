"""Multi-dataset pretraining + transfer for EvoCRM v2.

This is what makes EvoCRM a *foundation model* and not just a multi-task
model: pretrain the hub and towers on multiple source datasets, then
transfer to unseen target datasets via LoRA fine-tuning.

Flow:
    1. Pretrain:  train EvoCRM on concatenated data from N source datasets
                  (each sample tagged with dataset_id for a domain token).
    2. Freeze:    freeze backbone, inject LoRA adapters.
    3. Transfer:  fine-tune only LoRA params on a small slice of the
                  target dataset.
    4. Evaluate:  compare (a) from-scratch baseline on target,
                         (b) pretrained + LoRA transfer,
                         (c) pretrained full fine-tune.
"""
from __future__ import annotations
import copy
import numpy as np
import pandas as pd
import torch
from typing import Dict, List, Optional
from dataclasses import dataclass

from .config import EvoCRMConfig
from .pipeline import run_pipeline, PipelineArtifacts
from .dataset import EvoCRMDataset
from .model import EvoCRM
from .train import train_model
from .evaluate import evaluate
from .lora import (
    inject_lora_into_attention, freeze_non_lora, count_parameters,
)


@dataclass
class TransferResults:
    source_datasets: List[str]
    target_dataset: str
    baseline_metrics: Dict           # train from scratch on target
    lora_transfer_metrics: Dict      # pretrain → LoRA on target
    full_finetune_metrics: Dict      # pretrain → full fine-tune on target
    lora_param_pct: float
    pretraining_history: Dict


def pretrain_multi_dataset(
    source_tables: Dict[str, Dict[str, pd.DataFrame]],
    config: EvoCRMConfig,
    verbose: bool = True,
) -> Dict:
    """Pretrain EvoCRM on multiple source datasets.

    source_tables: {dataset_name: {table_name: DataFrame}}

    Strategy: run pipeline on each source separately (each has its own
    product/category vocab), collect the union of trained models,
    then produce a single "pretrained backbone" state_dict by averaging
    the hub weights. This is a pragmatic approximation — true joint
    pretraining would require a unified vocabulary which is dataset-
    specific and beyond a one-shot build.

    A more faithful version (future work): add a dataset-id embedding
    to every input token and concatenate all source data.
    """
    source_artifacts = {}
    for ds_name, tables in source_tables.items():
        if verbose:
            print(f"\n=== pretraining on source: {ds_name} ===")
        src_cfg = copy.deepcopy(config)
        arts = run_pipeline(tables, src_cfg, verbose=verbose)
        source_artifacts[ds_name] = arts

    # Extract hub-only state_dicts (transferable part)
    # Towers depend on per-dataset vocab sizes; hub is vocab-free.
    hub_states = []
    for arts in source_artifacts.values():
        hub_sd = {
            k: v.clone().cpu()
            for k, v in arts.model.hub.state_dict().items()
        }
        hub_states.append(hub_sd)

    # Average hub weights (simple "model soup" for the transferable part)
    avg_hub = {}
    for k in hub_states[0].keys():
        stacked = torch.stack([sd[k].float() for sd in hub_states], dim=0)
        avg_hub[k] = stacked.mean(dim=0)

    # FT-Transformer inside the customer tower is also transferable
    # (no vocab dependency — it tokenizes numerical features)
    ft_states = []
    for arts in source_artifacts.values():
        ft_sd = {
            k: v.clone().cpu()
            for k, v in arts.model.customer_tower.ft.state_dict().items()
        }
        ft_states.append(ft_sd)
    avg_ft = {}
    for k in ft_states[0].keys():
        stacked = torch.stack([sd[k].float() for sd in ft_states], dim=0)
        avg_ft[k] = stacked.mean(dim=0)

    history = {
        "source_metrics": {
            name: arts.val_metrics
            for name, arts in source_artifacts.items()
        },
    }

    return {
        "hub_state": avg_hub,
        "ft_state": avg_ft,
        "source_artifacts": source_artifacts,
        "history": history,
    }


def load_pretrained_into_model(
    model: EvoCRM,
    pretrained: Dict,
    strict: bool = False,
) -> None:
    """Load pretrained hub + FT-Transformer weights into a fresh model.

    Only loads shapes that match (towers with different vocab sizes skipped).
    """
    # Hub
    hub_missing = model.hub.load_state_dict(
        pretrained["hub_state"], strict=strict,
    )
    # FT-Transformer inside customer tower
    ft_target = model.customer_tower.ft
    # FT tokenizer weight has shape (n_features, d_token); skip if mismatch
    ft_sd = pretrained["ft_state"]
    compatible = {}
    for k, v in ft_sd.items():
        cur = ft_target.state_dict().get(k)
        if cur is not None and cur.shape == v.shape:
            compatible[k] = v
    ft_target.load_state_dict(compatible, strict=False)


def transfer_evaluate(
    source_tables: Dict[str, Dict[str, pd.DataFrame]],
    target_tables: Dict[str, pd.DataFrame],
    target_name: str,
    config: EvoCRMConfig,
    verbose: bool = True,
) -> TransferResults:
    """Full pretrain → transfer → evaluate comparison."""

    # --- (a) Baseline: train from scratch on target
    if verbose:
        print("\n=== (a) baseline: train from scratch on target ===")
    baseline_cfg = copy.deepcopy(config)
    baseline_arts = run_pipeline(target_tables, baseline_cfg, verbose=verbose)
    baseline_metrics = baseline_arts.val_metrics

    # --- Pretrain
    if verbose:
        print("\n=== pretraining on source datasets ===")
    pretrained = pretrain_multi_dataset(
        source_tables, config, verbose=verbose,
    )

    # --- (b) LoRA transfer: pretrain → freeze → LoRA fine-tune on target
    if verbose:
        print("\n=== (b) LoRA transfer to target ===")
    lora_cfg = copy.deepcopy(config)
    lora_cfg.training.num_epochs = max(
        3, lora_cfg.training.num_epochs // 2,
    )
    # Build a fresh model on target shapes
    lora_arts_model = _fresh_model_for_target(target_tables, lora_cfg)
    load_pretrained_into_model(lora_arts_model.model, pretrained)
    # Inject LoRA and freeze base
    n_wrapped = inject_lora_into_attention(
        lora_arts_model.model,
        rank=config.lora.rank, alpha=config.lora.alpha,
        dropout=config.lora.dropout,
    )
    n_trainable = freeze_non_lora(lora_arts_model.model)
    param_stats = count_parameters(lora_arts_model.model)
    if verbose:
        print(f"   wrapped {n_wrapped} attention projections with LoRA")
        print(f"   trainable params: {param_stats['trainable']:,} "
              f"({param_stats['trainable_pct']:.2f}%)")

    train_model(
        lora_arts_model.model,
        lora_arts_model.train_dataset,
        lora_arts_model.val_dataset,
        lora_cfg, verbose=verbose,
    )
    lora_metrics = evaluate(
        lora_arts_model.model, lora_arts_model.val_dataset,
        device=lora_cfg.training.device,
    )

    # --- (c) Full fine-tune: pretrain → unfreeze everything on target
    if verbose:
        print("\n=== (c) full fine-tune transfer to target ===")
    ft_cfg = copy.deepcopy(config)
    full_arts = _fresh_model_for_target(target_tables, ft_cfg)
    load_pretrained_into_model(full_arts.model, pretrained)
    train_model(
        full_arts.model, full_arts.train_dataset, full_arts.val_dataset,
        ft_cfg, verbose=verbose,
    )
    full_metrics = evaluate(
        full_arts.model, full_arts.val_dataset,
        device=ft_cfg.training.device,
    )

    return TransferResults(
        source_datasets=list(source_tables.keys()),
        target_dataset=target_name,
        baseline_metrics=baseline_metrics,
        lora_transfer_metrics=lora_metrics,
        full_finetune_metrics=full_metrics,
        lora_param_pct=param_stats["trainable_pct"],
        pretraining_history=pretrained["history"],
    )


def _fresh_model_for_target(
    target_tables: Dict[str, pd.DataFrame],
    config: EvoCRMConfig,
) -> PipelineArtifacts:
    """Build model + datasets for the target WITHOUT training, so we can
    load pretrained weights first then train ourselves.
    """
    # Abuse run_pipeline with zero epochs to get the plumbing
    cfg = copy.deepcopy(config)
    cfg.training.num_epochs = 0
    cfg.training.patience = 1
    arts = run_pipeline(target_tables, cfg, verbose=False)
    return arts
