# EvoCRM v2

A foundation model for CRM prediction using a Perceiver IO hub with FT-Transformer towers,
supporting binary classification, multi-class classification, and regression as a single
multi-task model — with leak-audited labels and multi-dataset pretrain-and-transfer.

## Why v2 exists

v1 had two fundamental problems:
1. **Label leakage**: churn AUC of 0.99–1.0 traced to recency being computed over the observation window.
2. **Weak architectural motivation**: XLNet's permutation LM has no reason to be the hub for tabular+sequence fusion.

v2 fixes both. Labels are constructed strictly after `cutoff_date`; features strictly before it.
The hub is Perceiver IO (purpose-built for multi-modal fusion); the customer tower is FT-Transformer
(SOTA for tabular). Task heads are output queries that cross-attend to the latent array — the
hub-and-spoke metaphor becomes architecturally literal.

## Architecture

```
     ┌──────────────────┐   ┌──────────────────────┐   ┌──────────────────┐
     │  Customer Tower  │   │ Interaction Tower    │   │ Catalog Tower    │
     │  (FT-Transformer)│   │ (product+time embed) │   │ (category embed) │
     └────────┬─────────┘   └──────────┬───────────┘   └────────┬─────────┘
              │                        │                        │
              └───────────────┬────────┴────────────────────────┘
                              ▼
                  ┌───────────────────────────┐
                  │     Perceiver IO hub      │
                  │  latent array (N=64,d=128)│
                  │  cross-attn + self-attn   │
                  └─────────────┬─────────────┘
                                │
            ┌───────────────────┼───────────────────┐
            ▼                   ▼                   ▼
     OutputQueryHead     OutputQueryHead     OutputQueryHead
      (churn, binary)   (category, 10-way)    (CLV, regression)
```

The three spokes are each a learned query that cross-attends to the hub's latent array,
producing a task-specific output vector.

## Tasks

| Task | Type | Label (post-cutoff) | Metric |
|---|---|---|---|
| churn | binary | zero orders in 90d observation window | AUC-ROC, F1 |
| category | multi-class (top-K + "other") | category of first post-cutoff order | macro-F1, accuracy |
| clv | regression | revenue in 90d observation window | RMSE, MAE |

## Repository layout

```
evocrm_v2/
├── evocrm/
│   ├── config.py            — dataclasses: DataConfig, FTTransformerConfig, PerceiverConfig, LoRAConfig, TrainingConfig, TaskHeadConfig
│   ├── data.py              — synthetic Olist generator + Olist/RetailRocket loaders
│   ├── labels.py            — leak-free churn/category/CLV labeling
│   ├── features.py          — cutoff-gated RFM, interaction sequences, category embeddings
│   ├── ft_transformer.py    — FT-Transformer for Customer Tower
│   ├── perceiver.py         — Perceiver IO hub + OutputQueryHead
│   ├── towers.py            — Customer / ProductInteraction / ProductCatalog towers
│   ├── model.py             — EvoCRM top-level; multi-task loss w/ uncertainty weighting
│   ├── dataset.py           — PyTorch Dataset wrapping feature/label bundles
│   ├── train.py             — training loop (AdamW + cosine + early stop)
│   ├── evaluate.py          — per-task metrics
│   ├── pipeline.py          — end-to-end: data → labels → features → train → eval
│   ├── lora.py              — LoRA adapters + injection helpers
│   ├── pretrain_transfer.py — multi-dataset pretrain + LoRA transfer comparison
│   └── baselines.py         — GBM / RF / LogReg specialist baselines
├── notebooks/
│   └── validate_all_modules.ipynb — per-module validation notebook
├── scripts/
│   └── build_doc.js         — generates the one-page project document
├── tests/
│   └── smoke_torch_free.py  — validates data + labels + features without torch
├── run_evocrm.py            — CLI entry point
├── EvoCRM_v2_Project_Document.docx — one-page project writeup
└── README.md
```

## Running

```bash
# Synthetic smoke test (no downloads)
python run_evocrm.py --synthetic --quick

# Full synthetic run
python run_evocrm.py --synthetic --n_customers 2000 --epochs 20

# Real Olist data (point at the Kaggle-downloaded CSV directory)
python run_evocrm.py --olist_dir /path/to/olist/
```

The validation notebook walks through every module with small-input tests:

```bash
jupyter notebook notebooks/validate_all_modules.ipynb
```

## Requirements

- Python 3.10+
- torch, pandas, numpy, scikit-learn
- node + docx (only if you want to rebuild the project document)

## Status: what's validated, what isn't

**Validated (ran in sandbox, passed):**
- Every module passes Python syntax check.
- Synthetic data generation produces the correct 4-table schema.
- Label construction invariants hold: churners have CLV=0; no negative recency; healthy churn rate (~20%).
- Feature construction respects the cutoff: zero recency values < 0.
- Module-level shape tests in the validation notebook.

**Not yet validated (sandbox had no torch):**
- End-to-end training loop actually converges.
- Pretrain → LoRA transfer comparison produces sensible numbers.
- GPU execution.

Before a publication run, you should: (1) install torch, (2) run the validation notebook top-to-bottom,
(3) run `python run_evocrm.py --synthetic --quick` — if synthetic churn AUC comes in at 0.70–0.85 that's
healthy; if it's > 0.95, there's a leak somewhere (re-audit label and feature cutoff logic).

## Honest limitations

- **Hub averaging is pragmatic.** True multi-dataset joint pretraining requires a unified vocab + dataset-id
  embedding; the current "hub soup" averages weights across separately-trained source models.
- **Customer tower transfers imperfectly.** The FT-Transformer's feature tokenizer is per-feature-count;
  only hub weights transfer cleanly across datasets with different feature schemas.
- **LoRA surface is minimal.** Rank-8 on attention `out_proj` only. For large distribution shifts, wrap
  FFN layers too or switch to IA3.
- **Synthetic data is for smoke-testing.** Publication results require Olist + at least one transfer target.

## References

- Gorishniy et al. 2021, "Revisiting Deep Learning Models for Tabular Data" (FT-Transformer)
- Jaegle et al. 2021, "Perceiver IO: A General Architecture for Structured Inputs & Outputs"
- Hu et al. 2021, "LoRA: Low-Rank Adaptation of Large Language Models"
- Kendall et al. 2018, "Multi-Task Learning Using Uncertainty to Weigh Losses"
