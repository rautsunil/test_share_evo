"""Smoke test for modules that don't require torch."""
import sys
sys.path.insert(0, "/home/claude/evocrm_v2")

from evocrm.data import generate_synthetic_olist, EVOCRM_SCHEMA
from evocrm.labels import LabelingConfig, build_all_labels, suggest_cutoff

print("=" * 60)
print("1. Generate synthetic data")
print("=" * 60)
tables = generate_synthetic_olist(n_customers=300, n_products=50, seed=7)
for name, df in tables.items():
    expected = set(EVOCRM_SCHEMA[name])
    actual = set(df.columns)
    missing = expected - actual
    print(f"  {name}: shape={df.shape}, missing_cols={missing or 'none'}")
    assert not missing, f"missing columns in {name}: {missing}"

print()
print("=" * 60)
print("2. Build labels")
print("=" * 60)
cutoff = suggest_cutoff(tables["orders"], observation_days=90)
print(f"  suggested cutoff: {cutoff}")

cfg = LabelingConfig(cutoff_date=cutoff, observation_window_days=90)
labels = build_all_labels(
    tables["orders"], tables["order_items"],
    tables["products"], tables["customers"],
    cfg,
)
print(f"  labels shape: {labels.shape}")
print(f"  churn rate: {labels['churn'].mean():.3f}")
print(f"  churn_valid all True: {labels['churn_valid'].all()}")
print(f"  category valid rate: {labels['category_valid'].mean():.3f}")
print(f"  CLV mean (non-zero): {labels.loc[labels['clv']>0,'clv'].mean():.2f}")
print(f"  CLV zero rate: {(labels['clv']==0).mean():.3f}")

# Basic sanity: churn and CLV>0 should be mutually exclusive by construction
churners = labels[labels["churn"] == 1]
if len(churners) > 0:
    assert churners["clv"].max() == 0, "churners must have zero observation-window CLV"
print("  INVARIANT OK: churners have CLV=0")

# Check label distribution for category (among non-churners)
cat_counts = labels.loc[labels["category_valid"], "category"].value_counts().sort_index()
print(f"  category distribution (top 5): {dict(cat_counts.head())}")

print()
print("=" * 60)
print("3. Build features")
print("=" * 60)
from evocrm.features import (
    build_customer_features, build_interaction_sequences,
    assemble_feature_matrix,
)
cust_feats = build_customer_features(
    tables["orders"], tables["order_items"],
    tables["customers"], cutoff,
)
print(f"  customer features shape: {cust_feats.shape}")
print(f"  feature columns: {list(cust_feats.columns)}")
print(f"  recency stats: min={cust_feats['recency_days'].min():.0f}, "
      f"max={cust_feats['recency_days'].max():.0f}")

seq_data = build_interaction_sequences(
    tables["orders"], tables["order_items"],
    tables["customers"], cutoff, max_length=20,
)
print(f"  sequences: n_customers={len(seq_data.customer_ids)}, "
      f"L={seq_data.product_ids.shape[1] if len(seq_data.customer_ids) else 0}, "
      f"vocab={seq_data.product_id_vocab_size}")

# Alignment test
common = list(labels["customer_unique_id"].values[:50])
common = [c for c in common if c in cust_feats.index]
feat_mat = assemble_feature_matrix(cust_feats, seq_data, common)
print(f"  assembled: tabular={feat_mat['tabular'].shape}, "
      f"seq_pids={feat_mat['seq_pids'].shape}")

print()
print("=" * 60)
print("4. Leak test: verify no feature uses post-cutoff data")
print("=" * 60)
import pandas as pd
obs_end = cutoff + pd.Timedelta(days=90)

# Simulate leak: if a customer's recency is computed correctly, then
# recency = (cutoff - last_feature_window_order) should be >= 0 and
# no customer should have negative recency (which would mean post-cutoff leak)
assert (cust_feats["recency_days"] >= 0).all(), "NEGATIVE RECENCY = LEAK"
print("  ALL recency_days >= 0 (no post-cutoff data leaked into features)")

# Check that churners (who by def have no obs-window orders) still have
# the SAME feature-window behavior as non-churners at cutoff. I.e., the
# features can't distinguish them perfectly.
merged = labels.merge(cust_feats, on="customer_unique_id", how="inner")
ch_rec = merged.loc[merged["churn"] == 1, "recency_days"]
nc_rec = merged.loc[merged["churn"] == 0, "recency_days"]
print(f"  churner recency (mean): {ch_rec.mean():.1f}d")
print(f"  non-churner recency (mean): {nc_rec.mean():.1f}d")
# A diff is expected (higher-rate customers naturally have lower recency
# AND lower churn) — but not a perfect separation
print("  NOTE: a modest difference is signal, near-perfect separation is leak")

print()
print("ALL TORCH-FREE TESTS PASSED")
