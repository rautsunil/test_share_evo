const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  AlignmentType, PageOrientation, LevelFormat, HeadingLevel,
  BorderStyle, WidthType, ShadingType, PageNumber,
} = require('docx');
const fs = require('fs');

const border = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const borders = { top: border, bottom: border, left: border, right: border };
const headerShade = { fill: "1F3A5F", type: ShadingType.CLEAR };
const headerColor = "FFFFFF";

function p(text, opts = {}) {
  return new Paragraph({
    children: [new TextRun({ text, ...opts })],
    spacing: { after: 80 },
  });
}

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    children: [new TextRun({ text })],
  });
}

function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    children: [new TextRun({ text })],
  });
}

function bullet(text, boldPrefix) {
  const runs = [];
  if (boldPrefix) runs.push(new TextRun({ text: boldPrefix, bold: true }));
  runs.push(new TextRun({ text }));
  return new Paragraph({
    numbering: { reference: "bullets", level: 0 },
    children: runs,
    spacing: { after: 40 },
  });
}

function cell(text, { bold, bgColor, textColor, width } = {}) {
  return new TableCell({
    borders,
    width: { size: width, type: WidthType.DXA },
    shading: bgColor ? { fill: bgColor, type: ShadingType.CLEAR } : undefined,
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    children: [
      new Paragraph({
        children: [new TextRun({
          text, bold: !!bold,
          color: textColor,
          size: 18,
        })],
      }),
    ],
  });
}

// Architecture comparison table: XLNet (old) vs Perceiver+FT-T (new)
const archTable = new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: [2600, 3380, 3380],
  rows: [
    new TableRow({
      tableHeader: true,
      children: [
        cell("Component", { bold: true, bgColor: "1F3A5F", textColor: "FFFFFF", width: 2600 }),
        cell("EvoCRM v1 (deprecated)", { bold: true, bgColor: "1F3A5F", textColor: "FFFFFF", width: 3380 }),
        cell("EvoCRM v2 (this work)", { bold: true, bgColor: "1F3A5F", textColor: "FFFFFF", width: 3380 }),
      ],
    }),
    new TableRow({ children: [
      cell("Hub", { bold: true, width: 2600 }),
      cell("XLNet permutation LM + two-stream attention", { width: 3380 }),
      cell("Perceiver IO: learned latent array + cross-attention", { width: 3380, bgColor: "E8F0E8" }),
    ]}),
    new TableRow({ children: [
      cell("Customer Tower", { bold: true, width: 2600 }),
      cell("MLP + BatchNorm on raw features", { width: 3380 }),
      cell("FT-Transformer: per-feature tokenization + self-attn", { width: 3380, bgColor: "E8F0E8" }),
    ]}),
    new TableRow({ children: [
      cell("Task heads", { bold: true, width: 2600 }),
      cell("Six MLP heads on shared embedding", { width: 3380 }),
      cell("Output-query cross-attention (true spokes)", { width: 3380, bgColor: "E8F0E8" }),
    ]}),
    new TableRow({ children: [
      cell("Adaptation", { bold: true, width: 2600 }),
      cell("LoRA on unstated modules (narrative only)", { width: 3380 }),
      cell("LoRA on attention out_proj, base frozen", { width: 3380, bgColor: "E8F0E8" }),
    ]}),
    new TableRow({ children: [
      cell("Foundation claim", { bold: true, width: 2600 }),
      cell("Single-dataset multi-task (weak)", { width: 3380 }),
      cell("Multi-dataset pretrain + transfer eval", { width: 3380, bgColor: "E8F0E8" }),
    ]}),
  ],
});

// Task table
const taskTable = new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: [2200, 1800, 2500, 2860],
  rows: [
    new TableRow({ tableHeader: true, children: [
      cell("Task", { bold: true, bgColor: "1F3A5F", textColor: "FFFFFF", width: 2200 }),
      cell("Type", { bold: true, bgColor: "1F3A5F", textColor: "FFFFFF", width: 1800 }),
      cell("Label (post-cutoff)", { bold: true, bgColor: "1F3A5F", textColor: "FFFFFF", width: 2500 }),
      cell("Metric", { bold: true, bgColor: "1F3A5F", textColor: "FFFFFF", width: 2860 }),
    ]}),
    new TableRow({ children: [
      cell("Churn", { bold: true, width: 2200 }),
      cell("Binary", { width: 1800 }),
      cell("Zero orders in 90d observation window", { width: 2500 }),
      cell("AUC-ROC, F1, Accuracy", { width: 2860 }),
    ]}),
    new TableRow({ children: [
      cell("Next category", { bold: true, width: 2200 }),
      cell("Multi-class", { width: 1800 }),
      cell("Category of first post-cutoff order (top-K + 'other')", { width: 2500 }),
      cell("Macro-F1, Accuracy", { width: 2860 }),
    ]}),
    new TableRow({ children: [
      cell("CLV", { bold: true, width: 2200 }),
      cell("Regression", { width: 1800 }),
      cell("Revenue in 90d observation window (log1p-transformed)", { width: 2500 }),
      cell("RMSE, MAE", { width: 2860 }),
    ]}),
  ],
});

const children = [
  // Title
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 120 },
    children: [new TextRun({
      text: "EvoCRM v2: A Foundation Model for Customer Relationship Prediction",
      bold: true, size: 32, color: "1F3A5F",
    })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 240 },
    children: [new TextRun({
      text: "Perceiver IO hub · FT-Transformer towers · LoRA-based transfer · Leak-audited labels",
      italics: true, size: 20, color: "555555",
    })],
  }),

  // Overview
  h2("1. Problem and Thesis"),
  p("CRM prediction is typically tackled with one specialist model per task (churn classifier, CLV regressor, recommender, etc.), which duplicates feature engineering, wastes cross-task signal, and produces inconsistent customer representations. EvoCRM v2 proposes a single hub-and-spoke foundation model that jointly learns churn (binary), next-purchase category (multi-class), and customer lifetime value (regression) across multiple source datasets, then transfers to unseen target domains via parameter-efficient LoRA fine-tuning."),

  // Architecture
  h2("2. Architecture"),
  bullet("routes heterogeneous inputs (tabular RFM, interaction sequences, product-catalog) through a Perceiver IO latent array of size 64x128, decoupling input size from compute cost.", "Hub: "),
  bullet("is an FT-Transformer that tokenizes every numerical feature into a learned d-dimensional embedding, enabling self-attention to capture feature interactions natively.", "Customer Tower: "),
  bullet("embed variable-length interaction histories and static category signals, projected to the hub's input space.", "Interaction Tower + Catalog Tower: "),
  bullet("Each of the three task heads is an output query that cross-attends to the latent array; this makes the hub-and-spoke diagram architecturally literal rather than metaphorical.", "Spokes: "),
  bullet("applied to attention out_proj layers (rank-8) enable overnight adaptation on fresh outcome signals with the base model frozen.", "LoRA: "),
  archTable,

  // Tasks
  h2("3. Tasks and Temporal Discipline"),
  p("Every label is constructed strictly after a cutoff_date; every feature is constructed strictly before it. This closes the label-leakage failure mode observed in EvoCRM v1 (churn AUC of 0.99 traced to recency being computed over the observation window). Validation invariants enforced programmatically: (a) churners have CLV=0 by construction, (b) every recency value is >= 0, (c) category label is only valid for non-churners."),
  taskTable,

  // Datasets
  h2("4. Datasets"),
  p("Three sources for pretraining + transfer evaluation. Foundation-model status requires cross-dataset generalization; single-dataset evaluation was explicitly rejected."),
  bullet("Brazilian e-commerce. 99k customers, 100k orders, 32k products, real product-category text. Primary.", "Olist: "),
  bullet("Event-stream e-commerce. 1.4M users, sparse transactions. Tests transfer to a very different distribution.", "RetailRocket: "),
  bullet("deterministic synthetic generator (Poisson-rate per customer) for offline validation and unit tests; any AUC > 0.95 on synthetic is a leakage alarm.", "Synthetic Olist: "),

  // Contributions
  h2("5. Contributions"),
  bullet("The hub-and-spoke metaphor is realized architecturally: output queries cross-attend to a shared latent array, not just sharing an embedding.", "Architectural: "),
  bullet("Leak-audited label construction with programmatic invariants replaces the fragile informal convention used in v1.", "Methodological: "),
  bullet("Multi-dataset pretraining averaged over hub + FT-T weights (a 'hub soup'), followed by LoRA transfer with base frozen.", "Foundation-model: "),
  bullet("Against per-task classical specialists (GBM / RF / LogReg) on identical tabular features; against from-scratch and full-finetune variants.", "Empirical: "),

  // Experimental protocol
  h2("6. Experimental Protocol"),
  p("(a) Baseline: train EvoCRM from scratch on each target. (b) Transfer-LoRA: pretrain on other sources, freeze base, fine-tune rank-8 LoRA adapters on target. (c) Transfer-Full: pretrain + full fine-tune. Primary metric per task as above; paired bootstrap at 95% for significance. Expected healthy AUC range: 0.70–0.85; anything higher triggers the leakage audit."),

  // Limitations
  h2("7. Honest Limitations"),
  bullet("is a pragmatic approximation of true joint pretraining; a dataset-id embedding + unified sampling would be more principled (future work).", "Hub averaging "),
  bullet("weights are averaged via shape match only; datasets with different feature counts transfer only the hub, not the customer tower.", "FT-Transformer "),
  bullet("is rank-8 on attention out_proj only; higher-capacity adaptation (full LoRA or IA3) may be needed for large distribution shift.", "LoRA surface "),
];

const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 20 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, font: "Arial", color: "1F3A5F" },
        paragraph: { spacing: { before: 200, after: 120 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 22, bold: true, font: "Arial", color: "1F3A5F" },
        paragraph: { spacing: { before: 160, after: 80 }, outlineLevel: 1 } },
    ],
  },
  numbering: {
    config: [
      { reference: "bullets",
        levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 540, hanging: 270 } } } }] },
    ],
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 900, right: 1080, bottom: 900, left: 1080 },
      },
    },
    children,
  }],
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("/home/claude/evocrm_v2/EvoCRM_v2_Project_Document.docx", buffer);
  console.log("wrote EvoCRM_v2_Project_Document.docx");
});
