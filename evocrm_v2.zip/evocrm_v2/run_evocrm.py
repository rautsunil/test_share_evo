"""Run EvoCRM v2 end-to-end.

Usage:
    python run_evocrm.py --synthetic                 # uses synthetic data
    python run_evocrm.py --olist_dir /path/to/olist  # uses real Olist CSVs

Both modes run the full pipeline: labels → features → train → evaluate.
"""
from __future__ import annotations
import argparse
import sys
from evocrm.config import EvoCRMConfig
from evocrm.data import generate_synthetic_olist, load_olist
from evocrm.pipeline import run_pipeline


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--synthetic", action="store_true",
                   help="Use synthetic data (no downloads needed)")
    p.add_argument("--olist_dir", type=str, default=None,
                   help="Path to directory with real Olist CSVs")
    p.add_argument("--epochs", type=int, default=20)
    p.add_argument("--batch_size", type=int, default=128)
    p.add_argument("--n_customers", type=int, default=2000,
                   help="Only used with --synthetic")
    p.add_argument("--quick", action="store_true",
                   help="Tiny run for smoke testing")
    args = p.parse_args()

    if args.synthetic and args.olist_dir:
        sys.exit("Pass either --synthetic OR --olist_dir, not both.")
    if not (args.synthetic or args.olist_dir):
        sys.exit("Pass --synthetic or --olist_dir.")

    if args.synthetic:
        print("[run] generating synthetic Olist-shaped data...")
        tables = generate_synthetic_olist(
            n_customers=200 if args.quick else args.n_customers,
        )
    else:
        print(f"[run] loading real Olist data from {args.olist_dir}")
        tables = load_olist(args.olist_dir)

    config = EvoCRMConfig()
    config.training.num_epochs = 3 if args.quick else args.epochs
    config.training.batch_size = args.batch_size

    artifacts = run_pipeline(tables, config, verbose=True)
    print("[run] done.")
    return artifacts


if __name__ == "__main__":
    main()
