"""
EvoCRM Model - Updated for Real Data Integration

Changes from original implementation:
1. Customer Tower: Now accepts raw features (demographics + aggregated behavioral)
2. Interaction Tower: Handles merged event sequences from multiple sources
3. Product Tower: Uses learned embeddings when no product catalog available
4. Added integrated data processing pipeline

Author: EvoCRM Team
Updated: For real e-commerce data (Demographics, Transactions, Web, Campaigns)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from sklearn.preprocessing import LabelEncoder, StandardScaler
from datetime import datetime, timedelta


# ============================================================
# CONFIGURATION
# ============================================================

@dataclass
class EvoCRMConfig:
    """Configuration for EvoCRM model with real data."""
    
    # Customer Tower
    num_categorical_features: int = 5
    categorical_cardinalities: List[int] = field(default_factory=lambda: [50, 10, 5, 20, 10])
    num_numerical_features: int = 25
    categorical_embedding_dim: int = 16
    customer_hidden_dim: int = 256
    
    # Interaction Tower
    num_event_types: int = 10
    num_products: int = 1000
    max_sequence_length: int = 128
    event_embedding_dim: int = 32
    product_embedding_dim: int = 64
    interaction_hidden_dim: int = 256
    num_transformer_layers: int = 2
    num_attention_heads: int = 4
    
    # Product Tower (when no catalog available)
    use_product_catalog: bool = False  # Set True if you have product features
    product_hidden_dim: int = 256
    
    # Hub
    hub_dim: int = 768
    num_hub_layers: int = 4
    
    # Task Heads
    num_nba_classes: int = 8  # Next Best Action classes
    
    # Training
    dropout: float = 0.1
    
    # Data Processing
    churn_threshold_days: int = 90
    clv_horizon_days: int = 365


# ============================================================
# CUSTOMER TOWER (Updated for raw features)
# ============================================================

class CustomerTowerV2(nn.Module):
    """
    Updated Customer Tower that handles:
    - Demographics (categorical: city, age_group, gender, etc.)
    - Aggregated transaction features (RFM, spend patterns)
    - Aggregated web behavior (engagement metrics)
    - Aggregated campaign features (sparse, with fallback)
    
    Changes from original:
    - Separate embedding layers for known categorical features
    - Batch normalization for numerical features
    - Feature interaction via self-attention
    """
    
    def __init__(self, config: EvoCRMConfig):
        super().__init__()
        self.config = config
        
        # Categorical embeddings (one per feature)
        self.categorical_embeddings = nn.ModuleList([
            nn.Embedding(cardinality + 1, config.categorical_embedding_dim, padding_idx=0)
            for cardinality in config.categorical_cardinalities
        ])
        
        # Numerical encoder
        self.numerical_bn = nn.BatchNorm1d(config.num_numerical_features)
        self.numerical_encoder = nn.Sequential(
            nn.Linear(config.num_numerical_features, config.customer_hidden_dim),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.customer_hidden_dim, config.customer_hidden_dim),
            nn.LayerNorm(config.customer_hidden_dim)
        )
        
        # Categorical aggregator
        total_cat_dim = len(config.categorical_cardinalities) * config.categorical_embedding_dim
        self.categorical_aggregator = nn.Sequential(
            nn.Linear(total_cat_dim, config.customer_hidden_dim),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.LayerNorm(config.customer_hidden_dim)
        )
        
        # Feature interaction (combines categorical + numerical)
        self.feature_interaction = nn.MultiheadAttention(
            embed_dim=config.customer_hidden_dim,
            num_heads=4,
            dropout=config.dropout,
            batch_first=True
        )
        
        # Output projection
        self.output_projection = nn.Sequential(
            nn.Linear(config.customer_hidden_dim * 2, config.customer_hidden_dim),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.LayerNorm(config.customer_hidden_dim)
        )
    
    def forward(
        self,
        categorical_features: torch.Tensor,  # (batch, num_cat_features)
        numerical_features: torch.Tensor,    # (batch, num_num_features)
    ) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            categorical_features: Encoded categorical features (demographics, etc.)
            numerical_features: Numerical features (RFM, spend, engagement, etc.)
        
        Returns:
            Customer embedding of shape (batch, customer_hidden_dim)
        """
        batch_size = categorical_features.size(0)
        
        # Embed categorical features
        cat_embeddings = []
        for i, embed_layer in enumerate(self.categorical_embeddings):
            cat_embeddings.append(embed_layer(categorical_features[:, i]))
        
        cat_concat = torch.cat(cat_embeddings, dim=-1)  # (batch, total_cat_dim)
        cat_hidden = self.categorical_aggregator(cat_concat)  # (batch, hidden_dim)
        
        # Encode numerical features
        num_normalized = self.numerical_bn(numerical_features)
        num_hidden = self.numerical_encoder(num_normalized)  # (batch, hidden_dim)
        
        # Feature interaction via attention
        # Stack as sequence of 2 tokens: [categorical, numerical]
        combined = torch.stack([cat_hidden, num_hidden], dim=1)  # (batch, 2, hidden_dim)
        
        attended, _ = self.feature_interaction(combined, combined, combined)
        
        # Aggregate attended features
        attended_pooled = attended.mean(dim=1)  # (batch, hidden_dim)
        
        # Final output
        output = self.output_projection(
            torch.cat([attended_pooled, num_hidden], dim=-1)
        )
        
        return output


# ============================================================
# INTERACTION TOWER (Updated for merged sequences)
# ============================================================

class InteractionTowerV2(nn.Module):
    """
    Updated Interaction Tower that handles:
    - Merged event sequences from Transactions + Web + Campaigns
    - Event type embeddings
    - Product embeddings (learned, not from catalog)
    - Temporal encoding (time deltas between events)
    
    Changes from original:
    - Added temporal encoding for time deltas
    - Handles sparse campaign events gracefully
    - Uses causal attention for sequence modeling
    """
    
    def __init__(self, config: EvoCRMConfig):
        super().__init__()
        self.config = config
        
        # Event type embedding
        self.event_embedding = nn.Embedding(
            config.num_event_types + 1,  # +1 for padding
            config.event_embedding_dim,
            padding_idx=0
        )
        
        # Product embedding (learned from interactions)
        self.product_embedding = nn.Embedding(
            config.num_products + 1,  # +1 for padding
            config.product_embedding_dim,
            padding_idx=0
        )
        
        # Temporal encoding (for time deltas)
        self.time_encoder = nn.Sequential(
            nn.Linear(1, 32),
            nn.GELU(),
            nn.Linear(32, 32)
        )
        
        # Positional encoding
        self.position_embedding = nn.Embedding(
            config.max_sequence_length,
            config.event_embedding_dim + config.product_embedding_dim + 32
        )
        
        # Combined dimension
        combined_dim = config.event_embedding_dim + config.product_embedding_dim + 32
        
        # Project to hidden dimension
        self.input_projection = nn.Linear(combined_dim, config.interaction_hidden_dim)
        
        # Transformer layers with causal attention
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=config.interaction_hidden_dim,
            nhead=config.num_attention_heads,
            dim_feedforward=config.interaction_hidden_dim * 4,
            dropout=config.dropout,
            activation='gelu',
            batch_first=True
        )
        self.transformer = nn.TransformerEncoder(
            encoder_layer,
            num_layers=config.num_transformer_layers
        )
        
        # Output projection
        self.output_projection = nn.Sequential(
            nn.Linear(config.interaction_hidden_dim, config.interaction_hidden_dim),
            nn.GELU(),
            nn.LayerNorm(config.interaction_hidden_dim)
        )
    
    def forward(
        self,
        event_sequences: torch.Tensor,    # (batch, seq_len) - encoded event types
        product_sequences: torch.Tensor,  # (batch, seq_len) - encoded product IDs
        time_deltas: torch.Tensor,        # (batch, seq_len) - days between events
        attention_mask: torch.Tensor,     # (batch, seq_len) - 1 for valid, 0 for padding
    ) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            event_sequences: Encoded event types
            product_sequences: Encoded product IDs
            time_deltas: Days between consecutive events
            attention_mask: Mask for valid positions
        
        Returns:
            Sequence embedding of shape (batch, interaction_hidden_dim)
        """
        batch_size, seq_len = event_sequences.shape
        device = event_sequences.device
        
        # Embed events and products
        event_embed = self.event_embedding(event_sequences)  # (batch, seq, event_dim)
        product_embed = self.product_embedding(product_sequences)  # (batch, seq, product_dim)
        
        # Encode time deltas
        time_embed = self.time_encoder(time_deltas.unsqueeze(-1))  # (batch, seq, 32)
        
        # Combine embeddings
        combined = torch.cat([event_embed, product_embed, time_embed], dim=-1)
        
        # Add positional encoding
        positions = torch.arange(seq_len, device=device).unsqueeze(0).expand(batch_size, -1)
        combined = combined + self.position_embedding(positions)
        
        # Project to hidden dimension
        hidden = self.input_projection(combined)
        
        # Create causal mask
        causal_mask = torch.triu(
            torch.ones(seq_len, seq_len, device=device), diagonal=1
        ).bool()
        
        # Create padding mask (True = ignore)
        padding_mask = (attention_mask == 0)
        
        # Transformer encoding
        encoded = self.transformer(
            hidden,
            mask=causal_mask,
            src_key_padding_mask=padding_mask
        )
        
        # Pool sequence (mean of valid positions)
        mask_expanded = attention_mask.unsqueeze(-1).float()
        pooled = (encoded * mask_expanded).sum(dim=1) / (mask_expanded.sum(dim=1) + 1e-8)
        
        # Output projection
        output = self.output_projection(pooled)
        
        return output


# ============================================================
# PRODUCT TOWER (Simplified - no catalog)
# ============================================================

class ProductTowerV2(nn.Module):
    """
    Simplified Product Tower when no product catalog is available.
    
    Uses learned embeddings from interaction history instead of
    explicit product features.
    
    If you have a product catalog, you can extend this to include:
    - Category embeddings
    - Price features
    - Text descriptions (via Sentence-BERT)
    """
    
    def __init__(self, config: EvoCRMConfig):
        super().__init__()
        self.config = config
        
        # Shared product embedding (same as Interaction Tower)
        self.product_embedding = nn.Embedding(
            config.num_products + 1,
            config.product_hidden_dim,
            padding_idx=0
        )
        
        # If product catalog is available, add feature encoders here
        if config.use_product_catalog:
            # Placeholder - extend when you have product features
            self.category_embedding = nn.Embedding(100, 32)
            self.price_encoder = nn.Linear(1, 32)
            self.feature_fusion = nn.Linear(
                config.product_hidden_dim + 32 + 32,
                config.product_hidden_dim
            )
    
    def forward(
        self,
        product_ids: torch.Tensor,  # (batch,) or (batch, num_products)
        product_features: Optional[Dict[str, torch.Tensor]] = None
    ) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            product_ids: Product IDs to embed
            product_features: Optional dict with category, price, etc.
        
        Returns:
            Product embedding(s)
        """
        embed = self.product_embedding(product_ids)
        
        if self.config.use_product_catalog and product_features is not None:
            # Fuse with product features
            cat_embed = self.category_embedding(product_features['category'])
            price_embed = self.price_encoder(product_features['price'].unsqueeze(-1))
            combined = torch.cat([embed, cat_embed, price_embed], dim=-1)
            embed = self.feature_fusion(combined)
        
        return embed


# ============================================================
# HUB (Cross-Modal Fusion) - Minimal changes
# ============================================================

class HubV2(nn.Module):
    """
    Hub for cross-modal fusion.
    
    Combines embeddings from:
    - Customer Tower (static + aggregated features)
    - Interaction Tower (sequential behavior)
    - Product Tower (for recommendations)
    
    Uses dynamic modality gating to weight different sources.
    """
    
    def __init__(self, config: EvoCRMConfig):
        super().__init__()
        self.config = config
        
        # Input dimensions from each tower
        customer_dim = config.customer_hidden_dim
        interaction_dim = config.interaction_hidden_dim
        product_dim = config.product_hidden_dim
        
        # Project all modalities to hub dimension
        self.customer_projection = nn.Linear(customer_dim, config.hub_dim)
        self.interaction_projection = nn.Linear(interaction_dim, config.hub_dim)
        self.product_projection = nn.Linear(product_dim, config.hub_dim)
        
        # Modality type embeddings
        self.modality_embeddings = nn.Embedding(3, config.hub_dim)
        
        # Dynamic gating
        self.gate_network = nn.Sequential(
            nn.Linear(config.hub_dim * 3, 128),
            nn.GELU(),
            nn.Linear(128, 3),
            nn.Softmax(dim=-1)
        )
        
        # Cross-modal attention
        self.cross_attention = nn.MultiheadAttention(
            embed_dim=config.hub_dim,
            num_heads=8,
            dropout=config.dropout,
            batch_first=True
        )
        
        # Fusion transformer
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=config.hub_dim,
            nhead=8,
            dim_feedforward=config.hub_dim * 4,
            dropout=config.dropout,
            activation='gelu',
            batch_first=True
        )
        self.fusion_transformer = nn.TransformerEncoder(
            encoder_layer,
            num_layers=config.num_hub_layers
        )
        
        # Output layer norm
        self.output_norm = nn.LayerNorm(config.hub_dim)
    
    def forward(
        self,
        customer_embedding: torch.Tensor,     # (batch, customer_dim)
        interaction_embedding: torch.Tensor,  # (batch, interaction_dim)
        product_embedding: Optional[torch.Tensor] = None,  # (batch, product_dim)
    ) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            customer_embedding: From Customer Tower
            interaction_embedding: From Interaction Tower
            product_embedding: From Product Tower (optional for some tasks)
        
        Returns:
            Unified embedding of shape (batch, hub_dim)
        """
        batch_size = customer_embedding.size(0)
        device = customer_embedding.device
        
        # Project all modalities
        customer_proj = self.customer_projection(customer_embedding)
        interaction_proj = self.interaction_projection(interaction_embedding)
        
        if product_embedding is not None:
            product_proj = self.product_projection(product_embedding)
        else:
            # Use zero vector if no product context
            product_proj = torch.zeros(batch_size, self.config.hub_dim, device=device)
        
        # Add modality embeddings
        modality_ids = torch.arange(3, device=device)
        modality_embeds = self.modality_embeddings(modality_ids)
        
        customer_proj = customer_proj + modality_embeds[0]
        interaction_proj = interaction_proj + modality_embeds[1]
        product_proj = product_proj + modality_embeds[2]
        
        # Stack as sequence
        stacked = torch.stack([customer_proj, interaction_proj, product_proj], dim=1)
        
        # Dynamic gating
        gate_input = torch.cat([customer_proj, interaction_proj, product_proj], dim=-1)
        gates = self.gate_network(gate_input)  # (batch, 3)
        
        # Apply gates
        gated = stacked * gates.unsqueeze(-1)
        
        # Cross-modal attention
        attended, _ = self.cross_attention(gated, gated, gated)
        
        # Fusion transformer
        fused = self.fusion_transformer(attended)
        
        # Pool and normalize
        output = fused.mean(dim=1)
        output = self.output_norm(output)
        
        return output


# ============================================================
# TASK HEADS (Updated with your tasks)
# ============================================================

class TaskHeadsV2(nn.Module):
    """
    Task heads for all CRM tasks.
    
    Tasks:
    1. Churn Prediction (Binary)
    2. CLV Estimation (Regression)
    3. Upsell Detection (Binary)
    4. Cross-sell Detection (Multi-label)
    5. Next Best Action (Multi-class)
    6. Early Adopter Score (Regression)
    7. Product Recommendations (Contrastive)
    """
    
    def __init__(self, config: EvoCRMConfig):
        super().__init__()
        self.config = config
        
        hub_dim = config.hub_dim
        
        # Churn Prediction
        self.churn_head = nn.Sequential(
            nn.Linear(hub_dim, 256),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(256, 1)
        )
        
        # CLV Estimation
        self.clv_head = nn.Sequential(
            nn.Linear(hub_dim, 256),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(256, 1),
            nn.Softplus()  # Ensure positive output
        )
        
        # Upsell Detection
        self.upsell_head = nn.Sequential(
            nn.Linear(hub_dim, 256),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(256, 1)
        )
        
        # Cross-sell Detection (multi-label for product categories)
        self.crosssell_head = nn.Sequential(
            nn.Linear(hub_dim, 256),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(256, 10)  # Assuming 10 product categories
        )
        
        # Next Best Action
        self.nba_head = nn.Sequential(
            nn.Linear(hub_dim, 256),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(256, config.num_nba_classes)
        )
        
        # Early Adopter Score
        self.early_adopter_head = nn.Sequential(
            nn.Linear(hub_dim, 128),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(128, 1),
            nn.Sigmoid()  # 0-1 score
        )
        
        # Days Until Next Purchase
        self.next_purchase_head = nn.Sequential(
            nn.Linear(hub_dim, 256),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(256, 1),
            nn.Softplus()  # Ensure positive
        )
        
        # Recommendation Head (for contrastive learning)
        self.recommendation_head = nn.Sequential(
            nn.Linear(hub_dim, 256),
            nn.GELU(),
            nn.Linear(256, 128)  # Embedding for contrastive loss
        )
    
    def forward(
        self,
        unified_embedding: torch.Tensor,
        tasks: List[str] = None
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass for specified tasks.
        
        Args:
            unified_embedding: Output from Hub (batch, hub_dim)
            tasks: List of tasks to compute (None = all)
        
        Returns:
            Dictionary of task outputs
        """
        if tasks is None:
            tasks = ['churn', 'clv', 'upsell', 'crosssell', 'nba', 
                     'early_adopter', 'next_purchase', 'recommendation']
        
        outputs = {}
        
        if 'churn' in tasks:
            outputs['churn'] = self.churn_head(unified_embedding).squeeze(-1)
        
        if 'clv' in tasks:
            outputs['clv'] = self.clv_head(unified_embedding).squeeze(-1)
        
        if 'upsell' in tasks:
            outputs['upsell'] = self.upsell_head(unified_embedding).squeeze(-1)
        
        if 'crosssell' in tasks:
            outputs['crosssell'] = self.crosssell_head(unified_embedding)
        
        if 'nba' in tasks:
            outputs['nba'] = self.nba_head(unified_embedding)
        
        if 'early_adopter' in tasks:
            outputs['early_adopter'] = self.early_adopter_head(unified_embedding).squeeze(-1)
        
        if 'next_purchase' in tasks:
            outputs['next_purchase'] = self.next_purchase_head(unified_embedding).squeeze(-1)
        
        if 'recommendation' in tasks:
            outputs['recommendation'] = self.recommendation_head(unified_embedding)
        
        return outputs


# ============================================================
# MAIN EVOCRM MODEL (Integrated)
# ============================================================

class EvoCRMV2(nn.Module):
    """
    EvoCRM Foundation Model - Version 2
    
    Updated to work directly with real e-commerce data:
    - Demographics table
    - Transactions table
    - Web behavior table
    - Campaigns table (sparse)
    
    Architecture:
    - Customer Tower: Static + aggregated features
    - Interaction Tower: Merged event sequences
    - Product Tower: Learned embeddings (no catalog needed)
    - Hub: Cross-modal fusion
    - Task Heads: All CRM tasks
    """
    
    def __init__(self, config: EvoCRMConfig):
        super().__init__()
        self.config = config
        
        # Towers
        self.customer_tower = CustomerTowerV2(config)
        self.interaction_tower = InteractionTowerV2(config)
        self.product_tower = ProductTowerV2(config)
        
        # Hub
        self.hub = HubV2(config)
        
        # Task Heads
        self.task_heads = TaskHeadsV2(config)
    
    def forward(
        self,
        # Customer Tower inputs
        categorical_features: torch.Tensor,
        numerical_features: torch.Tensor,
        # Interaction Tower inputs
        event_sequences: torch.Tensor,
        product_sequences: torch.Tensor,
        time_deltas: torch.Tensor,
        attention_mask: torch.Tensor,
        # Product Tower inputs (optional)
        target_product_ids: Optional[torch.Tensor] = None,
        # Task specification
        tasks: List[str] = None
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass through entire model.
        
        Args:
            categorical_features: (batch, num_cat) - demographics, etc.
            numerical_features: (batch, num_num) - RFM, spend, engagement
            event_sequences: (batch, seq_len) - encoded event types
            product_sequences: (batch, seq_len) - encoded product IDs
            time_deltas: (batch, seq_len) - days between events
            attention_mask: (batch, seq_len) - valid positions
            target_product_ids: (batch,) - for recommendation task
            tasks: List of tasks to compute
        
        Returns:
            Dictionary with task predictions
        """
        # Customer Tower
        customer_embedding = self.customer_tower(
            categorical_features, numerical_features
        )
        
        # Interaction Tower
        interaction_embedding = self.interaction_tower(
            event_sequences, product_sequences, time_deltas, attention_mask
        )
        
        # Product Tower (if target products provided)
        if target_product_ids is not None:
            product_embedding = self.product_tower(target_product_ids)
        else:
            product_embedding = None
        
        # Hub (cross-modal fusion)
        unified_embedding = self.hub(
            customer_embedding, interaction_embedding, product_embedding
        )
        
        # Task Heads
        outputs = self.task_heads(unified_embedding, tasks)
        
        # Also return intermediate embeddings (useful for debugging/analysis)
        outputs['customer_embedding'] = customer_embedding
        outputs['interaction_embedding'] = interaction_embedding
        outputs['unified_embedding'] = unified_embedding
        
        return outputs
    
    def get_user_embedding(
        self,
        categorical_features: torch.Tensor,
        numerical_features: torch.Tensor,
        event_sequences: torch.Tensor,
        product_sequences: torch.Tensor,
        time_deltas: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> torch.Tensor:
        """
        Get unified user embedding without task heads.
        
        Useful for:
        - Similarity search
        - Clustering
        - Downstream tasks
        """
        customer_embedding = self.customer_tower(
            categorical_features, numerical_features
        )
        
        interaction_embedding = self.interaction_tower(
            event_sequences, product_sequences, time_deltas, attention_mask
        )
        
        unified_embedding = self.hub(
            customer_embedding, interaction_embedding, None
        )
        
        return unified_embedding
    
    def compute_recommendation_score(
        self,
        user_embedding: torch.Tensor,
        product_ids: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute recommendation scores for user-product pairs.
        
        Args:
            user_embedding: (batch, hub_dim) - from get_user_embedding
            product_ids: (batch, num_products) - candidate products
        
        Returns:
            Scores of shape (batch, num_products)
        """
        # Get product embeddings
        product_embeds = self.product_tower(product_ids)  # (batch, num_products, product_dim)
        
        # Project user embedding for comparison
        user_proj = self.task_heads.recommendation_head(user_embedding)  # (batch, 128)
        
        # Project products
        product_proj = self.product_tower.product_embedding(product_ids)
        
        # Compute scores (dot product)
        scores = torch.bmm(
            product_proj, 
            user_proj.unsqueeze(-1)
        ).squeeze(-1)
        
        return scores


# ============================================================
# LOSS FUNCTIONS
# ============================================================

class EvoCRMMultiTaskLoss(nn.Module):
    """
    Multi-task loss for EvoCRM.
    
    Combines losses from all tasks with learnable weights.
    """
    
    def __init__(self, task_weights: Optional[Dict[str, float]] = None):
        super().__init__()
        
        self.task_weights = task_weights or {
            'churn': 1.0,
            'clv': 0.5,
            'upsell': 1.0,
            'nba': 1.0,
            'next_purchase': 0.5,
        }
        
        # Learnable uncertainty weights (homoscedastic uncertainty)
        self.log_vars = nn.ParameterDict({
            task: nn.Parameter(torch.zeros(1))
            for task in self.task_weights.keys()
        })
    
    def forward(
        self,
        predictions: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor]
    ) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        Compute multi-task loss.
        
        Args:
            predictions: Model outputs
            targets: Ground truth labels
        
        Returns:
            Total loss and per-task losses
        """
        losses = {}
        total_loss = 0
        
        # Churn loss (binary cross-entropy)
        if 'churn' in predictions and 'churn' in targets:
            churn_loss = F.binary_cross_entropy_with_logits(
                predictions['churn'],
                targets['churn'].float()
            )
            precision = torch.exp(-self.log_vars['churn'])
            losses['churn'] = churn_loss
            total_loss = total_loss + precision * churn_loss + self.log_vars['churn']
        
        # CLV loss (MSE or Huber)
        if 'clv' in predictions and 'clv' in targets:
            # Log-transform CLV for better training
            clv_pred = predictions['clv']
            clv_target = targets['clv'].float()
            
            clv_loss = F.huber_loss(
                torch.log1p(clv_pred),
                torch.log1p(clv_target)
            )
            precision = torch.exp(-self.log_vars['clv'])
            losses['clv'] = clv_loss
            total_loss = total_loss + precision * clv_loss + self.log_vars['clv']
        
        # Upsell loss (binary cross-entropy)
        if 'upsell' in predictions and 'upsell' in targets:
            upsell_loss = F.binary_cross_entropy_with_logits(
                predictions['upsell'],
                targets['upsell'].float()
            )
            precision = torch.exp(-self.log_vars['upsell'])
            losses['upsell'] = upsell_loss
            total_loss = total_loss + precision * upsell_loss + self.log_vars['upsell']
        
        # NBA loss (cross-entropy)
        if 'nba' in predictions and 'nba' in targets:
            nba_loss = F.cross_entropy(
                predictions['nba'],
                targets['nba'].long()
            )
            precision = torch.exp(-self.log_vars['nba'])
            losses['nba'] = nba_loss
            total_loss = total_loss + precision * nba_loss + self.log_vars['nba']
        
        # Next purchase loss (MSE)
        if 'next_purchase' in predictions and 'next_purchase' in targets:
            np_loss = F.mse_loss(
                predictions['next_purchase'],
                targets['next_purchase'].float()
            )
            precision = torch.exp(-self.log_vars['next_purchase'])
            losses['next_purchase'] = np_loss
            total_loss = total_loss + precision * np_loss + self.log_vars['next_purchase']
        
        return total_loss, losses


# ============================================================
# EXAMPLE USAGE
# ============================================================

if __name__ == "__main__":
    # Configuration
    config = EvoCRMConfig(
        num_categorical_features=5,
        categorical_cardinalities=[50, 10, 5, 20, 10],  # city, age_group, gender, channel, region
        num_numerical_features=25,
        num_event_types=10,
        num_products=500,
        max_sequence_length=128,
    )
    
    # Create model
    model = EvoCRMV2(config)
    
    # Sample batch
    batch_size = 32
    
    categorical_features = torch.randint(0, 10, (batch_size, 5))
    numerical_features = torch.randn(batch_size, 25)
    event_sequences = torch.randint(0, 10, (batch_size, 128))
    product_sequences = torch.randint(0, 500, (batch_size, 128))
    time_deltas = torch.rand(batch_size, 128) * 30
    attention_mask = torch.ones(batch_size, 128)
    
    # Forward pass
    outputs = model(
        categorical_features=categorical_features,
        numerical_features=numerical_features,
        event_sequences=event_sequences,
        product_sequences=product_sequences,
        time_deltas=time_deltas,
        attention_mask=attention_mask,
        tasks=['churn', 'clv', 'upsell', 'nba']
    )
    
    print("Model Output Shapes:")
    for key, value in outputs.items():
        if isinstance(value, torch.Tensor):
            print(f"  {key}: {value.shape}")
    
    # Count parameters
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    
    print(f"\nModel Parameters:")
    print(f"  Total: {total_params:,}")
    print(f"  Trainable: {trainable_params:,}")
