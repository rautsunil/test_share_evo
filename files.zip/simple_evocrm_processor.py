"""
EvoCRM Data Pipeline - Simplified Version

Maps your 4 tables to EvoCRM Foundation Model:
1. Demographics → Customer Tower (static features)
2. Transactions → Customer Tower (aggregated) + Interaction Tower (sequences)
3. Web Behavior → Customer Tower (aggregated) + Interaction Tower (sequences)
4. Campaigns (sparse) → Customer Tower (aggregated) + Interaction Tower (sequences)

Usage:
    processor = SimpleEvoCRMProcessor(
        demographics_df,
        transactions_df,
        web_behavior_df,
        campaigns_df  # Optional, sparse
    )
    evocrm_data = processor.process()
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from sklearn.preprocessing import LabelEncoder, StandardScaler
from datetime import datetime, timedelta
from collections import defaultdict


class SimpleEvoCRMProcessor:
    """
    Simple, practical data processor for EvoCRM.
    
    Takes your 4 tables and outputs model-ready data.
    """
    
    def __init__(
        self,
        demographics: pd.DataFrame,
        transactions: pd.DataFrame,
        web_behavior: pd.DataFrame,
        campaigns: Optional[pd.DataFrame] = None,
        config: Optional[Dict] = None
    ):
        """
        Initialize with your data tables.
        
        Expected columns:
        - demographics: user_id, age, city, [gender, registration_date, ...]
        - transactions: user_id, product_id, timestamp, amount, [quantity, ...]
        - web_behavior: user_id, product_id, event_type, timestamp, [session_id, ...]
        - campaigns: user_id, campaign_id, clicked, timestamp (SPARSE - OK if missing!)
        """
        self.demographics = demographics.copy()
        self.transactions = transactions.copy()
        self.web_behavior = web_behavior.copy()
        self.campaigns = campaigns.copy() if campaigns is not None else None
        
        # Default configuration
        self.config = config or {
            'max_sequence_length': 128,
            'churn_threshold_days': 90,
            'reference_date': None,  # Will auto-detect
        }
        
        # Auto-detect reference date
        if self.config['reference_date'] is None:
            self.config['reference_date'] = self._get_max_date()
        
        self.reference_date = pd.to_datetime(self.config['reference_date'])
        
        # Storage for encoders
        self.encoders = {}
        self.scalers = {}
        
        print("="*60)
        print("EvoCRM Data Processor Initialized")
        print("="*60)
        print(f"Demographics: {len(demographics):,} users")
        print(f"Transactions: {len(transactions):,} records")
        print(f"Web Behavior: {len(web_behavior):,} events")
        if campaigns is not None:
            print(f"Campaigns: {len(campaigns):,} records (sparse)")
        print(f"Reference Date: {self.reference_date.date()}")
    
    def _get_max_date(self) -> datetime:
        """Get max date from data."""
        dates = []
        for df, col in [(self.transactions, 'timestamp'), 
                        (self.web_behavior, 'timestamp')]:
            if col in df.columns:
                dates.append(pd.to_datetime(df[col]).max())
        return max(dates) if dates else datetime.now()
    
    # ================================================================
    # MAIN PROCESSING PIPELINE
    # ================================================================
    
    def process(
        self,
        user_id_col: str = 'user_id',
        verbose: bool = True
    ) -> Dict:
        """
        Main processing pipeline.
        
        Returns:
            Dictionary with:
            - customer_features: DataFrame with all user-level features
            - interaction_sequences: Dict with sequences for Interaction Tower
            - targets: Dict with target variables
            - metadata: Feature information
        """
        
        # Step 1: Process Demographics
        if verbose: print("\n[1/6] Processing Demographics...")
        demo_features = self._process_demographics(user_id_col)
        
        # Step 2: Aggregate Transactions
        if verbose: print("[2/6] Aggregating Transactions...")
        txn_features = self._aggregate_transactions(user_id_col)
        
        # Step 3: Aggregate Web Behavior
        if verbose: print("[3/6] Aggregating Web Behavior...")
        web_features = self._aggregate_web_behavior(user_id_col)
        
        # Step 4: Aggregate Campaigns (handle sparsity)
        if verbose: print("[4/6] Aggregating Campaigns (sparse)...")
        campaign_features = self._aggregate_campaigns(user_id_col)
        
        # Step 5: Build Interaction Sequences
        if verbose: print("[5/6] Building Interaction Sequences...")
        sequences = self._build_sequences(user_id_col)
        
        # Step 6: Calculate Targets
        if verbose: print("[6/6] Calculating Target Variables...")
        targets = self._calculate_targets(user_id_col)
        
        # Combine all features
        if verbose: print("\nCombining all features...")
        customer_features = self._combine_features(
            demo_features, txn_features, web_features, campaign_features, targets
        )
        
        # Prepare final output
        result = self._prepare_output(customer_features, sequences)
        
        if verbose:
            print("\n" + "="*60)
            print("PROCESSING COMPLETE")
            print("="*60)
            print(f"Users: {result['metadata']['num_users']:,}")
            print(f"Features: {result['metadata']['num_features']}")
            print(f"Sequence length: {result['metadata']['max_sequence_length']}")
            print(f"Event types: {result['metadata']['num_event_types']}")
        
        return result
    
    # ================================================================
    # STEP 1: DEMOGRAPHICS
    # ================================================================
    
    def _process_demographics(self, user_id_col: str) -> pd.DataFrame:
        """Process demographics table."""
        df = self.demographics.copy()
        result = pd.DataFrame({user_id_col: df[user_id_col]})
        
        # Detect and process columns
        for col in df.columns:
            if col == user_id_col:
                continue
            
            # Categorical columns
            if df[col].dtype == 'object' or df[col].nunique() < 20:
                encoder = LabelEncoder()
                result[f'demo_{col}'] = encoder.fit_transform(
                    df[col].fillna('UNKNOWN').astype(str)
                )
                self.encoders[f'demo_{col}'] = encoder
            
            # Numerical columns
            elif np.issubdtype(df[col].dtype, np.number):
                result[f'demo_{col}'] = df[col].fillna(df[col].median())
            
            # Datetime columns
            elif pd.api.types.is_datetime64_any_dtype(df[col]):
                result[f'demo_{col}_days'] = (
                    self.reference_date - pd.to_datetime(df[col])
                ).dt.days.fillna(0)
        
        return result
    
    # ================================================================
    # STEP 2: TRANSACTIONS
    # ================================================================
    
    def _aggregate_transactions(self, user_id_col: str) -> pd.DataFrame:
        """Aggregate transactions to user level."""
        df = self.transactions.copy()
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        
        # Basic aggregations
        agg = df.groupby(user_id_col).agg({
            'timestamp': ['min', 'max', 'count'],
            'amount': ['sum', 'mean', 'std', 'min', 'max'],
            'product_id': 'nunique'
        })
        agg.columns = [
            'first_purchase', 'last_purchase', 'total_orders',
            'total_spend', 'avg_order_value', 'order_std', 'min_order', 'max_order',
            'unique_products_purchased'
        ]
        agg = agg.reset_index()
        
        # Fill NaN std
        agg['order_std'] = agg['order_std'].fillna(0)
        
        # RFM Features
        agg['recency_days'] = (self.reference_date - agg['last_purchase']).dt.days
        agg['tenure_days'] = (self.reference_date - agg['first_purchase']).dt.days
        agg['frequency'] = agg['total_orders'] / (agg['tenure_days'] / 30 + 1)
        
        # Recent activity
        for days in [30, 60, 90]:
            cutoff = self.reference_date - timedelta(days=days)
            recent = df[df['timestamp'] >= cutoff].groupby(user_id_col).agg({
                'amount': 'sum',
                'timestamp': 'count'
            }).reset_index()
            recent.columns = [user_id_col, f'spend_last_{days}d', f'orders_last_{days}d']
            agg = agg.merge(recent, on=user_id_col, how='left')
            agg[f'spend_last_{days}d'] = agg[f'spend_last_{days}d'].fillna(0)
            agg[f'orders_last_{days}d'] = agg[f'orders_last_{days}d'].fillna(0)
        
        # Drop datetime columns
        agg = agg.drop(columns=['first_purchase', 'last_purchase'])
        
        return agg
    
    # ================================================================
    # STEP 3: WEB BEHAVIOR
    # ================================================================
    
    def _aggregate_web_behavior(self, user_id_col: str) -> pd.DataFrame:
        """Aggregate web behavior to user level."""
        df = self.web_behavior.copy()
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        
        # Basic aggregations
        agg = df.groupby(user_id_col).agg({
            'timestamp': ['min', 'max', 'count'],
            'product_id': 'nunique'
        })
        agg.columns = ['first_web', 'last_web', 'total_web_events', 'unique_products_viewed']
        agg = agg.reset_index()
        
        # Web recency
        agg['web_recency_days'] = (self.reference_date - agg['last_web']).dt.days
        
        # Event type counts
        event_counts = df.pivot_table(
            index=user_id_col,
            columns='event_type',
            values='timestamp',
            aggfunc='count',
            fill_value=0
        ).reset_index()
        event_counts.columns = [user_id_col] + [f'event_{c}_count' for c in event_counts.columns[1:]]
        
        agg = agg.merge(event_counts, on=user_id_col, how='left')
        
        # Recent activity
        cutoff = self.reference_date - timedelta(days=30)
        recent = df[df['timestamp'] >= cutoff].groupby(user_id_col).agg({
            'timestamp': 'count',
            'product_id': 'nunique'
        }).reset_index()
        recent.columns = [user_id_col, 'web_events_last_30d', 'products_viewed_last_30d']
        agg = agg.merge(recent, on=user_id_col, how='left')
        agg['web_events_last_30d'] = agg['web_events_last_30d'].fillna(0)
        agg['products_viewed_last_30d'] = agg['products_viewed_last_30d'].fillna(0)
        
        # Drop datetime columns
        agg = agg.drop(columns=['first_web', 'last_web'])
        
        return agg
    
    # ================================================================
    # STEP 4: CAMPAIGNS (SPARSE)
    # ================================================================
    
    def _aggregate_campaigns(self, user_id_col: str) -> Optional[pd.DataFrame]:
        """Aggregate campaigns (handles sparsity)."""
        if self.campaigns is None or len(self.campaigns) == 0:
            return None
        
        df = self.campaigns.copy()
        
        agg = df.groupby(user_id_col).agg({
            'campaign_id': 'nunique',
            'clicked': ['sum', 'count']
        })
        agg.columns = ['campaigns_unique', 'campaigns_clicked', 'campaigns_exposed']
        agg = agg.reset_index()
        
        agg['campaign_ctr'] = agg['campaigns_clicked'] / (agg['campaigns_exposed'] + 1)
        
        print(f"  Campaign data for {len(agg):,} users ({len(agg)/len(self.demographics)*100:.1f}% coverage)")
        
        return agg
    
    # ================================================================
    # STEP 5: INTERACTION SEQUENCES
    # ================================================================
    
    def _build_sequences(self, user_id_col: str) -> Dict:
        """Build event sequences for Interaction Tower."""
        max_len = self.config['max_sequence_length']
        
        # Combine all events
        events_list = []
        
        # Web events
        web_events = self.web_behavior[[user_id_col, 'product_id', 'event_type', 'timestamp']].copy()
        web_events['source'] = 'web'
        events_list.append(web_events)
        
        # Transaction events
        txn_events = self.transactions[[user_id_col, 'product_id', 'timestamp']].copy()
        txn_events['event_type'] = 'purchase'
        txn_events['source'] = 'transaction'
        events_list.append(txn_events)
        
        # Campaign events (if available)
        if self.campaigns is not None:
            camp_events = self.campaigns[[user_id_col, 'timestamp']].copy()
            camp_events['product_id'] = 'CAMPAIGN'
            camp_events['event_type'] = 'campaign_click'
            camp_events['source'] = 'campaign'
            events_list.append(camp_events)
        
        # Combine
        events = pd.concat(events_list, ignore_index=True)
        events['timestamp'] = pd.to_datetime(events['timestamp'])
        events = events.sort_values([user_id_col, 'timestamp'])
        
        # Encode event types
        event_encoder = LabelEncoder()
        all_events = ['[PAD]'] + list(events['event_type'].unique())
        event_encoder.fit(all_events)
        events['event_encoded'] = event_encoder.transform(events['event_type'])
        self.encoders['event_type'] = event_encoder
        
        # Encode products
        product_encoder = LabelEncoder()
        all_products = ['[PAD]'] + list(events['product_id'].unique())
        product_encoder.fit(all_products)
        events['product_encoded'] = product_encoder.transform(events['product_id'])
        self.encoders['product_id'] = product_encoder
        
        # Build sequences per user
        user_ids = events[user_id_col].unique()
        
        sequences = {
            'user_ids': [],
            'event_sequences': [],
            'product_sequences': [],
            'time_deltas': [],
            'attention_masks': []
        }
        
        for uid in user_ids:
            user_events = events[events[user_id_col] == uid].tail(max_len)
            
            event_seq = user_events['event_encoded'].values
            product_seq = user_events['product_encoded'].values
            
            # Time deltas
            timestamps = user_events['timestamp'].values
            deltas = np.zeros(len(timestamps))
            if len(timestamps) > 1:
                deltas[1:] = np.diff(timestamps).astype('timedelta64[D]').astype(float)
            deltas = np.clip(deltas, 0, 365)
            
            # Pad
            seq_len = len(event_seq)
            pad_len = max_len - seq_len
            
            if pad_len > 0:
                event_seq = np.pad(event_seq, (pad_len, 0), constant_values=0)
                product_seq = np.pad(product_seq, (pad_len, 0), constant_values=0)
                deltas = np.pad(deltas, (pad_len, 0), constant_values=0)
                mask = np.array([0] * pad_len + [1] * seq_len)
            else:
                mask = np.ones(max_len)
            
            sequences['user_ids'].append(uid)
            sequences['event_sequences'].append(event_seq)
            sequences['product_sequences'].append(product_seq)
            sequences['time_deltas'].append(deltas)
            sequences['attention_masks'].append(mask)
        
        # Convert to numpy
        for key in sequences:
            sequences[key] = np.array(sequences[key])
        
        print(f"  Built sequences for {len(user_ids):,} users")
        print(f"  Event types: {len(event_encoder.classes_)}")
        print(f"  Products: {len(product_encoder.classes_)}")
        
        return sequences
    
    # ================================================================
    # STEP 6: TARGETS
    # ================================================================
    
    def _calculate_targets(self, user_id_col: str) -> pd.DataFrame:
        """Calculate target variables."""
        df = self.transactions.copy()
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        
        # Last purchase per user
        last_purchase = df.groupby(user_id_col)['timestamp'].max().reset_index()
        last_purchase.columns = [user_id_col, 'last_purchase']
        
        targets = pd.DataFrame({user_id_col: df[user_id_col].unique()})
        targets = targets.merge(last_purchase, on=user_id_col, how='left')
        
        # Churn
        targets['recency'] = (self.reference_date - targets['last_purchase']).dt.days
        targets['churned'] = (targets['recency'] > self.config['churn_threshold_days']).astype(int)
        
        # CLV (last 365 days spend)
        cutoff = self.reference_date - timedelta(days=365)
        clv = df[df['timestamp'] >= cutoff].groupby(user_id_col)['amount'].sum().reset_index()
        clv.columns = [user_id_col, 'clv']
        targets = targets.merge(clv, on=user_id_col, how='left')
        targets['clv'] = targets['clv'].fillna(0)
        
        # Upsell (AOV increased?)
        def calc_upsell(group):
            if len(group) < 4:
                return 0
            mid = len(group) // 2
            first_aov = group.head(mid)['amount'].mean()
            second_aov = group.tail(mid)['amount'].mean()
            return 1 if second_aov > first_aov * 1.2 else 0
        
        upsell = df.sort_values('timestamp').groupby(user_id_col).apply(calc_upsell).reset_index()
        upsell.columns = [user_id_col, 'upsell']
        targets = targets.merge(upsell, on=user_id_col, how='left')
        targets['upsell'] = targets['upsell'].fillna(0).astype(int)
        
        targets = targets.drop(columns=['last_purchase', 'recency'])
        
        print(f"  Churn rate: {targets['churned'].mean():.1%}")
        print(f"  Avg CLV: {targets['clv'].mean():,.0f}")
        print(f"  Upsell rate: {targets['upsell'].mean():.1%}")
        
        return targets
    
    # ================================================================
    # COMBINE & OUTPUT
    # ================================================================
    
    def _combine_features(
        self,
        demo: pd.DataFrame,
        txn: pd.DataFrame,
        web: pd.DataFrame,
        campaign: Optional[pd.DataFrame],
        targets: pd.DataFrame
    ) -> pd.DataFrame:
        """Combine all features."""
        user_id_col = demo.columns[0]
        
        combined = demo.copy()
        combined = combined.merge(txn, on=user_id_col, how='left')
        combined = combined.merge(web, on=user_id_col, how='left')
        
        if campaign is not None:
            combined = combined.merge(campaign, on=user_id_col, how='left')
        
        combined = combined.merge(targets, on=user_id_col, how='left')
        
        # Fill NaN
        numeric_cols = combined.select_dtypes(include=[np.number]).columns
        combined[numeric_cols] = combined[numeric_cols].fillna(0)
        
        return combined
    
    def _prepare_output(self, features: pd.DataFrame, sequences: Dict) -> Dict:
        """Prepare final output."""
        user_id_col = features.columns[0]
        
        # Identify feature columns
        target_cols = ['churned', 'clv', 'upsell']
        feature_cols = [c for c in features.columns if c != user_id_col and c not in target_cols]
        
        # Align sequences with features
        user_to_idx = {uid: i for i, uid in enumerate(features[user_id_col].values)}
        seq_len = self.config['max_sequence_length']
        
        aligned_seqs = {
            'event_sequences': np.zeros((len(features), seq_len), dtype=np.int64),
            'product_sequences': np.zeros((len(features), seq_len), dtype=np.int64),
            'time_deltas': np.zeros((len(features), seq_len), dtype=np.float32),
            'attention_masks': np.zeros((len(features), seq_len), dtype=np.int64)
        }
        
        for i, uid in enumerate(sequences['user_ids']):
            if uid in user_to_idx:
                idx = user_to_idx[uid]
                aligned_seqs['event_sequences'][idx] = sequences['event_sequences'][i]
                aligned_seqs['product_sequences'][idx] = sequences['product_sequences'][i]
                aligned_seqs['time_deltas'][idx] = sequences['time_deltas'][i]
                aligned_seqs['attention_masks'][idx] = sequences['attention_masks'][i]
        
        return {
            'user_ids': features[user_id_col].values,
            'customer_features': features[feature_cols].values,
            'feature_names': feature_cols,
            'interaction_sequences': aligned_seqs,
            'targets': {
                'churned': features['churned'].values if 'churned' in features else None,
                'clv': features['clv'].values if 'clv' in features else None,
                'upsell': features['upsell'].values if 'upsell' in features else None,
            },
            'metadata': {
                'num_users': len(features),
                'num_features': len(feature_cols),
                'max_sequence_length': seq_len,
                'num_event_types': len(self.encoders.get('event_type', LabelEncoder().fit(['a'])).classes_),
                'num_products': len(self.encoders.get('product_id', LabelEncoder().fit(['a'])).classes_),
                'encoders': self.encoders,
            }
        }


# ================================================================
# EXAMPLE USAGE
# ================================================================

if __name__ == "__main__":
    # Create sample data
    np.random.seed(42)
    n_users = 1000
    
    # Demographics
    demographics = pd.DataFrame({
        'user_id': [f'U{i:04d}' for i in range(n_users)],
        'age': np.random.randint(18, 65, n_users),
        'city': np.random.choice(['Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Kolkata'], n_users),
    })
    
    # Transactions
    transactions = pd.DataFrame({
        'user_id': np.random.choice(demographics['user_id'], 5000),
        'product_id': [f'P{np.random.randint(1, 500):03d}' for _ in range(5000)],
        'timestamp': pd.date_range('2023-01-01', periods=5000, freq='2h'),
        'amount': np.random.lognormal(7, 1, 5000),  # Indian Rupees
    })
    
    # Web Behavior
    web_behavior = pd.DataFrame({
        'user_id': np.random.choice(demographics['user_id'], 20000),
        'product_id': [f'P{np.random.randint(1, 500):03d}' for _ in range(20000)],
        'event_type': np.random.choice(['product_view', 'add_to_cart', 'search', 'wishlist'], 20000, p=[0.6, 0.2, 0.15, 0.05]),
        'timestamp': pd.date_range('2023-01-01', periods=20000, freq='30min'),
    })
    
    # Campaigns (Sparse - only 10% of users)
    campaign_users = np.random.choice(demographics['user_id'], 200, replace=False)
    campaigns = pd.DataFrame({
        'user_id': np.repeat(campaign_users, 3),
        'campaign_id': np.random.choice(['DIWALI', 'SUMMER', 'NEWYEAR'], 600),
        'clicked': np.random.binomial(1, 0.15, 600),
        'timestamp': pd.date_range('2023-06-01', periods=600, freq='d'),
    })
    
    print("Sample Data Created:")
    print(f"  Demographics: {len(demographics)} users")
    print(f"  Transactions: {len(transactions)} records")
    print(f"  Web Behavior: {len(web_behavior)} events")
    print(f"  Campaigns: {len(campaigns)} records (sparse - {len(campaign_users)} users)")
    
    # Process
    processor = SimpleEvoCRMProcessor(
        demographics=demographics,
        transactions=transactions,
        web_behavior=web_behavior,
        campaigns=campaigns
    )
    
    result = processor.process()
    
    print("\n" + "="*60)
    print("OUTPUT STRUCTURE")
    print("="*60)
    print(f"User IDs: {result['user_ids'].shape}")
    print(f"Customer Features: {result['customer_features'].shape}")
    print(f"Feature Names: {result['feature_names'][:10]}...")
    print(f"Event Sequences: {result['interaction_sequences']['event_sequences'].shape}")
    print(f"Targets: {list(result['targets'].keys())}")
