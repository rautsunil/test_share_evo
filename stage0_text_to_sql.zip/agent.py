"""
Stage 0 Text-to-SQL Agent — single table, LangGraph, self-correcting.

WHAT THIS IS (beginner walkthrough):
A LangGraph agent is just a flowchart where each box ("node") is a
Python function, and the flowchart decides which box runs next based
on the current "state" (a shared dict-like object every node can
read and write).

This agent has 3 boxes:
  1. generate_sql   -> asks Claude to write a SQL query
  2. validate_sql    -> checks the query is safe (SELECT-only, has LIMIT)
  3. execute_sql      -> runs it on BigQuery

If execute_sql fails (bad column name, syntax error, etc.), we loop
back to generate_sql ONE more time with the error message attached,
so the model can fix its own mistake. This is "self-correction" —
cheap to build, catches most real-world failures.

RUN MODES:
  - DRY_RUN = True  -> generates + validates SQL but does NOT hit
                        BigQuery. Use this first, before you've wired
                        up credentials. Lets you sanity-check the SQL
                        by eye.
  - DRY_RUN = False -> actually executes against BigQuery.
"""

import os
import re
import yaml
from typing import TypedDict, Optional
from anthropic import Anthropic
from langgraph.graph import StateGraph, END

from prompts import build_system_prompt, RETRY_PROMPT

# ------------------------------------------------------------------
# CONFIG — edit these for your environment
# ------------------------------------------------------------------
DRY_RUN = True                 # flip to False once BigQuery creds are set up
MAX_RETRIES = 2                # how many times to let the agent self-correct
MODEL = "claude-sonnet-4-6"    # generation model
SCHEMA_PATH = "schema.yaml"

client = Anthropic()  # reads ANTHROPIC_API_KEY from env


# ------------------------------------------------------------------
# STATE — the shared "clipboard" every node reads/writes
# ------------------------------------------------------------------
class AgentState(TypedDict):
    question: str
    sql: Optional[str]
    error: Optional[str]
    result: Optional[list]
    attempts: int
    status: str  # "ok" | "cannot_answer" | "failed"


# ------------------------------------------------------------------
# NODE 1: generate_sql
# ------------------------------------------------------------------
def generate_sql(state: AgentState, schema: dict) -> AgentState:
    system_prompt = build_system_prompt(schema)

    if state.get("error"):
        # Retry path: include the previous failure so the model can fix it
        user_msg = RETRY_PROMPT.format(
            error=state["error"],
            previous_sql=state["sql"],
        )
    else:
        user_msg = f"Question: {state['question']}"

    response = client.messages.create(
        model=MODEL,
        max_tokens=500,
        system=system_prompt,
        messages=[{"role": "user", "content": user_msg}],
    )
    raw = response.content[0].text.strip()

    if raw.startswith("CANNOT_ANSWER"):
        state["status"] = "cannot_answer"
        state["error"] = raw
        return state

    state["sql"] = raw
    state["attempts"] = state.get("attempts", 0) + 1
    return state


# ------------------------------------------------------------------
# NODE 2: validate_sql — the guardrail
# Beginner note: NEVER skip this. This is what stops a hallucinated
# or malformed query from touching your real data.
# ------------------------------------------------------------------
FORBIDDEN = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|TRUNCATE|CREATE|MERGE|GRANT)\b",
    re.IGNORECASE,
)


def validate_sql(state: AgentState, max_rows: int) -> AgentState:
    if state["status"] == "cannot_answer":
        return state

    sql = state["sql"] or ""

    if not sql.strip().upper().startswith("SELECT"):
        state["error"] = "Query must start with SELECT."
        state["sql"] = None
        return state

    if FORBIDDEN.search(sql):
        state["error"] = "Query contains a forbidden write/DDL keyword."
        state["sql"] = None
        return state

    if "LIMIT" not in sql.upper():
        # auto-fix rather than reject — small, safe correction
        sql = sql.rstrip(";") + f" LIMIT {max_rows}"
        state["sql"] = sql

    state["error"] = None  # cleared validation
    return state


# ------------------------------------------------------------------
# NODE 3: execute_sql
# ------------------------------------------------------------------
def execute_sql(state: AgentState) -> AgentState:
    if state["status"] == "cannot_answer" or not state.get("sql"):
        return state

    if DRY_RUN:
        state["result"] = [{"dry_run": "SQL not executed. Set DRY_RUN=False to run for real."}]
        state["status"] = "ok"
        return state

    try:
        from google.cloud import bigquery
        bq = bigquery.Client()
        rows = bq.query(state["sql"]).result()
        state["result"] = [dict(row) for row in rows]
        state["status"] = "ok"
        state["error"] = None
    except Exception as e:
        state["error"] = str(e)
        state["result"] = None

    return state


# ------------------------------------------------------------------
# ROUTING — decides what happens after execute_sql
# ------------------------------------------------------------------
def route_after_execute(state: AgentState) -> str:
    if state["status"] == "cannot_answer":
        return END
    if state.get("error") and state.get("attempts", 0) < MAX_RETRIES:
        return "generate_sql"  # loop back and self-correct
    if state.get("error"):
        state["status"] = "failed"
        return END
    return END


# ------------------------------------------------------------------
# BUILD THE GRAPH
# ------------------------------------------------------------------
def build_agent():
    with open(SCHEMA_PATH) as f:
        schema = yaml.safe_load(f)
    max_rows = schema["table"].get("max_rows_returned", 1000)

    graph = StateGraph(AgentState)
    graph.add_node("generate_sql", lambda s: generate_sql(s, schema))
    graph.add_node("validate_sql", lambda s: validate_sql(s, max_rows))
    graph.add_node("execute_sql", execute_sql)

    graph.set_entry_point("generate_sql")
    graph.add_edge("generate_sql", "validate_sql")
    graph.add_edge("validate_sql", "execute_sql")
    graph.add_conditional_edges(
        "execute_sql",
        route_after_execute,
        {"generate_sql": "generate_sql", END: END},
    )

    return graph.compile()


def ask(question: str) -> AgentState:
    """Convenience entrypoint: run one question through the agent."""
    app = build_agent()
    initial_state: AgentState = {
        "question": question,
        "sql": None,
        "error": None,
        "result": None,
        "attempts": 0,
        "status": "",
    }
    return app.invoke(initial_state)


if __name__ == "__main__":
    q = "What was the total revenue last month?"
    final_state = ask(q)
    print("QUESTION:", q)
    print("SQL:", final_state.get("sql"))
    print("STATUS:", final_state.get("status"))
    print("RESULT:", final_state.get("result"))
    if final_state.get("error"):
        print("ERROR:", final_state["error"])
