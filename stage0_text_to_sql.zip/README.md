# Stage 0 — Text-to-SQL Agent (single table)

This is the "fail fast" starting point from the plan. It does ONE
thing: turn a plain-English question into a safe, validated SQL
query for **one** BigQuery table.

No router agent, no insight agent, no multi-table joins yet — those
come in Stage 1 and 2. The point of Stage 0 is to see where
text-to-SQL breaks *before* you build infrastructure around it.

## Files

| File | What it does |
|---|---|
| `schema.yaml` | Describes your table — columns, business terms. **Edit this first.** |
| `prompts.py` | The prompt sent to Claude. You'll tweak this a lot. |
| `agent.py` | The LangGraph agent: generate → validate → execute → self-correct |
| `test_questions.py` | Runs a batch of test questions so you can eyeball results |

## Setup (5 steps)

1. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Set your Anthropic API key**
   ```bash
   export ANTHROPIC_API_KEY="your-key-here"
   ```

3. **Edit `schema.yaml`** to describe your real table — actual
   column names, types, and (important) the business term glossary.
   This is the single biggest lever on quality. Garbage schema in,
   garbage SQL out.

4. **First run: keep `DRY_RUN = True`** in `agent.py`. This generates
   and validates SQL WITHOUT touching BigQuery, so you can sanity
   check the queries by reading them before anything executes.
   ```bash
   python test_questions.py
   ```

5. **Once the SQL looks right**, set up BigQuery credentials
   (`gcloud auth application-default login` or a service account
   key via `GOOGLE_APPLICATION_CREDENTIALS`), flip `DRY_RUN = False`
   in `agent.py`, and re-run.

## What "good" looks like at this stage

You're NOT aiming for perfection. You're aiming to answer:
- Which questions does it get right immediately?
- Which fail, and why — bad column guess? Wrong business term?
  Ambiguous question it should have refused?
- Does the self-correction retry actually fix real errors, or just
  burn a second API call for nothing?

Write down every failure. That list becomes:
- Additions to `business_terms` in `schema.yaml`
- Your golden test set for Stage 1 (add the question + the CORRECT
  SQL you'd expect, by hand)

## Guardrails already built in (don't remove these)

- Rejects anything that isn't a `SELECT`
- Rejects write/DDL keywords (`INSERT`, `DROP`, etc.) even if the
  model tries to generate them
- Auto-adds a `LIMIT` if the model forgets one
- Self-corrects once on execution error, then gives up cleanly
  rather than looping forever

## Next step (Stage 1)

Once this feels solid on your one table:
1. Add the Router Agent (classify: text-to-sql vs. insight vs. clarify)
2. Add the Insight Agent (reads the result table, writes a summary,
   grounded to the actual numbers — no hallucinated stats)
3. Wire both into this same LangGraph graph as new nodes

Still just one table at this point — don't scale to all 7 until
Stage 2, per the plan.
