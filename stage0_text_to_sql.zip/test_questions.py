"""
Run a batch of test questions through the agent and print results.

Beginner note: this file is your safety net. Every time you tweak
schema.yaml or prompts.py, re-run this and eyeball the output.
When something breaks that used to work, you'll see it immediately
instead of finding out from a user later.

As you go, ADD real questions your team actually asks — that's how
this becomes your golden test set for Stage 1/2, per the plan.
"""

from agent import ask

TEST_QUESTIONS = [
    "What was the total revenue last month?",
    "How many orders were cancelled this year?",
    "Show me the top 5 product categories by order value.",
    "What's the cancellation rate by region?",
    "List all orders from customer X.",  # deliberately vague — should
                                          # ideally trigger CANNOT_ANSWER
                                          # or ask for a real customer_id
]

if __name__ == "__main__":
    for i, q in enumerate(TEST_QUESTIONS, 1):
        print(f"\n{'='*60}")
        print(f"[{i}] {q}")
        print("=" * 60)
        state = ask(q)
        print("STATUS :", state.get("status"))
        print("SQL    :", state.get("sql"))
        if state.get("error"):
            print("ERROR  :", state["error"])
        if state.get("result") is not None:
            print("RESULT :", state["result"][:3], "..." if len(state["result"]) > 3 else "")
