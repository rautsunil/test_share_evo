"""
Run this standalone (no FSDP, no training) to see the REAL baseline memory
footprint of your model + quantization, before any sequence-length or
sharding complexity enters the picture.

    python diagnose_memory.py
"""
import torch
from transformers import AutoModelForCausalLM, BitsAndBytesConfig

bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16,
    bnb_4bit_use_double_quant=True,
)

print("Loading model on GPU 0 only (single GPU, no FSDP)...")
model = AutoModelForCausalLM.from_pretrained(
    "Qwen/Qwen3-8B",
    quantization_config=bnb_config,
    attn_implementation="flash_attention_2",
    torch_dtype=torch.bfloat16,
    device_map={"": 0},
)

allocated = torch.cuda.memory_allocated(0) / 1e9
reserved = torch.cuda.memory_reserved(0) / 1e9

print(f"\n--- Baseline (weights only, no activations, no batch) ---")
print(f"Allocated: {allocated:.2f} GB")
print(f"Reserved:  {reserved:.2f} GB")
print(f"Attn impl: {model.config._attn_implementation}")

# Expected: allocated should be ~4.5-6GB for a correctly 4-bit-quantized 8B model.
# If this number is already 15GB+, the model is NOT actually loading in 4-bit -
# check your bitsandbytes install and BitsAndBytesConfig, this is your bug,
# not sequence length.

if allocated > 10:
    print("\n⚠️  WARNING: allocated memory is much higher than expected for 4-bit.")
    print("This means quantization is not actually active - check:")
    print("  1. bitsandbytes version (`pip show bitsandbytes`)")
    print("  2. CUDA compatibility of your bitsandbytes build")
    print("  3. Whether quantization_config is being silently ignored")
else:
    print("\n✅ Baseline looks correct for 4-bit quantization.")
    print("If you still OOM during actual training, the issue is in")
    print("activations/FSDP sharding, not the base model loading.")
