"""
Run this BEFORE training to pick MAX_SEQ_LEN from real data instead of guessing.
Usage: python check_lengths.py train_data.jsonl
"""
import sys
import json
import numpy as np
from transformers import AutoTokenizer

tokenizer = AutoTokenizer.from_pretrained("Qwen/Qwen3-8B")

path = sys.argv[1] if len(sys.argv) > 1 else "train_data.jsonl"

lengths = []
with open(path) as f:
    for line in f:
        record = json.loads(line)
        lengths.append(len(tokenizer(record["text"]).input_ids))

lengths = np.array(lengths)
print(f"n examples: {len(lengths)}")
for p in [50, 75, 90, 95, 99, 100]:
    print(f"p{p}: {int(np.percentile(lengths, p))} tokens")
print(f"\nExamples over 12288 tokens: {(lengths > 12288).sum()} "
      f"({(lengths > 12288).mean() * 100:.1f}%)")
print(f"Examples over 16384 tokens: {(lengths > 16384).sum()} "
      f"({(lengths > 16384).mean() * 100:.1f}%)")
