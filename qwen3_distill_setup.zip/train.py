"""
QLoRA fine-tuning of Qwen3-8B for knowledge distillation, across 2x L4 GPUs.
Launch with:
    accelerate launch --config_file fsdp_config.yaml train.py

Stack: FSDP (multi-GPU sharding) + QLoRA (4-bit) + Flash Attention 2 +
       gradient checkpointing + Liger Kernel chunked cross-entropy.
"""

import torch
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    TrainingArguments,
    Trainer,
    DataCollatorForSeq2Seq,
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from datasets import load_dataset

# ---- Liger Kernel: patches Qwen3 to use fused/chunked ops, incl. chunked ----
# ---- cross-entropy, so the full [seq_len, vocab_size] logits tensor is  ----
# ---- never fully materialized. Must be called BEFORE model loading.    ----
from liger_kernel.transformers import apply_liger_kernel_to_qwen3

apply_liger_kernel_to_qwen3(
    rope=True,
    swiglu=True,
    rms_norm=True,
    fused_linear_cross_entropy=True,  # the key memory-saving piece
)

MODEL_ID = "Qwen/Qwen3-8B"
MAX_SEQ_LEN = 12288          # set from your actual data percentile check, not guessed
OUTPUT_DIR = "./qwen3_qlora_distill"


def build_model_and_tokenizer():
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,
    )

    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        MODEL_ID,
        quantization_config=bnb_config,
        attn_implementation="flash_attention_2",   # requires bf16/fp16, not fp32
        torch_dtype=torch.bfloat16,
    )

    # Sanity check FA2 actually took effect - fail loudly instead of silently
    # falling back to eager attention.
    assert model.config._attn_implementation == "flash_attention_2", (
        f"Flash Attention 2 not active, got: {model.config._attn_implementation}. "
        "Check flash-attn is installed for your CUDA/torch build."
    )

    model.config.use_cache = False  # required alongside gradient checkpointing

    model = prepare_model_for_kbit_training(
        model, use_gradient_checkpointing=True
    )
    model.gradient_checkpointing_enable(
        gradient_checkpointing_kwargs={"use_reentrant": False}
    )

    lora_config = LoraConfig(
        r=16,
        lora_alpha=32,
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=[
            "q_proj", "k_proj", "v_proj", "o_proj",
            "gate_proj", "up_proj", "down_proj",
        ],
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    return model, tokenizer


def build_dataset(tokenizer):
    # Replace with your actual judge-distillation dataset loading logic.
    # Expected columns: "text" (already-formatted prompt+rationale+scores).
    dataset = load_dataset("json", data_files="train_data.jsonl")["train"]

    def tokenize_fn(example):
        tokenized = tokenizer(
            example["text"],
            truncation=True,
            max_length=MAX_SEQ_LEN,
            padding=False,  # dynamic padding via collator, not fixed-length padding
        )
        tokenized["labels"] = tokenized["input_ids"].copy()
        return tokenized

    return dataset.map(tokenize_fn, remove_columns=dataset.column_names)


def main():
    model, tokenizer = build_model_and_tokenizer()
    train_dataset = build_dataset(tokenizer)

    collator = DataCollatorForSeq2Seq(
        tokenizer=tokenizer,
        padding=True,
        label_pad_token_id=-100,
    )

    training_args = TrainingArguments(
        output_dir=OUTPUT_DIR,
        per_device_train_batch_size=1,
        gradient_accumulation_steps=16,
        num_train_epochs=3,
        learning_rate=2e-4,
        bf16=True,
        logging_steps=10,
        save_strategy="epoch",
        optim="paged_adamw_8bit",     # handles memory spikes on long sequences
        report_to="tensorboard",
        gradient_checkpointing=True,
        gradient_checkpointing_kwargs={"use_reentrant": False},
        max_grad_norm=0.3,
        warmup_ratio=0.03,
        lr_scheduler_type="cosine",
        # NOTE: do NOT also pass deepspeed=... here - FSDP is driven via the
        # accelerate launch config (fsdp_config.yaml), not TrainingArguments.
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        data_collator=collator,
    )

    trainer.train()
    trainer.save_model(OUTPUT_DIR)
    tokenizer.save_pretrained(OUTPUT_DIR)


if __name__ == "__main__":
    main()
