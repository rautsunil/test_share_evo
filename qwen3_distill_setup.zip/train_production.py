"""
PRODUCTION TRAINING SCRIPT - Qwen3-8B QLoRA Distillation
FSDP + QLoRA(4-bit) + Flash Attention 2 + Gradient Checkpointing + Liger Kernel

Launch (never run with plain `python`, or FSDP silently does nothing):
    accelerate launch --config_file fsdp_config.yaml train_production.py

Every fix from the debugging conversation is verified BEFORE training starts.
If any guardrail fails, the script exits loudly instead of silently OOMing
20 minutes into training.
"""

import sys
import torch
import torch.distributed as dist
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    TrainingArguments,
    Trainer,
    DataCollatorForSeq2Seq,
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from datasets import load_dataset
from accelerate import PartialState

from liger_kernel.transformers import apply_liger_kernel_to_qwen3

MODEL_ID = "Qwen/Qwen3-8B"
MAX_SEQ_LEN = 12288  # set from check_lengths.py p95 output - do not guess
OUTPUT_DIR = "./qwen3_qlora_distill"
DATA_PATH = "train_data.jsonl"


def log(msg, state):
    """Only print from rank 0 - avoids N duplicate log lines from N processes."""
    if state.is_main_process:
        print(msg, flush=True)


# ---------------------------------------------------------------------------
# GUARDRAIL 1: Confirm Accelerate actually spawned multiple processes.
# If this prints num_processes=1, FSDP is inert no matter what the YAML says -
# the script was launched with `python train.py` instead of `accelerate launch`.
# ---------------------------------------------------------------------------
def check_distributed_setup():
    state = PartialState()
    log(f"[GUARDRAIL 1] process_index={state.process_index}, "
        f"num_processes={state.num_processes}, device={state.device}", state)
    if state.num_processes < 2:
        log("\n FATAL: num_processes=1. FSDP is NOT active.\n"
            "   You must launch with:\n"
            "   accelerate launch --config_file fsdp_config.yaml train_production.py\n"
            "   Not: python train_production.py", state)
        sys.exit(1)
    return state


# ---------------------------------------------------------------------------
# GUARDRAIL 2: Apply Liger kernel BEFORE model load (chunked cross-entropy,
# avoids materializing the full [seq_len, vocab_size] logits tensor).
# ---------------------------------------------------------------------------
def apply_liger(state):
    apply_liger_kernel_to_qwen3(
        rope=True, swiglu=True, rms_norm=True, fused_linear_cross_entropy=True,
    )
    log("[GUARDRAIL 2] Liger kernel patches applied to Qwen3", state)


# ---------------------------------------------------------------------------
# GUARDRAIL 3: Load model, then VERIFY 4-bit actually took effect by
# inspecting a real layer's class name - not just trusting the config.
# ---------------------------------------------------------------------------
def build_model_and_tokenizer(state):
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,
        bnb_4bit_quant_storage=torch.bfloat16,  # required for FSDP+QLoRA to shard correctly
    )

    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        MODEL_ID,
        quantization_config=bnb_config,
        attn_implementation="flash_attention_2",
        torch_dtype=torch.bfloat16,
    )

    # --- Verify FA2 is really active, not silently fallen back to eager ---
    attn_impl = model.config._attn_implementation
    log(f"[GUARDRAIL 3a] attn_implementation = {attn_impl}", state)
    assert attn_impl == "flash_attention_2", (
        f"FATAL: expected flash_attention_2, got {attn_impl}. "
        "Check flash-attn is installed for your torch/CUDA build."
    )

    # --- Verify 4-bit quantization is really active by checking layer class ---
    sample_layer = None
    for name, module in model.named_modules():
        if "q_proj" in name and hasattr(module, "weight"):
            sample_layer = (name, type(module).__name__)
            break
    log(f"[GUARDRAIL 3b] sample layer: {sample_layer}", state)
    assert sample_layer is not None and sample_layer[1] == "Linear4bit", (
        f"FATAL: expected Linear4bit, got {sample_layer}. "
        "Model is NOT quantized - check bitsandbytes install "
        "(`python -m bitsandbytes` to diagnose)."
    )

    # --- Report actual per-GPU memory after load, before any training ---
    allocated = torch.cuda.memory_allocated(state.device) / 1e9
    log(f"[GUARDRAIL 3c] Post-load allocated memory on {state.device}: "
        f"{allocated:.2f} GB (expect ~4-6GB for correctly 4-bit-quantized 8B model)", state)
    if allocated > 10:
        log("️  WARNING: allocated memory is much higher than expected for 4-bit. "
            "Continuing, but this strongly suggests quantization is not fully active.", state)

    model.config.use_cache = False  # required with gradient checkpointing
    model = prepare_model_for_kbit_training(model, use_gradient_checkpointing=True)
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    log(f"[GUARDRAIL 4] use_cache={model.config.use_cache}, "
        f"gradient_checkpointing enabled", state)

    lora_config = LoraConfig(
        r=16, lora_alpha=32, lora_dropout=0.05, bias="none", task_type="CAUSAL_LM",
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    )
    model = get_peft_model(model, lora_config)
    if state.is_main_process:
        model.print_trainable_parameters()

    return model, tokenizer


# ---------------------------------------------------------------------------
# GUARDRAIL 5: Verify tokenized dataset doesn't silently exceed MAX_SEQ_LEN,
# and report how much of the real data distribution is being truncated.
# ---------------------------------------------------------------------------
def build_dataset(tokenizer, state):
    dataset = load_dataset("json", data_files=DATA_PATH)["train"]

    lengths = [len(tokenizer(ex["text"]).input_ids) for ex in dataset.select(range(min(500, len(dataset))))]
    over_limit = sum(1 for l in lengths if l > MAX_SEQ_LEN)
    log(f"[GUARDRAIL 5] Sampled {len(lengths)} examples: "
        f"{over_limit} ({over_limit/len(lengths)*100:.1f}%) exceed MAX_SEQ_LEN={MAX_SEQ_LEN} "
        f"and will be truncated.", state)
    if over_limit / len(lengths) > 0.1:
        log("️  WARNING: >10% of sampled data exceeds MAX_SEQ_LEN. "
            "Re-run check_lengths.py and consider raising MAX_SEQ_LEN or "
            "using hierarchical compression for long conversations.", state)

    def tokenize_fn(example):
        tokenized = tokenizer(example["text"], truncation=True, max_length=MAX_SEQ_LEN, padding=False)
        tokenized["labels"] = tokenized["input_ids"].copy()
        return tokenized

    return dataset.map(tokenize_fn, remove_columns=dataset.column_names)


def main():
    state = check_distributed_setup()
    apply_liger(state)
    model, tokenizer = build_model_and_tokenizer(state)
    train_dataset = build_dataset(tokenizer, state)

    collator = DataCollatorForSeq2Seq(tokenizer=tokenizer, padding=True, label_pad_token_id=-100)

    training_args = TrainingArguments(
        output_dir=OUTPUT_DIR,
        per_device_train_batch_size=1,
        gradient_accumulation_steps=16,
        num_train_epochs=3,
        learning_rate=2e-4,
        bf16=True,
        logging_steps=10,
        save_strategy="epoch",
        optim="paged_adamw_8bit",
        report_to="tensorboard",
        gradient_checkpointing=True,
        gradient_checkpointing_kwargs={"use_reentrant": False},
        max_grad_norm=0.3,
        warmup_ratio=0.03,
        lr_scheduler_type="cosine",
    )

    trainer = Trainer(model=model, args=training_args, train_dataset=train_dataset, data_collator=collator)

    log("\n[GUARDRAIL 6] All pre-flight checks passed. Starting training.\n", state)
    trainer.train()

    trainer.save_model(OUTPUT_DIR)
    tokenizer.save_pretrained(OUTPUT_DIR)
    log(f"\nTraining complete. Model saved to {OUTPUT_DIR}", state)


if __name__ == "__main__":
    main()
