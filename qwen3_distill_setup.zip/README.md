# Qwen3-8B QLoRA Distillation — 2x L4 (g2-standard-24) Setup

## Install (order matters)
```bash
pip install torch==2.4.0 --index-url https://download.pytorch.org/whl/cu121
pip install -r requirements.txt --no-build-isolation
```
`flash-attn` compiles against your installed torch/CUDA — installing it before torch,
or with a mismatched CUDA version, is the #1 source of "FA2 silently not active" bugs.
Verify with `python -c "import flash_attn; print(flash_attn.__version__)"`.

## 1. Check your real sequence length distribution first
```bash
python check_lengths.py train_data.jsonl
```
Set `MAX_SEQ_LEN` in `train.py` from the p95 (not p100/max) of this output. Don't
guess 6144 or any other number blind — this is the step that prevents both the OOM
and the "drop 50% of data" problem from the earlier discussion.

## 2. Launch training (2 GPUs, FSDP)
```bash
accelerate launch --config_file fsdp_config.yaml train.py
```

## Why FSDP instead of DeepSpeed ZeRO-3
DeepSpeed ZeRO-3 partitions parameters in a way that conflicts with how
bitsandbytes stores 4-bit quantized weights — this combination frequently
produces silent corruption or crashes with QLoRA specifically. FSDP does not
have this issue and is the combination Hugging Face / Answer.AI validated for
QLoRA across multiple GPUs. If you don't need QLoRA (e.g. full fine-tune or
LoRA on bf16 weights, no 4-bit), ZeRO-3 becomes viable again.

## Known gotchas this code guards against
- `gradient_checkpointing_enable()` called before `prepare_model_for_kbit_training`
  can silently no-op — order in `build_model_and_tokenizer()` matters.
- FA2 requires bf16/fp16 dtype; the code asserts it actually activated instead of
  silently falling back to eager attention.
- `use_cache=False` is required with gradient checkpointing — set explicitly.
- Padding is dynamic (via `DataCollatorForSeq2Seq`), not fixed to `MAX_SEQ_LEN`,
  so short examples don't pay the memory cost of long ones.
- `fsdp_transformer_layer_cls_to_wrap: Qwen3DecoderLayer` must match the exact
  decoder layer class name in your installed `transformers` version — verify with:
  ```python
  from transformers.models.qwen3.modeling_qwen3 import Qwen3DecoderLayer
  print(Qwen3DecoderLayer)
  ```

## If you still OOM after this
- Lower `MAX_SEQ_LEN` toward p90 instead of p95.
- Increase `gradient_accumulation_steps` rather than batch size.
- Add `fsdp_offload_params: true` in `fsdp_config.yaml` to offload to CPU RAM
  (slower, but trades speed for memory headroom).
