import torch
import bitsandbytes as bnb
import transformers

print(f"torch: {torch.__version__}, cuda available: {torch.cuda.is_available()}")
print(f"bitsandbytes: {bnb.__version__}")
print(f"transformers: {transformers.__version__}")

# This is the real test - does bnb's CUDA setup actually work
try:
    from bitsandbytes.cuda_setup.main import get_compute_capability
    print("bnb CUDA setup: importable")
except Exception as e:
    print(f"bnb CUDA setup issue: {e}")

# Try loading just the config to check quantization support
from transformers import AutoConfig
config = AutoConfig.from_pretrained("Qwen/Qwen3-8B")
print(f"\nmodel_type: {config.model_type}")
print(f"quantization_config support check - loading small test...")

from transformers import AutoModelForCausalLM, BitsAndBytesConfig

bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16,
)

model = AutoModelForCausalLM.from_pretrained(
    "Qwen/Qwen3-8B",
    quantization_config=bnb_config,
    device_map={"": 0},
)

# The real proof: check the actual dtype of a real weight tensor
first_param = next(model.parameters())
print(f"\nFirst param dtype: {first_param.dtype}")
print(f"Is 4bit: {getattr(model, 'is_loaded_in_4bit', 'attribute not found')}")
print(f"Allocated GB: {torch.cuda.memory_allocated(0) / 1e9:.2f}")

# Check a linear layer specifically - should be Linear4bit if quantized
for name, module in model.named_modules():
    if "q_proj" in name and hasattr(module, "weight"):
        print(f"\nSample layer: {name}")
        print(f"Module type: {type(module).__name__}")
        print(f"Weight dtype: {module.weight.dtype}")
        break
