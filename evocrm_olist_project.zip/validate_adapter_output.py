"""
EvoCRM Adapter Output Validator
================================

Validates that adapter output is correct and model-ready.
Works with both RetailRocket and Olist adapter output.

Checks:
    1. All required files exist and are non-empty
    2. Table schemas match EvoCRM contract
    3. Target integrity (binary 0/1, no NaN, class balance)
    4. Train/val/test split integrity (no overlap)
    5. Feature quality (no inf, acceptable NaN rate)
    6. Interaction sequence format
    7. Data leakage warnings
    8. Metadata consistency

Usage:
    python validate_adapter_output.py --data_dir ./data/olist/
"""

import os
import sys
import json
import argparse
from pathlib import Path

import numpy as np
import pandas as pd


class AdapterValidator:
    def __init__(self, data_dir: str):
        self.data_dir = Path(data_dir)
        self.errors = []
        self.warnings = []

    def run_all_checks(self) -> bool:
        print("=" * 60)
        print("  EVOCRM ADAPTER OUTPUT VALIDATION")
        print(f"  Data dir: {self.data_dir}")
        print("=" * 60)

        checks = [
            ("File Existence", self.check_files),
            ("Table Schemas", self.check_schemas),
            ("Target Integrity", self.check_targets),
            ("Split Integrity", self.check_splits),
            ("Feature Quality", self.check_features),
            ("Sequence Format", self.check_sequences),
            ("Metadata Consistency", self.check_metadata),
        ]

        all_pass = True
        for name, fn in checks:
            print(f"\n  [{name}]")
            try:
                ok = fn()
                print(f"    → {'✓ PASS' if ok else '✗ FAIL'}")
                if not ok:
                    all_pass = False
            except Exception as e:
                print(f"    → ✗ ERROR: {e}")
                self.errors.append(f"{name}: {e}")
                all_pass = False

        self._summary(all_pass)
        return all_pass

    def check_files(self):
        required = [
            "tables/demographics.csv", "tables/transactions.csv",
            "tables/web_behavior.csv", "tables/campaigns.csv",
            "targets.csv",
            "features/customer_tower_features.csv",
            "features/product_tower_features.csv",
            "features/interaction_sequences.json",
            "splits/train_user_ids.npy", "splits/val_user_ids.npy",
            "splits/test_user_ids.npy", "metadata.json",
        ]
        ok = True
        for f in required:
            p = self.data_dir / f
            exists = p.exists()
            sz = p.stat().st_size if exists else 0
            status = "✓" if exists and sz > 0 else "✗"
            print(f"    {status} {f} ({sz / 1024:.1f} KB)" if exists else f"    ✗ {f} MISSING")
            if not exists or sz == 0:
                self.errors.append(f"Missing: {f}")
                ok = False
        return ok

    def check_schemas(self):
        schemas = {
            "demographics": ["user_id", "registration_date", "city"],
            "transactions": ["transaction_id", "user_id", "product_id", "timestamp", "amount"],
            "web_behavior": ["event_id", "user_id", "event_type", "timestamp"],
            "campaigns": ["user_id"],
        }
        ok = True
        for tbl, cols in schemas.items():
            df = pd.read_csv(self.data_dir / "tables" / f"{tbl}.csv", nrows=5)
            missing = set(cols) - set(df.columns)
            if missing:
                print(f"    ✗ {tbl}: missing {missing}")
                ok = False
            else:
                print(f"    ✓ {tbl}: {len(df.columns)} columns")
        return ok

    def check_targets(self):
        targets = pd.read_csv(self.data_dir / "targets.csv")
        ok = True

        req = ["user_id", "churn", "clv", "upsell", "early_adopter", "days_next_purchase"]
        missing = [c for c in req if c not in targets.columns]
        if missing:
            print(f"    ✗ Missing columns: {missing}")
            return False

        for col in ["churn", "upsell", "early_adopter"]:
            vals = targets[col].unique()
            if not set(vals).issubset({0, 1, 0.0, 1.0}):
                print(f"    ✗ {col}: non-binary values {vals[:5]}")
                ok = False
            else:
                rate = targets[col].mean()
                flag = "⚠" if rate < 0.02 or rate > 0.98 else "✓"
                print(f"    {flag} {col}: rate={rate:.1%}")
                if rate < 0.02 or rate > 0.98:
                    self.warnings.append(f"{col} severely imbalanced ({rate:.1%})")

        for col in ["clv", "days_next_purchase"]:
            if targets[col].isna().any():
                print(f"    ✗ {col}: has NaN")
                ok = False
            else:
                print(f"    ✓ {col}: mean={targets[col].mean():.2f}")

        if targets["user_id"].duplicated().any():
            print(f"    ✗ Duplicate user_ids!")
            ok = False
        else:
            print(f"    ✓ {len(targets):,} unique users")

        return ok

    def check_splits(self):
        train = set(np.load(self.data_dir / "splits" / "train_user_ids.npy", allow_pickle=True))
        val = set(np.load(self.data_dir / "splits" / "val_user_ids.npy", allow_pickle=True))
        test = set(np.load(self.data_dir / "splits" / "test_user_ids.npy", allow_pickle=True))

        ok = True
        for a, b, na, nb in [(train, val, "train", "val"), (train, test, "train", "test"),
                              (val, test, "val", "test")]:
            overlap = a & b
            if overlap:
                print(f"    ✗ {na}-{nb} overlap: {len(overlap)}")
                ok = False

        if ok:
            print(f"    ✓ No overlap")

        total = len(train) + len(val) + len(test)
        print(f"    ✓ Train: {len(train):,} ({len(train)/total:.0%}) | "
              f"Val: {len(val):,} ({len(val)/total:.0%}) | "
              f"Test: {len(test):,} ({len(test)/total:.0%})")
        return ok

    def check_features(self):
        feats = pd.read_csv(self.data_dir / "features" / "customer_tower_features.csv")
        ok = True
        num = feats.select_dtypes(include=[np.number])

        inf_count = np.isinf(num).sum().sum()
        if inf_count > 0:
            print(f"    ✗ {inf_count} infinite values")
            ok = False
        else:
            print(f"    ✓ No infinite values")

        high_nan = num.isna().mean()
        bad = high_nan[high_nan > 0.5]
        if not bad.empty:
            print(f"    ⚠ >50% NaN: {bad.index.tolist()}")
            self.warnings.append(f"High NaN columns: {bad.index.tolist()}")
        else:
            print(f"    ✓ NaN rates acceptable")

        print(f"    ✓ Shape: {feats.shape[0]:,} × {feats.shape[1]}")
        return ok

    def check_sequences(self):
        with open(self.data_dir / "features" / "interaction_sequences.json") as f:
            seqs = json.load(f)

        ok = True
        lens = []
        for uid, evts in list(seqs.items())[:500]:
            lens.append(len(evts))
            for e in evts:
                if len(e) != 3:
                    print(f"    ✗ User {uid}: event has {len(e)} elements")
                    ok = False
                    break

        mx = max(lens) if lens else 0
        if mx > 128:
            print(f"    ✗ Max length {mx} > 128")
            ok = False
        else:
            print(f"    ✓ Lengths: mean={np.mean(lens):.1f}, max={mx}")

        print(f"    ✓ {len(seqs):,} sequences")
        return ok

    def check_metadata(self):
        meta = json.load(open(self.data_dir / "metadata.json"))
        targets = pd.read_csv(self.data_dir / "targets.csv")
        feats = pd.read_csv(self.data_dir / "features" / "customer_tower_features.csv")

        ok = True
        if meta["stats"]["n_users"] != len(targets):
            print(f"    ✗ User count mismatch: meta={meta['stats']['n_users']} vs targets={len(targets)}")
            ok = False
        if len(feats) != len(targets):
            print(f"    ✗ Feature/target row mismatch: {len(feats)} vs {len(targets)}")
            ok = False
        if ok:
            print(f"    ✓ Counts consistent: {len(targets):,} users")

        if "limitations" in meta:
            print(f"    ✓ {len(meta['limitations'])} limitations documented")

        return ok

    def _summary(self, all_pass):
        print("\n" + "=" * 60)
        if all_pass and not self.errors:
            print("  ✓ ALL CHECKS PASSED")
        else:
            print(f"  ✗ {len(self.errors)} ERRORS")
            for e in self.errors:
                print(f"    • {e}")
        if self.warnings:
            print(f"  ⚠ {len(self.warnings)} WARNINGS")
            for w in self.warnings:
                print(f"    • {w}")
        print("=" * 60)


def main():
    p = argparse.ArgumentParser(description="Validate EvoCRM adapter output")
    p.add_argument("--data_dir", type=str, default="./data/olist/")
    a = p.parse_args()
    ok = AdapterValidator(a.data_dir).run_all_checks()
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
