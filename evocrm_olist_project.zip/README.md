# EvoCRM — Olist Pipeline

One-command pipeline: raw Olist CSVs → trained model → paper-ready results.

## Quick Start

```bash
# 1. Setup
pip install -r requirements.txt
pip install torch --index-url https://download.pytorch.org/whl/cu118  # GPU version

# 2. Download Olist data
pip install kaggle
kaggle datasets download -d olistbr/brazilian-ecommerce
unzip brazilian-ecommerce.zip -d olist_raw/

# 3. Run everything (one command)
python run_full_pipeline.py --olist_dir ./olist_raw/

# Or quick test first (~30 min)
python run_full_pipeline.py --olist_dir ./olist_raw/ --quick
```

## Pipeline Steps

| Step | Script | What | Time |
|------|--------|------|------|
| 0 | — | Verify environment + GPU + data | 10s |
| 1 | `olist_adapter.py` | Convert 8 Olist CSVs → EvoCRM format | 5 min |
| 2 | `validate_adapter_output.py` | 7 quality checks | 30s |
| 3 | `train_baselines.py` | XGBoost, LightGBM, RF, Linear | 15 min |
| 4 | `train_evocrm.py` | 3-phase: towers→hub→LoRA finetune | 3-5 hrs |
| 5 | `evaluate_evocrm.py` | EvoCRM vs baselines → Table 1 | 5 min |
| 6 | `run_ablations.py` | Tower/Hub/LoRA/Multi-task ablations | 4-8 hrs |
| 7 | `generate_paper_artifacts.py` | LaTeX tables + figures | 1 min |

## Step-by-Step (Manual)

```bash
python olist_adapter.py --data_dir ./olist_raw/ --output_dir ./data/olist/
python validate_adapter_output.py --data_dir ./data/olist/
python train_baselines.py --data_dir ./data/olist/ --output_dir ./results/baselines/
python train_evocrm.py --data_dir ./data/olist/ --phase all --epochs 50,30,20 --use_lora
python evaluate_evocrm.py --data_dir ./data/olist/ --checkpoint ./checkpoints/evocrm_final.pt --baselines ./results/baselines/all_baseline_results.json --output_dir ./results/evaluation/
python run_ablations.py --data_dir ./data/olist/ --output_dir ./results/ablations/
python generate_paper_artifacts.py --results_dir ./results/ --output_dir ./results/paper_artifacts/
```

## Output Files

| File | Paper Section |
|------|---------------|
| `results/evaluation/table1_main_results.tex` | Table 1: Main results |
| `results/paper_artifacts/table2_param_efficiency.tex` | Table 2: LoRA efficiency |
| `results/paper_artifacts/table3_tower_ablation.tex` | Table 3: Tower importance |
| `results/paper_artifacts/table4_hub_comparison.tex` | Table 4: Hub architecture |
| `results/paper_artifacts/table5_multitask.tex` | Table 5: Multi-task benefit |
| `results/paper_artifacts/figure_lora_pareto.png` | Figure 3: Pareto curve |

## Files in This Project

```
evocrm_olist_project/
├── run_full_pipeline.py           # Master orchestrator (run this)
├── olist_adapter.py               # Step 1: Olist → EvoCRM format
├── validate_adapter_output.py     # Step 2: Quality checks
├── train_baselines.py             # Step 3: XGBoost/RF/LightGBM
├── train_evocrm.py                # Step 4: 3-phase EvoCRM training
├── evaluate_evocrm.py             # Step 5: Evaluation + Table 1
├── run_ablations.py               # Step 6: 4 ablation studies
├── generate_paper_artifacts.py    # Step 7: LaTeX + figures
├── requirements.txt               # Dependencies
└── README.md                      # This file
```
