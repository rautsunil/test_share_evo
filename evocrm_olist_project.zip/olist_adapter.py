"""
Olist Brazilian E-Commerce → EvoCRM Data Adapter Pipeline
============================================================

Converts the Olist public dataset (8 relational tables) into EvoCRM's
4-table format with all 6 task head targets.

Source: https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce

Usage:
    python olist_adapter.py --data_dir ./olist_raw/ --output_dir ./data/olist/
"""

import os
import json
import hashlib
import argparse
import warnings
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")


@dataclass
class OlistConfig:
    data_dir: str = "./olist_raw/"
    output_dir: str = "./data/olist/"
    valid_order_statuses: tuple = ("delivered", "shipped", "invoiced", "processing")
    min_orders_per_user: int = 1
    churn_window_days: int = 90
    churn_gap_days: int = 30
    upsell_aov_increase_pct: float = 0.20
    early_adopter_days: int = 30
    next_purchase_max_days: int = 365
    train_ratio: float = 0.70
    val_ratio: float = 0.15
    test_ratio: float = 0.15
    dissatisfied_threshold: int = 2
    seed: int = 42


# ============================================================
# STEP 1: LOAD
# ============================================================

class OlistLoader:
    REQUIRED = {
        "customers": "olist_customers_dataset.csv",
        "orders": "olist_orders_dataset.csv",
        "order_items": "olist_order_items_dataset.csv",
        "payments": "olist_order_payments_dataset.csv",
        "reviews": "olist_order_reviews_dataset.csv",
        "products": "olist_products_dataset.csv",
        "sellers": "olist_sellers_dataset.csv",
    }
    OPTIONAL = {
        "geolocation": "olist_geolocation_dataset.csv",
        "category_translation": "product_category_name_translation.csv",
    }

    def __init__(self, config: OlistConfig):
        self.config = config
        self.data_dir = Path(config.data_dir)

    def load_all(self) -> Dict[str, pd.DataFrame]:
        print("=" * 60)
        print("STEP 1: LOADING OLIST DATASET")
        print("=" * 60)

        data = {}
        for key, fname in self.REQUIRED.items():
            path = self.data_dir / fname
            if not path.exists():
                raise FileNotFoundError(
                    f"{fname} not found at {path}.\n"
                    f"Download: kaggle datasets download -d olistbr/brazilian-ecommerce"
                )
            data[key] = pd.read_csv(path)
            print(f"  ✓ {fname}: {len(data[key]):,} rows")

        for key, fname in self.OPTIONAL.items():
            path = self.data_dir / fname
            if path.exists():
                data[key] = pd.read_csv(path)
                print(f"  ✓ {fname}: {len(data[key]):,} rows (optional)")
            else:
                data[key] = pd.DataFrame()
                print(f"  ⚠ {fname}: not found (optional)")

        # Parse datetimes
        dt_cols = {
            "orders": ["order_purchase_timestamp", "order_approved_at",
                       "order_delivered_carrier_date", "order_delivered_customer_date",
                       "order_estimated_delivery_date"],
            "reviews": ["review_creation_date", "review_answer_timestamp"],
        }
        for tbl, cols in dt_cols.items():
            for col in cols:
                if col in data[tbl].columns:
                    data[tbl][col] = pd.to_datetime(data[tbl][col], errors="coerce")

        # Translate categories
        if not data["category_translation"].empty and not data["products"].empty:
            data["products"] = data["products"].merge(
                data["category_translation"], on="product_category_name", how="left"
            )
            data["products"]["category_english"] = (
                data["products"].get("product_category_name_english",
                                     pd.Series(dtype=str))
                .fillna(data["products"]["product_category_name"])
            )

        print(f"\n  Orders: {len(data['orders']):,} | "
              f"Customers: {data['customers']['customer_unique_id'].nunique():,} | "
              f"Products: {len(data['products']):,}\n")
        return data


# ============================================================
# STEP 2: CLEAN
# ============================================================

class OlistCleaner:
    def __init__(self, config: OlistConfig):
        self.config = config

    def clean(self, data: Dict[str, pd.DataFrame]) -> Dict[str, pd.DataFrame]:
        print("=" * 60)
        print("STEP 2: CLEANING & ENRICHMENT")
        print("=" * 60)

        orders = data["orders"]
        n0 = len(orders)
        orders = orders[orders["order_status"].isin(self.config.valid_order_statuses)].copy()
        print(f"  [2a] Status filter: {n0:,} → {len(orders):,}")

        orders = orders.dropna(subset=["order_purchase_timestamp"])
        print(f"  [2b] Drop null timestamps: {len(orders):,}")

        # Resolve customer_unique_id
        customers = data["customers"]
        orders = orders.merge(
            customers[["customer_id", "customer_unique_id"]],
            on="customer_id", how="left"
        )
        print(f"  [2c] Resolved to {orders['customer_unique_id'].nunique():,} unique customers")

        # Filter min orders
        uc = orders.groupby("customer_unique_id").size()
        active = uc[uc >= self.config.min_orders_per_user].index
        orders = orders[orders["customer_unique_id"].isin(active)]
        print(f"  [2d] After min_orders filter: {orders['customer_unique_id'].nunique():,} users")

        # Filter order_items
        items = data["order_items"][data["order_items"]["order_id"].isin(orders["order_id"])].copy()

        # Merge product info
        products = data["products"]
        merge_cols = ["product_id"]
        for c in ["category_english", "product_weight_g", "product_length_cm",
                   "product_height_cm", "product_width_cm", "product_photos_qty",
                   "product_name_lenght", "product_description_lenght"]:
            if c in products.columns:
                merge_cols.append(c)
        items = items.merge(products[merge_cols], on="product_id", how="left")

        # Aggregate payments
        payments = data["payments"][data["payments"]["order_id"].isin(orders["order_id"])].copy()
        pay_agg = payments.groupby("order_id").agg(
            total_payment=("payment_value", "sum"),
            n_installments=("payment_installments", "max"),
            payment_types=("payment_type", lambda x: ",".join(sorted(x.unique()))),
            n_payment_methods=("payment_type", "nunique"),
        ).reset_index()

        # Aggregate reviews
        reviews = data["reviews"][data["reviews"]["order_id"].isin(orders["order_id"])].copy()
        rev_agg = reviews.groupby("order_id").agg(
            review_score=("review_score", "mean"),
            has_review_comment=("review_comment_message", lambda x: x.notna().any()),
        ).reset_index()

        # Enrich orders
        orders = orders.merge(pay_agg, on="order_id", how="left")
        orders = orders.merge(rev_agg, on="order_id", how="left")

        orders["delivery_days"] = (
            orders["order_delivered_customer_date"] - orders["order_purchase_timestamp"]
        ).dt.days
        orders["delivery_vs_estimate"] = (
            orders["order_delivered_customer_date"] - orders["order_estimated_delivery_date"]
        ).dt.days

        data["orders"] = orders
        data["order_items"] = items
        data["payments"] = payments
        data["reviews"] = reviews

        print(f"\n  Clean: {len(orders):,} orders | "
              f"{orders['customer_unique_id'].nunique():,} users | "
              f"{items['product_id'].nunique():,} products\n")
        return data


# ============================================================
# STEP 3: CONVERT TO 4-TABLE FORMAT
# ============================================================

class OlistConverter:
    def __init__(self, config: OlistConfig):
        self.config = config
        self.rng = np.random.RandomState(config.seed)

    def build_demographics(self, data):
        print("  [Table 1/4] Demographics ...")
        orders = data["orders"]
        customers = data["customers"]

        info = orders.sort_values("order_purchase_timestamp").groupby("customer_unique_id").agg(
            first_order=("order_purchase_timestamp", "min"),
            last_order=("order_purchase_timestamp", "max"),
            total_orders=("order_id", "nunique"),
            customer_id_last=("customer_id", "last"),
        ).reset_index()

        loc = customers[["customer_id", "customer_city", "customer_state",
                         "customer_zip_code_prefix"]].drop_duplicates(subset=["customer_id"])
        info = info.merge(loc, left_on="customer_id_last", right_on="customer_id", how="left")

        demo = pd.DataFrame({
            "user_id": info["customer_unique_id"],
            "registration_date": info["first_order"],
            "city": info["customer_city"].fillna("unknown"),
            "state": info["customer_state"].fillna("unknown"),
            "zip_prefix": info["customer_zip_code_prefix"].fillna(0).astype(int),
            "tenure_days": (info["last_order"] - info["first_order"]).dt.days.fillna(0).astype(int),
            "total_orders": info["total_orders"],
            "user_segment": pd.cut(
                info["total_orders"], bins=[0, 1, 2, 4, float("inf")],
                labels=["one_time", "returning", "regular", "power_buyer"]
            ).astype(str),
        })
        print(f"    → {len(demo):,} users | {demo['state'].nunique()} states")
        return demo

    def build_transactions(self, data):
        print("  [Table 2/4] Transactions ...")
        orders = data["orders"]
        items = data["order_items"]

        oi = orders[["order_id", "customer_unique_id", "order_purchase_timestamp",
                      "total_payment", "review_score"]].drop_duplicates(subset=["order_id"])
        txn = items.merge(oi, on="order_id", how="inner")

        result = pd.DataFrame({
            "transaction_id": txn["order_id"].astype(str) + "_" + txn["order_item_id"].astype(str),
            "user_id": txn["customer_unique_id"],
            "product_id": txn["product_id"],
            "timestamp": txn["order_purchase_timestamp"],
            "amount": (txn["price"] + txn["freight_value"]).round(2),
            "quantity": 1,
            "price": txn["price"],
            "freight": txn["freight_value"],
            "seller_id": txn["seller_id"],
            "review_score": txn["review_score"],
        })
        print(f"    → {len(result):,} items | avg=${result['amount'].mean():.2f}")
        return result

    def build_web_behavior(self, data):
        print("  [Table 3/4] Web behavior (order journey events) ...")
        orders = data["orders"]
        items = data["order_items"]
        reviews = data["reviews"]

        events = []
        eid = 1

        for _, r in orders.iterrows():
            uid = r["customer_unique_id"]
            oid = r["order_id"]

            stages = [
                ("order_placed", r["order_purchase_timestamp"]),
                ("payment_approved", r.get("order_approved_at")),
                ("shipped", r.get("order_delivered_carrier_date")),
                ("delivered", r.get("order_delivered_customer_date")),
            ]
            for etype, ts in stages:
                if pd.notna(ts):
                    events.append({
                        "event_id": eid, "user_id": uid,
                        "product_id": f"ORDER_{str(oid)[:8]}",
                        "event_type": etype, "timestamp": ts, "session_id": oid,
                    })
                    eid += 1

        # Product purchase events
        ou_map = orders.set_index("order_id")["customer_unique_id"].to_dict()
        ots_map = orders.set_index("order_id")["order_purchase_timestamp"].to_dict()
        for _, r in items.iterrows():
            oid = r["order_id"]
            if oid in ou_map:
                events.append({
                    "event_id": eid, "user_id": ou_map[oid],
                    "product_id": r["product_id"],
                    "event_type": "purchase", "timestamp": ots_map.get(oid),
                    "session_id": oid,
                })
                eid += 1

        # Review events
        rev_agg = reviews.groupby("order_id").first()
        for oid, rv in rev_agg.iterrows():
            if oid in ou_map and pd.notna(rv.get("review_creation_date")):
                score = int(rv["review_score"]) if pd.notna(rv.get("review_score")) else 3
                events.append({
                    "event_id": eid, "user_id": ou_map[oid],
                    "product_id": f"REVIEW_{str(oid)[:8]}",
                    "event_type": f"review_score_{score}",
                    "timestamp": rv["review_creation_date"], "session_id": oid,
                })
                eid += 1

        web = pd.DataFrame(events)
        web = web.sort_values(["user_id", "timestamp"]).reset_index(drop=True)
        web["event_id"] = range(1, len(web) + 1)
        print(f"    → {len(web):,} events | {web['session_id'].nunique():,} sessions")
        return web

    def build_campaigns(self, data):
        print("  [Table 4/4] Campaigns (empty — no marketing data)")
        return pd.DataFrame({
            "user_id": pd.Series(dtype="str"),
            "campaign_id": pd.Series(dtype="str"),
            "timestamp": pd.Series(dtype="datetime64[ns]"),
            "clicked": pd.Series(dtype="int64"),
        })

    def convert_all(self, data):
        print("=" * 60)
        print("STEP 3: CONVERTING TO EVOCRM FORMAT")
        print("=" * 60)
        return {
            "demographics": self.build_demographics(data),
            "transactions": self.build_transactions(data),
            "web_behavior": self.build_web_behavior(data),
            "campaigns": self.build_campaigns(data),
        }


# ============================================================
# STEP 4: TARGETS
# ============================================================

class OlistTargetGenerator:
    def __init__(self, config: OlistConfig):
        self.config = config

    def generate_all(self, txn, web, demo, raw_data):
        print("=" * 60)
        print("STEP 4: GENERATING TARGETS (6 + 1 bonus)")
        print("=" * 60)

        users = demo[["user_id"]].copy()
        data_end = txn["timestamp"].max() if not txn.empty else pd.Timestamp.now()

        users = self._churn(users, txn, data_end)
        users = self._clv(users, txn)
        users = self._upsell(users, txn)
        users = self._next_item(users, txn)
        users = self._early_adopter(users, txn)
        users = self._days_next_purchase(users, txn, data_end)
        users = self._satisfaction_risk(users, txn)

        print(f"\n  Targets for {len(users):,} users")
        return users

    def _churn(self, users, txn, data_end):
        print("  [1/7] Churn ...")
        cutoff = data_end - pd.Timedelta(days=self.config.churn_window_days)
        if txn.empty:
            users["churn"] = 1
        else:
            lp = txn.groupby("user_id")["timestamp"].max().reset_index()
            lp.columns = ["user_id", "lp_ts"]
            users = users.merge(lp, on="user_id", how="left")
            users["churn"] = (users["lp_ts"].isna() | (users["lp_ts"] < cutoff)).astype(int)
            users = users.drop(columns=["lp_ts"])
        print(f"    → rate: {users['churn'].mean():.1%}")
        return users

    def _clv(self, users, txn):
        print("  [2/7] CLV ...")
        if txn.empty:
            users["clv"] = 0.0
        else:
            c = txn.groupby("user_id")["amount"].sum().reset_index()
            c.columns = ["user_id", "clv"]
            users = users.merge(c, on="user_id", how="left")
            users["clv"] = users["clv"].fillna(0.0)
        print(f"    → mean=${users['clv'].mean():.2f}")
        return users

    def _upsell(self, users, txn):
        print("  [3/7] Upsell ...")
        if txn.empty:
            users["upsell"] = 0
            return users
        oa = txn.groupby(["user_id", "timestamp"]).agg(ot=("amount", "sum")).reset_index()
        oa = oa.sort_values(["user_id", "timestamp"])

        def _calc(g):
            if len(g) < 2:
                return 0
            m = len(g) // 2
            f_aov = g.iloc[:m]["ot"].mean()
            s_aov = g.iloc[m:]["ot"].mean()
            return int(f_aov > 0 and (s_aov - f_aov) / f_aov >= self.config.upsell_aov_increase_pct)

        up = oa.groupby("user_id").apply(_calc).reset_index()
        up.columns = ["user_id", "upsell"]
        users = users.merge(up, on="user_id", how="left")
        users["upsell"] = users["upsell"].fillna(0).astype(int)
        print(f"    → rate: {users['upsell'].mean():.1%}")
        return users

    def _next_item(self, users, txn):
        print("  [4/7] Next item ...")
        if txn.empty:
            users["next_item_id"] = -1
        else:
            li = txn.sort_values("timestamp").groupby("user_id")["product_id"].last()
            li = li.reset_index()
            li.columns = ["user_id", "next_item_id"]
            users = users.merge(li, on="user_id", how="left")
            users["next_item_id"] = users["next_item_id"].fillna("NONE")
        n_valid = (users["next_item_id"] != "NONE").sum() if users["next_item_id"].dtype == object else (users["next_item_id"] != -1).sum()
        print(f"    → {n_valid:,} valid")
        return users

    def _early_adopter(self, users, txn):
        print("  [5/7] Early adopter ...")
        if txn.empty:
            users["early_adopter"] = 0
            return users
        ifirst = txn.groupby("product_id")["timestamp"].min().reset_index()
        ifirst.columns = ["product_id", "first_seen"]
        m = txn.merge(ifirst, on="product_id")
        m["dsl"] = (m["timestamp"] - m["first_seen"]).dt.days
        eu = m[m["dsl"] <= self.config.early_adopter_days]["user_id"].unique()
        users["early_adopter"] = users["user_id"].isin(eu).astype(int)
        print(f"    → rate: {users['early_adopter'].mean():.1%}")
        return users

    def _days_next_purchase(self, users, txn, data_end):
        print("  [6/7] Days next purchase ...")
        if txn.empty:
            users["days_next_purchase"] = float(self.config.next_purchase_max_days)
            return users

        def _gap(g):
            ts = sorted(g["timestamp"].dropna().tolist())
            if len(ts) >= 2:
                return min((ts[-1] - ts[-2]).days, self.config.next_purchase_max_days)
            elif len(ts) == 1:
                return min((data_end - ts[0]).days, self.config.next_purchase_max_days)
            return self.config.next_purchase_max_days

        gaps = txn.groupby("user_id").apply(_gap).reset_index()
        gaps.columns = ["user_id", "days_next_purchase"]
        users = users.merge(gaps, on="user_id", how="left")
        users["days_next_purchase"] = users["days_next_purchase"].fillna(
            self.config.next_purchase_max_days
        ).astype(float)
        print(f"    → mean: {users['days_next_purchase'].mean():.1f} days")
        return users

    def _satisfaction_risk(self, users, txn):
        print("  [7/7] Satisfaction risk (bonus) ...")
        if txn.empty or "review_score" not in txn.columns:
            users["satisfaction_risk"] = 0
            users["avg_review_score"] = 3.0
            return users
        rs = txn.groupby("user_id")["review_score"].mean().reset_index()
        rs.columns = ["user_id", "avg_review_score"]
        users = users.merge(rs, on="user_id", how="left")
        users["avg_review_score"] = users["avg_review_score"].fillna(3.0)
        users["satisfaction_risk"] = (users["avg_review_score"] <= self.config.dissatisfied_threshold).astype(int)
        print(f"    → at-risk rate: {users['satisfaction_risk'].mean():.1%}")
        return users


# ============================================================
# STEP 5: FEATURE ENGINEERING
# ============================================================

class OlistFeatureEngineer:
    def __init__(self, config: OlistConfig):
        self.config = config

    def customer_features(self, demo, txn, web, raw_data):
        print("  [Tower 1/3] Customer Tower Features ...")
        users = demo[["user_id", "city", "state", "user_segment", "tenure_days"]].copy()
        data_end = txn["timestamp"].max() if not txn.empty else pd.Timestamp.now()

        if not txn.empty:
            rfm = txn.groupby("user_id").agg(
                recency_days=("timestamp", lambda x: (data_end - x.max()).days),
                frequency=("transaction_id", "nunique"),
                monetary=("amount", "sum"),
                avg_order_value=("amount", "mean"),
                max_order_value=("amount", "max"),
                min_order_value=("amount", "min"),
                std_order_value=("amount", "std"),
                total_items=("transaction_id", "count"),
                n_unique_products=("product_id", "nunique"),
            ).reset_index()
            rfm["std_order_value"] = rfm["std_order_value"].fillna(0)
            users = users.merge(rfm, on="user_id", how="left")

        if not txn.empty and "price" in txn.columns:
            ps = txn.groupby("user_id").agg(
                avg_item_price=("price", "mean"),
                total_freight=("freight", "sum"),
                avg_freight=("freight", "mean"),
            ).reset_index()
            users = users.merge(ps, on="user_id", how="left")
            if "monetary" in users.columns:
                users["freight_pct"] = users["total_freight"] / users["monetary"].clip(lower=0.01)

        if not txn.empty and "review_score" in txn.columns:
            rv = txn.groupby("user_id").agg(
                avg_review=("review_score", "mean"),
                min_review=("review_score", "min"),
                n_reviews=("review_score", lambda x: x.notna().sum()),
            ).reset_index()
            users = users.merge(rv, on="user_id", how="left")

        if not txn.empty and "seller_id" in txn.columns:
            ss = txn.groupby("user_id").agg(n_unique_sellers=("seller_id", "nunique")).reset_index()
            users = users.merge(ss, on="user_id", how="left")

        orders = raw_data.get("orders", pd.DataFrame())
        if not orders.empty and "delivery_days" in orders.columns:
            ds = orders.groupby("customer_unique_id").agg(
                avg_delivery_days=("delivery_days", "mean"),
                max_delivery_days=("delivery_days", "max"),
                n_late=("delivery_vs_estimate", lambda x: (x > 0).sum()),
            ).reset_index().rename(columns={"customer_unique_id": "user_id"})
            users = users.merge(ds, on="user_id", how="left")

        payments = raw_data.get("payments", pd.DataFrame())
        if not payments.empty and not orders.empty:
            ou = orders[["order_id", "customer_unique_id"]].drop_duplicates()
            pwu = payments.merge(ou, on="order_id", how="inner")
            pst = pwu.groupby("customer_unique_id").agg(
                avg_installments=("payment_installments", "mean"),
                max_installments=("payment_installments", "max"),
                uses_credit_card=("payment_type", lambda x: int("credit_card" in x.values)),
                uses_boleto=("payment_type", lambda x: int("boleto" in x.values)),
            ).reset_index().rename(columns={"customer_unique_id": "user_id"})
            users = users.merge(pst, on="user_id", how="left")

        if not web.empty:
            js = web.groupby("user_id").agg(
                total_journey_events=("event_id", "count"),
                n_order_sessions=("session_id", "nunique"),
            ).reset_index()
            users = users.merge(js, on="user_id", how="left")

        num_cols = users.select_dtypes(include=[np.number]).columns
        users[num_cols] = users[num_cols].fillna(0)
        for c in users.select_dtypes(include=["object"]).columns:
            users[c] = users[c].fillna("unknown")

        print(f"    → {len(users):,} users × {len(users.columns)} features")
        return users

    def interaction_sequences(self, web, max_seq=128):
        print("  [Tower 2/3] Interaction Sequences ...")
        ET = {"order_placed": 1, "payment_approved": 2, "shipped": 3, "delivered": 4,
              "purchase": 5, "review_score_1": 6, "review_score_2": 7,
              "review_score_3": 8, "review_score_4": 9, "review_score_5": 10}

        wb = web.sort_values(["user_id", "timestamp"]).copy()
        wb["etid"] = wb["event_type"].map(ET).fillna(0).astype(int)

        prods = wb["product_id"].unique()
        pid_map = {p: i + 1 for i, p in enumerate(prods)}

        wb["first_ts"] = wb.groupby("user_id")["timestamp"].transform("min")
        wb["td"] = (wb["timestamp"] - wb["first_ts"]).dt.total_seconds().fillna(0)

        seqs = {}
        for uid, g in wb.groupby("user_id"):
            evts = g[["etid", "product_id", "td"]].values.tolist()
            evts = [[int(e[0]), pid_map.get(e[1], 0), float(e[2])] for e in evts]
            seqs[str(uid)] = evts[-max_seq:]

        lens = [len(v) for v in seqs.values()]
        print(f"    → {len(seqs):,} sequences | avg len: {np.mean(lens):.1f}")
        return seqs

    def product_features(self, raw_data, txn):
        print("  [Tower 3/3] Product Features ...")
        products = raw_data.get("products", pd.DataFrame()).copy()
        items = raw_data.get("order_items", pd.DataFrame())

        if products.empty:
            return pd.DataFrame(columns=["product_id"])

        if not items.empty:
            ss = items.groupby("product_id").agg(
                n_orders=("order_id", "nunique"), total_revenue=("price", "sum"),
                avg_price=("price", "mean"), avg_freight=("freight_value", "mean"),
                n_sellers=("seller_id", "nunique"),
            ).reset_index()
            products = products.merge(ss, on="product_id", how="left")

        if not txn.empty and "review_score" in txn.columns:
            pr = txn.groupby("product_id").agg(
                product_avg_review=("review_score", "mean"),
                product_n_reviews=("review_score", lambda x: x.notna().sum()),
            ).reset_index()
            products = products.merge(pr, on="product_id", how="left")

        fill = ["product_weight_g", "product_length_cm", "product_height_cm",
                "product_width_cm", "product_photos_qty", "n_orders", "total_revenue",
                "avg_price", "avg_freight", "n_sellers", "product_avg_review", "product_n_reviews"]
        for c in fill:
            if c in products.columns:
                products[c] = products[c].fillna(0)

        for c in ["category_english", "product_category_name"]:
            if c in products.columns:
                products[c] = products[c].fillna("unknown")

        print(f"    → {len(products):,} products × {len(products.columns)} features")
        return products


# ============================================================
# STEP 6: EXPORT
# ============================================================

class OlistExporter:
    def __init__(self, config: OlistConfig):
        self.config = config
        self.rng = np.random.RandomState(config.seed)

    def export(self, tables, targets, cust_feat, prod_feat, seqs, metadata):
        out = Path(self.config.output_dir)
        out.mkdir(parents=True, exist_ok=True)

        print("=" * 60)
        print("STEP 6: EXPORTING")
        print("=" * 60)

        (out / "tables").mkdir(exist_ok=True)
        for name, df in tables.items():
            df.to_csv(out / "tables" / f"{name}.csv", index=False)
            print(f"  ✓ tables/{name}.csv ({len(df):,})")

        targets.to_csv(out / "targets.csv", index=False)
        print(f"  ✓ targets.csv ({len(targets):,})")

        (out / "features").mkdir(exist_ok=True)
        cust_feat.to_csv(out / "features" / "customer_tower_features.csv", index=False)
        print(f"  ✓ customer_tower_features.csv ({len(cust_feat):,})")
        prod_feat.to_csv(out / "features" / "product_tower_features.csv", index=False)
        print(f"  ✓ product_tower_features.csv ({len(prod_feat):,})")

        with open(out / "features" / "interaction_sequences.json", "w") as f:
            json.dump(seqs, f)
        print(f"  ✓ interaction_sequences.json ({len(seqs):,})")

        # Splits
        uids = targets["user_id"].values
        n = len(uids)
        shuf = self.rng.permutation(uids)
        nt = int(n * self.config.train_ratio)
        nv = int(n * self.config.val_ratio)
        splits = {"train": shuf[:nt], "val": shuf[nt:nt + nv], "test": shuf[nt + nv:]}
        (out / "splits").mkdir(exist_ok=True)
        for name, ids in splits.items():
            np.save(out / "splits" / f"{name}_user_ids.npy", ids)
            print(f"  ✓ {name}_user_ids.npy ({len(ids):,})")

        with open(out / "metadata.json", "w") as f:
            json.dump(metadata, f, indent=2, default=str)
        print(f"  ✓ metadata.json\n")


# ============================================================
# MAIN PIPELINE
# ============================================================

class OlistToEvoCRM:
    def __init__(self, config: OlistConfig):
        self.config = config

    def run(self):
        print("╔" + "═" * 58 + "╗")
        print("║   Olist → EvoCRM Data Adapter                          ║")
        print("╚" + "═" * 58 + "╝\n")

        raw = OlistLoader(self.config).load_all()
        data = OlistCleaner(self.config).clean(raw)
        tables = OlistConverter(self.config).convert_all(data)

        tg = OlistTargetGenerator(self.config)
        targets = tg.generate_all(tables["transactions"], tables["web_behavior"],
                                   tables["demographics"], data)

        print("\n" + "=" * 60)
        print("STEP 5: FEATURE ENGINEERING")
        print("=" * 60)
        fe = OlistFeatureEngineer(self.config)
        cf = fe.customer_features(tables["demographics"], tables["transactions"],
                                   tables["web_behavior"], data)
        seqs = fe.interaction_sequences(tables["web_behavior"])
        pf = fe.product_features(data, tables["transactions"])

        cat_cols = ["city", "state", "user_segment"]
        num_cols = [c for c in cf.select_dtypes(include=[np.number]).columns if c != "user_id"]

        metadata = {
            "source_dataset": "Olist Brazilian E-Commerce",
            "source_url": "https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce",
            "conversion_date": datetime.now().isoformat(),
            "config": {"churn_window_days": self.config.churn_window_days, "seed": self.config.seed},
            "stats": {
                "n_users": len(tables["demographics"]),
                "n_transactions": len(tables["transactions"]),
                "n_web_events": len(tables["web_behavior"]),
                "n_products": pf["product_id"].nunique() if "product_id" in pf.columns else 0,
                "n_categories": pf["category_english"].nunique() if "category_english" in pf.columns else 0,
            },
            "customer_tower": {
                "categorical_features": cat_cols,
                "categorical_cardinalities": {c: int(cf[c].nunique()) for c in cat_cols},
                "numerical_features": num_cols,
                "num_numerical": len(num_cols),
                "num_categorical": len(cat_cols),
            },
            "interaction_tower": {"max_sequence_length": 128, "num_event_types": 10},
            "product_tower": {
                "num_products": int(pf["product_id"].nunique()) if "product_id" in pf.columns else 0,
                "has_text_descriptions": True,
            },
            "targets": {
                "churn": {"type": "binary", "positive_rate": float(targets["churn"].mean())},
                "clv": {"type": "continuous", "mean": float(targets["clv"].mean())},
                "upsell": {"type": "binary", "positive_rate": float(targets["upsell"].mean())},
                "early_adopter": {"type": "binary", "positive_rate": float(targets["early_adopter"].mean())},
                "days_next_purchase": {"type": "continuous", "mean": float(targets["days_next_purchase"].mean())},
                "satisfaction_risk": {"type": "binary", "positive_rate": float(targets["satisfaction_risk"].mean())},
            },
            "splits": {"train": self.config.train_ratio, "val": self.config.val_ratio, "test": self.config.test_ratio},
            "limitations": [
                "No web browsing data — Interaction Tower uses order journey events",
                "No campaign data — Campaign Tower zeroed",
                "Most customers have only 1 order",
                "Brazilian market only",
            ],
        }

        OlistExporter(self.config).export(tables, targets, cf, pf, seqs, metadata)

        print("╔" + "═" * 58 + "╗")
        print("║   OLIST ADAPTER COMPLETE                                ║")
        print(f"║   Users: {metadata['stats']['n_users']:>8,}  Transactions: {metadata['stats']['n_transactions']:>8,}   ║")
        print("╚" + "═" * 58 + "╝")


def main():
    p = argparse.ArgumentParser(description="Olist → EvoCRM adapter")
    p.add_argument("--data_dir", type=str, default="./olist_raw/")
    p.add_argument("--output_dir", type=str, default="./data/olist/")
    p.add_argument("--churn_window", type=int, default=90)
    p.add_argument("--seed", type=int, default=42)
    a = p.parse_args()
    OlistToEvoCRM(OlistConfig(data_dir=a.data_dir, output_dir=a.output_dir,
                               churn_window_days=a.churn_window, seed=a.seed)).run()


if __name__ == "__main__":
    main()
